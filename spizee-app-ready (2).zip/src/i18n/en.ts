export const copy = {
  brand: {
    name: 'SPIZEE',
    nameBn: 'স্পাইজি',
    tagline: 'Fresh, crispy fast food crafted to order in Dhaka.',
  },
  nav: {
    home: 'Home',
    menu: 'Menu',
    about: 'About',
    contact: 'Contact',
    cart: 'Cart',
    profile: 'Profile',
    admin: 'Admin',
    signIn: 'Sign In',
  },
  orderTypes: {
    home_delivery: 'Home Delivery',
    pickup: 'Instant Pickup',
    dine_in: 'Dine-In',
  } as Record<string, string>,
  orderStatuses: {
    pending: 'Pending',
    confirmed: 'Confirmed',
    preparing: 'Preparing',
    ready: 'Ready',
    completed: 'Completed',
    cancelled: 'Cancelled',
  } as Record<string, string>,
};
