import React from 'react';
import { AlertTriangle, CheckCircle2, Info, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const FeedbackOverlays: React.FC = () => {
  const { toasts, dismissToast, confirmState, resolveConfirm } = useApp();

  return (
    <>
      {/* Toast Notifications */}
      <div
        aria-live="polite"
        className="no-print pointer-events-none fixed bottom-5 right-5 z-[60] flex w-full max-w-sm flex-col gap-2 px-4 sm:px-0"
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            className="pointer-events-auto flex items-center gap-3 rounded-2xl border border-stone-200 bg-white/95 px-4 py-3 text-sm font-medium text-[#1C1917] shadow-lg backdrop-blur-md"
          >
            {t.type === 'success' && (
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
            )}
            {t.type === 'error' && (
              <AlertTriangle className="h-4 w-4 shrink-0 text-red-600" />
            )}
            {t.type === 'info' && <Info className="h-4 w-4 shrink-0 text-[#D99B00]" />}
            <span className="flex-1">{t.message}</span>
            <button
              type="button"
              onClick={() => dismissToast(t.id)}
              aria-label="Dismiss notification"
              className="rounded-lg p-1 text-stone-400 hover:bg-stone-100 hover:text-stone-700"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Global Confirmation Dialog */}
      {confirmState && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="confirm-dialog-title"
          className="no-print fixed inset-0 z-[70] flex items-center justify-center bg-stone-900/40 p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-md rounded-2xl border border-stone-200 bg-white p-6 shadow-2xl">
            <h3 id="confirm-dialog-title" className="font-display text-lg font-bold text-[#1C1917]">
              {confirmState.title}
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-stone-600">
              {confirmState.message}
            </p>
            <div className="mt-6 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => resolveConfirm(false)}
                className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-sm font-semibold text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => resolveConfirm(true)}
                className={`rounded-xl px-4 py-2 text-sm font-bold transition ${
                  confirmState.destructive
                    ? 'bg-red-600 text-white hover:bg-red-700'
                    : 'bg-[#F5B800] text-[#1C1917] hover:bg-[#E0A700]'
                }`}
              >
                {confirmState.confirmLabel || 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
