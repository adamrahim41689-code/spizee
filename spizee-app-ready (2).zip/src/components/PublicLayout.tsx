import React, { useState } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import {
  Clock,
  ExternalLink,
  LayoutDashboard,
  Mail,
  MapPin,
  Menu,
  Phone,
  ShoppingBag,
  User,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { SpizeeLogo } from './SpizeeLogo';
import { CartDrawer } from './CartDrawer';

export const PublicLayout: React.FC = () => {
  const { settings, user, cartCount, setCartOpen } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    `whitespace-nowrap shrink-0 text-sm font-medium transition-colors ${
      isActive
        ? 'text-[#1C1917] underline decoration-[#F5B800] decoration-2 underline-offset-8'
        : 'text-stone-600 hover:text-[#1C1917]'
    }`;

  return (
    <div className="flex min-h-screen flex-col bg-[#FFFDF7] text-[#1C1917]">
      {/* Sticky Frosted Glass 3-Zone Header */}
      <header className="no-print sticky top-0 z-40 border-b border-stone-200/80 bg-white/82 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-6 px-4 sm:px-6 lg:px-8">
          {/* Zone 1: Brand wordmark */}
          <Link to="/" aria-label="SPIZEE Home" className="shrink-0">
            <SpizeeLogo size="md" />
          </Link>

          {/* Zone 2: Primary navigation links */}
          <nav aria-label="Primary navigation" className="hidden items-center gap-7 md:flex">
            <NavLink to="/" end className={navLinkClass}>
              Home
            </NavLink>
            <NavLink to="/menu" className={navLinkClass}>
              Menu
            </NavLink>
            <NavLink to="/about" className={navLinkClass}>
              About
            </NavLink>
            <NavLink to="/contact" className={navLinkClass}>
              Contact
            </NavLink>
          </nav>

          {/* Zone 3: Cart & Account Actions */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setCartOpen(true)}
              aria-label={`Open cart (${cartCount} items)`}
              className="relative inline-flex h-10 items-center gap-2 rounded-xl border border-stone-200/90 bg-white px-3.5 text-sm font-semibold text-[#1C1917] transition hover:border-[#F5B800] hover:bg-[#FFF9E6] whitespace-nowrap"
            >
              <ShoppingBag className="h-4 w-4 text-[#B47B00]" />
              <span className="hidden sm:inline">Cart</span>
              <span
                data-testid="cart-badge-count"
                className="inline-flex min-w-[20px] items-center justify-center rounded-md bg-[#F5B800] px-1.5 py-0.5 font-mono text-xs font-bold text-[#1C1917] tabular-nums"
              >
                {cartCount}
              </span>
            </button>

            {user ? (
              <div className="hidden items-center gap-2 md:flex">
                {(user.role === 'admin' || user.role === 'manager') && (
                  <Link
                    to="/admin"
                    className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3.5 text-sm font-semibold text-[#1C1917] transition hover:border-[#1C1917] whitespace-nowrap"
                  >
                    <LayoutDashboard className="h-4 w-4" />
                    Admin
                  </Link>
                )}
                <Link
                  to="/profile"
                  className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#1C1917] px-4 text-sm font-semibold text-white transition hover:bg-stone-800 whitespace-nowrap"
                >
                  <User className="h-4 w-4" />
                  <span className="max-w-[110px] truncate">
                    {user.fullName?.split(' ')[0] || 'Profile'}
                  </span>
                </Link>
              </div>
            ) : (
              <Link
                to="/login"
                className="hidden h-10 items-center rounded-xl bg-[#F5B800] px-4 text-sm font-bold text-[#1C1917] transition hover:bg-[#E0A700] whitespace-nowrap md:inline-flex"
              >
                Sign In
              </Link>
            )}

            <button
              type="button"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
              className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-stone-200 bg-white text-[#1C1917] md:hidden"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        {mobileMenuOpen && (
          <div className="border-t border-stone-200 bg-white px-4 py-4 md:hidden">
            <nav className="flex flex-col gap-1">
              {[
                { to: '/', label: 'Home' },
                { to: '/menu', label: 'Menu' },
                { to: '/about', label: 'About' },
                { to: '/contact', label: 'Contact' },
                { to: '/cart', label: `Cart (${cartCount})` },
              ].map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className="rounded-xl px-3 py-2.5 text-sm font-semibold text-[#1C1917] hover:bg-[#FFF9E6]"
                >
                  {item.label}
                </Link>
              ))}
              <div className="mt-2 border-t border-stone-200 pt-3">
                {user ? (
                  <div className="flex flex-col gap-2">
                    <Link
                      to="/profile"
                      onClick={() => setMobileMenuOpen(false)}
                      className="rounded-xl bg-[#1C1917] px-4 py-2.5 text-center text-sm font-semibold text-white"
                    >
                      My Profile ({user.fullName || user.email})
                    </Link>
                    {(user.role === 'admin' || user.role === 'manager') && (
                      <Link
                        to="/admin"
                        onClick={() => setMobileMenuOpen(false)}
                        className="rounded-xl bg-[#F5B800] px-4 py-2.5 text-center text-sm font-bold text-[#1C1917]"
                      >
                        Admin Dashboard
                      </Link>
                    )}
                  </div>
                ) : (
                  <Link
                    to="/login"
                    onClick={() => setMobileMenuOpen(false)}
                    className="block rounded-xl bg-[#F5B800] px-4 py-2.5 text-center text-sm font-bold text-[#1C1917]"
                  >
                    Sign In / Sign Up
                  </Link>
                )}
              </div>
            </nav>
          </div>
        )}
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer driven dynamically by site_settings */}
      <footer className="no-print mt-16 border-t border-stone-200/90 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <SpizeeLogo size="md" />
              <p className="mt-1.5 text-xs font-semibold text-[#B47B00]">
                {settings?.restaurantName || 'SPIZEE'} · স্পাইজি
              </p>
              <p className="mt-3 text-sm leading-relaxed text-stone-600">
                {settings?.shortDescription ||
                  'Fresh, extra-crispy fried chicken, handcrafted burgers, and flame-grilled shawarma served hot in Dhaka.'}
              </p>
            </div>

            <div>
              <h3 className="font-display text-sm font-bold text-[#1C1917]">Explore</h3>
              <ul className="mt-3 space-y-2 text-sm text-stone-600">
                <li>
                  <Link to="/" className="hover:text-[#1C1917]">Home</Link>
                </li>
                <li>
                  <Link to="/menu" className="hover:text-[#1C1917]">Full Menu</Link>
                </li>
                <li>
                  <Link to="/about" className="hover:text-[#1C1917]">About SPIZEE</Link>
                </li>
                <li>
                  <Link to="/contact" className="hover:text-[#1C1917]">Contact &amp; Delivery</Link>
                </li>
                <li>
                  <Link to="/cart" className="hover:text-[#1C1917]">Shopping Cart</Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-display text-sm font-bold text-[#1C1917]">Visit &amp; Contact</h3>
              <ul className="mt-3 space-y-2.5 text-sm text-stone-600">
                {settings?.address && (
                  <li className="flex items-start gap-2">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#D99B00]" />
                    <span>{settings.address}</span>
                  </li>
                )}
                {settings?.phone && (
                  <li className="flex items-center gap-2 tabular-nums">
                    <Phone className="h-4 w-4 shrink-0 text-[#D99B00]" />
                    <a href={`tel:${settings.phone}`} className="hover:text-[#1C1917]">
                      {settings.phone}
                    </a>
                  </li>
                )}
                {settings?.email && (
                  <li className="flex items-center gap-2">
                    <Mail className="h-4 w-4 shrink-0 text-[#D99B00]" />
                    <a href={`mailto:${settings.email}`} className="hover:text-[#1C1917]">
                      {settings.email}
                    </a>
                  </li>
                )}
                {settings?.openingHours && (
                  <li className="flex items-center gap-2">
                    <Clock className="h-4 w-4 shrink-0 text-[#D99B00]" />
                    <span>{settings.openingHours}</span>
                  </li>
                )}
              </ul>
            </div>

            <div>
              <h3 className="font-display text-sm font-bold text-[#1C1917]">Connect With Us</h3>
              <div className="mt-3 flex flex-wrap gap-2">
                {settings?.facebook && (
                  <a
                    href={settings.facebook}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 rounded-lg border border-stone-200 px-3 py-1.5 text-xs font-semibold text-stone-700 hover:border-[#F5B800] hover:bg-[#FFF9E6]"
                  >
                    Facebook
                    <ExternalLink className="h-3 w-3" />
                  </a>
                )}
                {settings?.instagram && (
                  <a
                    href={settings.instagram}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 rounded-lg border border-stone-200 px-3 py-1.5 text-xs font-semibold text-stone-700 hover:border-[#F5B800] hover:bg-[#FFF9E6]"
                  >
                    Instagram
                    <ExternalLink className="h-3 w-3" />
                  </a>
                )}
                {settings?.tiktok && (
                  <a
                    href={settings.tiktok}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 rounded-lg border border-stone-200 px-3 py-1.5 text-xs font-semibold text-stone-700 hover:border-[#F5B800] hover:bg-[#FFF9E6]"
                  >
                    TikTok
                    <ExternalLink className="h-3 w-3" />
                  </a>
                )}
                {settings?.whatsapp && (
                  <a
                    href={`https://wa.me/${settings.whatsapp.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 rounded-lg border border-stone-200 px-3 py-1.5 text-xs font-semibold text-stone-700 hover:border-[#F5B800] hover:bg-[#FFF9E6]"
                  >
                    WhatsApp
                    <ExternalLink className="h-3 w-3" />
                  </a>
                )}
              </div>
              {settings?.googleMapsUrl && (
                <a
                  href={settings.googleMapsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-[#B47B00] hover:underline"
                >
                  Open Restaurant Location in Google Maps
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              )}
            </div>
          </div>

          {(() => {
            const copyrightText =
              settings?.footerCopyright !== null && settings?.footerCopyright !== undefined
                ? settings.footerCopyright
                : `© ${new Date().getFullYear()} ${settings?.restaurantName || 'SPIZEE'} (স্পাইজি). All rights reserved.`;
            const rightText =
              settings?.footerRightText !== null && settings?.footerRightText !== undefined
                ? settings.footerRightText
                : 'Prices in Bangladeshi Taka (৳ BDT) · Asia/Dhaka Time';
            if (!copyrightText && !rightText) return null;
            const sizeClass =
              settings?.footerTextSize === 'lg'
                ? 'text-lg font-semibold text-stone-700'
                : settings?.footerTextSize === 'base'
                ? 'text-base font-medium text-stone-600'
                : settings?.footerTextSize === 'sm'
                ? 'text-sm text-stone-600'
                : 'text-xs text-stone-500';
            return (
              <div
                data-testid="site-footer-bottom"
                className={`mt-10 flex flex-col items-center justify-between gap-3 border-t border-stone-200/80 pt-6 sm:flex-row ${sizeClass}`}
              >
                {copyrightText && <p>{copyrightText}</p>}
                {rightText && <p>{rightText}</p>}
              </div>
            );
          })()}
        </div>
      </footer>

      <CartDrawer />
    </div>
  );
};
