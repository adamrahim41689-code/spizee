import { resolveMediaUrl } from '../lib/api';
import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';

interface SpizeeLogoProps {
  size?: 'sm' | 'md' | 'lg';
  monochrome?: boolean;
  logoOverride?: string | null;
}

export const SpizeeLogo: React.FC<SpizeeLogoProps> = ({
  size = 'md',
  monochrome = false,
  logoOverride,
}) => {
  const { settings } = useApp();
  const logoUrl = logoOverride !== undefined ? logoOverride : settings?.logoUrl;
  const brandName = settings?.restaurantName || 'SPIZEE';
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setImgFailed(false);
  }, [logoUrl]);

  const imgHeight =
    size === 'sm' ? 'h-10' : size === 'lg' ? 'h-16' : 'h-12';
  const boxSize =
    size === 'sm' ? 'h-8 w-8 text-base' : size === 'lg' ? 'h-11 w-11 text-xl' : 'h-9 w-9 text-lg';
  const textSize =
    size === 'sm' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-xl';

  if (logoUrl && !imgFailed) {
    return (
      <span className="inline-flex items-center whitespace-nowrap shrink-0">
        <img
          src={resolveMediaUrl(logoUrl)}
          alt={brandName}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className={`${imgHeight} w-auto max-w-[180px] rounded-lg object-contain`}
        />
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0">
      <span
        aria-hidden="true"
        className={`inline-flex items-center justify-center rounded-xl font-display font-extrabold select-none ${boxSize} ${
          monochrome
            ? 'border-2 border-black bg-white text-black'
            : 'bg-[#F5B800] text-[#1C1917] shadow-sm'
        }`}
      >
        S
      </span>
      <span
        className={`font-display font-extrabold tracking-tight ${textSize} ${
          monochrome ? 'text-black' : 'text-[#1C1917]'
        }`}
      >
        {brandName}
      </span>
    </span>
  );
};
