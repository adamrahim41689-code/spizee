import React, { useState } from 'react';
import { Download, Printer, Scissors } from 'lucide-react';
import type { OrderDetail, SiteSettings } from '../types';
import { formatBdt, formatDhakaDateTime } from '../utils/orderMath';
import { downloadReceiptPdf, printReceiptHtml } from '../utils/receiptPdf';
import { copy } from '../i18n/en';
import { SpizeeLogo } from './SpizeeLogo';

interface ReceiptPaperProps {
  order: OrderDetail;
  settings: SiteSettings | null;
  showActions?: boolean;
}

export const ReceiptPaper: React.FC<ReceiptPaperProps> = ({
  order,
  settings,
  showActions = true,
}) => {
  const [downloading, setDownloading] = useState(false);
  const [printing, setPrinting] = useState(false);
  const receiptNumber = order.receipt?.receiptNumber || `SPZ-${order.orderNumber}`;
  const dhaka = formatDhakaDateTime(order.receipt?.issuedAt || order.createdAt);
  const totalQty = order.items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  const orderTypeLabel = copy.orderTypes[order.orderType] || order.orderType;
  const statusLabel = copy.orderStatuses[order.status] || order.status;

  const handlePrint = async () => {
    if (printing) return;
    setPrinting(true);
    try {
      await printReceiptHtml(order, settings);
    } finally {
      setPrinting(false);
    }
  };

  const handleDownloadPdf = async () => {
    if (downloading) return;
    setDownloading(true);
    try {
      await downloadReceiptPdf(order, settings);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="flex flex-col items-center">
      {showActions && (
        <div className="no-print mb-5 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            disabled={printing}
            onClick={handlePrint}
            className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-xs transition hover:bg-emerald-700 disabled:opacity-60 whitespace-nowrap"
          >
            <Printer className="h-4 w-4" />
            {printing ? 'Opening Printer…' : 'Print Receipt'}
          </button>
          <button
            type="button"
            disabled={downloading}
            onClick={handleDownloadPdf}
            className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-[#F5B800] px-5 py-2.5 text-sm font-bold text-[#1C1917] shadow-xs transition hover:bg-[#E0A700] disabled:opacity-60 whitespace-nowrap"
          >
            <Download className="h-4 w-4" />
            {downloading ? 'Generating PDF…' : 'Download Receipt (PDF)'}
          </button>
        </div>
      )}

      {/* Single-page continuous thermal receipt: Customer Copy + Tear Line + Kitchen Copy */}
      <article
        aria-label={`Receipt ${receiptNumber}`}
        className="print-only-container w-full max-w-[340px] rounded-xl border border-stone-300 bg-white px-4 py-4 font-mono text-[12px] leading-snug text-black shadow-md"
      >
        {/* ==================== PART 1: CUSTOMER COPY ==================== */}
        <div className="mb-2.5 bg-black py-1 text-center text-[11px] font-extrabold tracking-[0.14em] text-white uppercase">
          Customer Copy
        </div>

        <div className="flex flex-col items-center text-center">
          <div className="mb-1">
            <SpizeeLogo size="sm" monochrome logoOverride={settings?.logoUrl} />
          </div>
          {settings?.phone && (
            <p className="text-[11px] font-bold text-black tabular-nums">
              Mobile: {settings.phone}
            </p>
          )}
          {settings?.address && (
            <p className="mt-0.5 text-[10px] text-black">{settings.address}</p>
          )}
        </div>

        <hr className="my-2 border-dashed border-black" />

        <dl className="space-y-1 text-[11px]">
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Order #:</dt>
            <dd className="tabular-nums text-right">
              #{order.orderNumber} ({order.source.toUpperCase()})
            </dd>
          </div>
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Date:</dt>
            <dd className="tabular-nums text-right">{dhaka.dateStr}</dd>
          </div>
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Time:</dt>
            <dd className="tabular-nums text-right">{dhaka.timeStr}</dd>
          </div>
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Type:</dt>
            <dd className="text-right">{orderTypeLabel}</dd>
          </div>
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Status:</dt>
            <dd className="font-bold uppercase text-right">{statusLabel}</dd>
          </div>
          {order.customerPhone && (
            <div className="flex justify-between gap-2">
              <dt className="font-bold">Mobile:</dt>
              <dd className="tabular-nums text-right">{order.customerPhone}</dd>
            </div>
          )}
        </dl>

        {order.orderType === 'home_delivery' && order.deliveryAddress && (
          <div className="mt-2 border-t border-dashed border-black pt-1.5 text-[10.5px]">
            <p className="font-bold">Delivery Address:</p>
            <p className="mt-0.5 break-words">{order.deliveryAddress}</p>
          </div>
        )}

        <hr className="my-2 border-dashed border-black" />

        <table className="w-full text-left text-[11px]">
          <thead>
            <tr className="border-b border-dashed border-black">
              <th className="pb-1 font-bold">Item</th>
              <th className="pb-1 text-center font-bold">Qty</th>
              <th className="pb-1 text-right font-bold">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-dotted divide-stone-400">
            {order.items.map((item) => (
              <tr key={item.id}>
                <td className="py-1 pr-2 align-top">
                  <div className="font-semibold">{item.productName}</div>
                  <div className="text-[10px] tabular-nums">
                    {item.sizeLabel ? `${item.sizeLabel} · ` : ''}
                    {formatBdt(item.unitPrice)} each
                  </div>
                </td>
                <td className="py-1 text-center align-top tabular-nums">{item.quantity}</td>
                <td className="py-1 text-right align-top font-semibold tabular-nums">
                  {formatBdt(item.lineTotal)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <hr className="my-2 border-dashed border-black" />

        <div className="space-y-1 text-[11.5px] tabular-nums">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>{formatBdt(order.subtotal)}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between">
              <span>Discount</span>
              <span>-{formatBdt(order.discount)}</span>
            </div>
          )}
          <div className="mt-1.5 flex justify-between border-t border-black pt-1.5 text-[14px] font-bold">
            <span>TOTAL</span>
            <span>{formatBdt(order.totalAmount)}</span>
          </div>
          <div className="flex justify-between text-[10.5px]">
            <span>Payment</span>
            <span className="uppercase">{order.paymentMethod || 'CASH'}</span>
          </div>
        </div>

        <hr className="my-2 border-dashed border-black" />

        <div className="text-center text-[10.5px]">
          <p className="font-bold">Thank you for ordering from {settings?.restaurantName || 'SPIZEE'}!</p>
        </div>

        {/* ==================== TEAR-OFF / CUT LINE (SAME PAGE) ==================== */}
        <div className="my-3.5 py-0.5" aria-label="Tear-off cut line between customer copy and kitchen copy">
          <div className="border-t-2 border-dashed border-black" />
          <div className="my-1 flex items-center justify-center gap-1.5 text-[10px] font-extrabold tracking-widest text-black uppercase">
            <Scissors className="h-3.5 w-3.5" aria-hidden />
            <span>CUT / TEAR HERE</span>
            <Scissors className="h-3.5 w-3.5 -scale-x-100" aria-hidden />
          </div>
          <div className="border-t-2 border-dashed border-black" />
        </div>

        {/* ==================== PART 2: KITCHEN COPY ==================== */}
        <div className="mb-2 bg-black py-1 text-center text-[11px] font-extrabold tracking-[0.14em] text-white uppercase">
          Kitchen Copy
        </div>

        <div className="flex flex-col items-center text-center">
          <div className="mb-1">
            <SpizeeLogo size="sm" monochrome logoOverride={settings?.logoUrl} />
          </div>
          {settings?.phone && (
            <p className="text-[10.5px] font-bold text-black tabular-nums">
              Mobile: {settings.phone}
            </p>
          )}
        </div>

        <dl className="mt-2 space-y-1 text-[11px]">
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Order #:</dt>
            <dd className="font-extrabold tabular-nums text-right">
              #{order.orderNumber} ({order.source.toUpperCase()})
            </dd>
          </div>
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Date:</dt>
            <dd className="tabular-nums text-right">{dhaka.dateStr}</dd>
          </div>
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Time:</dt>
            <dd className="tabular-nums text-right">{dhaka.timeStr}</dd>
          </div>
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Type:</dt>
            <dd className="font-bold text-right">{orderTypeLabel}</dd>
          </div>
          <div className="flex justify-between gap-2">
            <dt className="font-bold">Status:</dt>
            <dd className="font-bold uppercase text-right">{statusLabel}</dd>
          </div>
          {order.customerPhone && (
            <div className="flex justify-between gap-2">
              <dt className="font-bold">Mobile:</dt>
              <dd className="tabular-nums text-right">{order.customerPhone}</dd>
            </div>
          )}
        </dl>

        <hr className="my-2 border-dashed border-black" />

        <table className="w-full text-left text-[11.5px]">
          <thead>
            <tr className="border-b border-dashed border-black text-[10.5px]">
              <th className="w-10 pb-1 font-bold">Qty</th>
              <th className="pb-1 font-bold">Kitchen Prep Item</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-dotted divide-stone-400">
            {order.items.map((item) => (
              <tr key={`kitchen-${item.id}`}>
                <td className="py-1.5 pr-2 align-top text-[13px] font-extrabold tabular-nums">
                  {item.quantity}x
                </td>
                <td className="py-1.5 align-top">
                  <div className="font-bold">{item.productName}</div>
                  {item.sizeLabel && (
                    <div className="text-[10.5px] font-semibold">[{item.sizeLabel}]</div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {order.notes && order.notes.trim() && (
          <div className="mt-2 border border-black px-2.5 py-1.5 text-[11px] font-bold">
            NOTE: {order.notes.trim()}
          </div>
        )}

        <hr className="my-2 border-dashed border-black" />

        <div className="flex justify-between text-[12px] font-extrabold tabular-nums">
          <span>Total Items: {totalQty}</span>
          <span>{formatBdt(order.totalAmount)}</span>
        </div>
      </article>
    </div>
  );
};
