import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Minus, Plus, ShoppingBag, X, Zap } from 'lucide-react';
import type { Product } from '../types';
import { useApp } from '../context/AppContext';
import { computeEffectivePrice, formatBdt } from '../utils/orderMath';
import { FoodImage } from './FoodImage';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({ product, onClose }) => {
  const { offers, addToCart, setBuyNowItem } = useApp();
  const navigate = useNavigate();

  const sortedSizes = useMemo(
    () => (product ? [...product.sizes].sort((a, b) => a.sortOrder - b.sortOrder) : []),
    [product]
  );

  const [selectedSizeId, setSelectedSizeId] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (product) {
      setSelectedSizeId(sortedSizes.length > 0 ? sortedSizes[0].id : null);
      setQuantity(1);
    }
  }, [product, sortedSizes]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (product) window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [product, onClose]);

  if (!product) return null;

  const activeSize = sortedSizes.find((s) => s.id === selectedSizeId) || sortedSizes[0] || null;
  const priced = computeEffectivePrice(
    {
      productId: product.id,
      basePrice: product.basePrice,
      discountPrice: product.discountPrice,
      sizePrice: activeSize ? activeSize.price : null,
      sizeDiscountPrice: activeSize ? activeSize.discountPrice : null,
      quantity,
    },
    offers
  );

  const hasDiscount = priced.effectiveUnitPrice < priced.originalUnitPrice;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="product-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/35 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="glass-surface relative grid w-full max-w-3xl overflow-hidden rounded-3xl bg-white/95 shadow-2xl md:grid-cols-2"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close product details"
          className="absolute right-4 top-4 z-10 inline-flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-[#1C1917] shadow-sm transition hover:bg-[#F5B800]"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="relative aspect-[4/3] bg-[#FAF6EA] md:aspect-auto md:h-full">
          <FoodImage
            src={product.imageUrl}
            alt={product.name}
            className="h-full w-full object-cover"
          />
        </div>

        <div className="flex flex-col p-6 sm:p-7">
          <div className="flex items-center gap-2 text-xs font-medium text-stone-500">
            <span>{product.categoryName || 'Menu'}</span>
            {priced.appliedOfferTitle && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-[#B47B00]">{priced.appliedOfferTitle}</span>
              </>
            )}
          </div>

          <h2
            id="product-modal-title"
            className="mt-1 font-display text-2xl font-bold text-[#1C1917]"
          >
            {product.name}
          </h2>

          {product.description && (
            <p className="mt-2.5 text-sm leading-relaxed text-stone-600">{product.description}</p>
          )}

          {sortedSizes.length > 0 && (
            <div className="mt-5">
              <p className="text-xs font-semibold text-stone-600">Select Size</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {sortedSizes.map((sz) => {
                  const active = (activeSize?.id ?? null) === sz.id;
                  const szPriced = computeEffectivePrice(
                    {
                      productId: product.id,
                      basePrice: product.basePrice,
                      discountPrice: product.discountPrice,
                      sizePrice: sz.price,
                      sizeDiscountPrice: sz.discountPrice,
                      quantity: 1,
                    },
                    offers
                  );
                  return (
                    <button
                      key={sz.id}
                      type="button"
                      onClick={() => setSelectedSizeId(sz.id)}
                      className={`rounded-xl border px-3 py-2 text-xs font-semibold transition tabular-nums ${
                        active
                          ? 'border-[#1C1917] bg-[#1C1917] text-white'
                          : 'border-stone-200 bg-white text-stone-800 hover:border-[#F5B800] hover:bg-[#FFF9E6]'
                      }`}
                    >
                      {sz.label} · {formatBdt(szPriced.effectiveUnitPrice)}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="mt-5 flex items-center justify-between border-y border-stone-200/80 py-4">
            <div>
              <span className="block text-xs text-stone-500">Total Price</span>
              <div className="mt-0.5 flex items-baseline gap-2 tabular-nums">
                <span className="font-mono text-2xl font-bold text-[#1C1917]">
                  {formatBdt(priced.lineSubtotal)}
                </span>
                {hasDiscount && (
                  <span className="font-mono text-sm text-stone-400 line-through">
                    {formatBdt(priced.originalUnitPrice * quantity)}
                  </span>
                )}
              </div>
            </div>

            <div className="inline-flex items-center rounded-xl border border-stone-200 bg-stone-50 p-1">
              <button
                type="button"
                aria-label="Decrease quantity"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-stone-700 hover:bg-white"
              >
                <Minus className="h-3.5 w-3.5" />
              </button>
              <span className="w-9 text-center font-mono text-sm font-bold tabular-nums">
                {quantity}
              </span>
              <button
                type="button"
                aria-label="Increase quantity"
                onClick={() => setQuantity((q) => Math.min(50, q + 1))}
                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-stone-700 hover:bg-white"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3">
            <button
              type="button"
              disabled={!product.isAvailable}
              onClick={() => {
                addToCart(product.id, activeSize ? activeSize.id : null, quantity, true);
                onClose();
              }}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#F5B800] px-4 py-3 text-sm font-bold text-[#1C1917] transition hover:bg-[#E0A700] disabled:bg-stone-200 disabled:text-stone-500 whitespace-nowrap"
            >
              <ShoppingBag className="h-4 w-4" />
              {product.isAvailable ? 'Add to Cart' : 'Sold Out'}
            </button>
            <button
              type="button"
              disabled={!product.isAvailable}
              onClick={() => {
                setBuyNowItem({
                  productId: product.id,
                  sizeId: activeSize ? activeSize.id : null,
                  quantity,
                });
                onClose();
                navigate('/checkout');
              }}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#1C1917] px-4 py-3 text-sm font-semibold text-white transition hover:bg-stone-800 disabled:opacity-50 whitespace-nowrap"
            >
              <Zap className="h-4 w-4" />
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
