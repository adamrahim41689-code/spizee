import React, { useEffect, useState } from 'react';
import { UtensilsCrossed } from 'lucide-react';
import { resolveMediaUrl } from '../lib/api';

interface FoodImageProps {
  src?: string | null;
  alt: string;
  className?: string;
}

export const FoodImage: React.FC<FoodImageProps> = ({ src, alt, className = '' }) => {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  if (!src || failed) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#FFF5CC] via-[#FFFDF7] to-[#F5EFE0] text-stone-500 ${className}`}
      >
        <UtensilsCrossed className="h-8 w-8 text-[#D99B00] opacity-75" />
        <span className="mt-2 px-3 text-center text-xs font-medium text-stone-500 line-clamp-1">
          {alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={resolveMediaUrl(src)}
      decoding="async"
      alt={alt}
      referrerPolicy="no-referrer"
      loading="lazy"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};
