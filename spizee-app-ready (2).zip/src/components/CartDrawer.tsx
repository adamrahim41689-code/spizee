import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { computeEffectivePrice, formatBdt } from '../utils/orderMath';
import { FoodImage } from './FoodImage';

export const CartDrawer: React.FC = () => {
  const {
    cartOpen,
    setCartOpen,
    cartItems,
    cartSubtotal,
    products,
    offers,
    updateCartQty,
    changeCartSize,
    removeFromCart,
    setBuyNowItem,
  } = useApp();
  const navigate = useNavigate();

  if (!cartOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Shopping cart"
      className="no-print fixed inset-0 z-50 flex justify-end bg-stone-900/35 backdrop-blur-xs"
      onClick={() => setCartOpen(false)}
    >
      <div
        className="flex h-full w-full max-w-md flex-col bg-[#FFFDF7] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-stone-200 px-6 py-4">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="h-5 w-5 text-[#D99B00]" />
            <h2 className="font-display text-lg font-bold text-[#1C1917]">Your Cart</h2>
          </div>
          <button
            type="button"
            onClick={() => setCartOpen(false)}
            aria-label="Close cart drawer"
            className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-stone-600 transition hover:bg-stone-100 hover:text-[#1C1917]"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {cartItems.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center py-12 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#FFF3C4] text-[#B47B00]">
                <ShoppingBag className="h-8 w-8" />
              </div>
              <h3 className="mt-4 font-display text-lg font-bold text-[#1C1917]">
                Your cart is empty
              </h3>
              <p className="mt-1 max-w-xs text-sm text-stone-500">
                Browse crispy fried chicken, burgers, shawarma, and combo boxes to start an order.
              </p>
              <Link
                to="/menu"
                onClick={() => setCartOpen(false)}
                className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#F5B800] px-5 py-2.5 text-sm font-bold text-[#1C1917] transition hover:bg-[#E0A700]"
              >
                Explore Menu
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          ) : (
            <ul className="divide-y divide-stone-200/80">
              {cartItems.map((entry) => {
                const prod = products.find((p) => p.id === entry.productId);
                if (!prod) return null;
                const size = entry.sizeId
                  ? prod.sizes.find((s) => s.id === entry.sizeId)
                  : undefined;
                const priced = computeEffectivePrice(
                  {
                    productId: prod.id,
                    basePrice: prod.basePrice,
                    discountPrice: prod.discountPrice,
                    sizePrice: size ? size.price : null,
                    sizeDiscountPrice: size ? size.discountPrice : null,
                    quantity: entry.quantity,
                  },
                  offers
                );

                return (
                  <li key={`${entry.productId}-${entry.sizeId ?? 'base'}`} className="flex gap-4 py-4">
                    <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-[#FAF6EA]">
                      <FoodImage
                        src={prod.imageUrl}
                        alt={prod.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="truncate font-display text-sm font-bold text-[#1C1917]">
                          {prod.name}
                        </h3>
                        <button
                          type="button"
                          aria-label={`Remove ${prod.name}`}
                          onClick={() => removeFromCart(entry.productId, entry.sizeId)}
                          className="rounded-lg p-1 text-stone-400 transition hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>

                      {prod.sizes.length > 0 && (
                        <div className="mt-1.5">
                          <label className="sr-only">Change size for {prod.name}</label>
                          <select
                            aria-label={`Size for ${prod.name}`}
                            value={entry.sizeId ?? ''}
                            onChange={(e) =>
                              changeCartSize(entry.productId, entry.sizeId, e.target.value || null)
                            }
                            className="rounded-lg border border-stone-200 bg-white px-2 py-1 text-xs font-medium text-stone-700 focus:border-[#F5B800] focus:outline-none"
                          >
                            {prod.sizes.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.label}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}

                      <div className="mt-2.5 flex items-center justify-between">
                        <div className="inline-flex items-center rounded-lg border border-stone-200 bg-white">
                          <button
                            type="button"
                            aria-label={`Decrease quantity of ${prod.name}`}
                            onClick={() =>
                              updateCartQty(entry.productId, entry.sizeId, entry.quantity - 1)
                            }
                            className="inline-flex h-7 w-7 items-center justify-center text-stone-700 hover:bg-stone-100"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="w-7 text-center font-mono text-xs font-bold tabular-nums">
                            {entry.quantity}
                          </span>
                          <button
                            type="button"
                            aria-label={`Increase quantity of ${prod.name}`}
                            onClick={() =>
                              updateCartQty(entry.productId, entry.sizeId, entry.quantity + 1)
                            }
                            className="inline-flex h-7 w-7 items-center justify-center text-stone-700 hover:bg-stone-100"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>

                        <div className="text-right font-mono text-sm font-bold text-[#1C1917] tabular-nums">
                          {formatBdt(priced.lineSubtotal)}
                        </div>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {cartItems.length > 0 && (
          <div className="border-t border-stone-200 bg-white/90 px-6 py-4">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium text-stone-600">Subtotal</span>
              <span className="font-mono text-lg font-bold text-[#1C1917] tabular-nums">
                {formatBdt(cartSubtotal)}
              </span>
            </div>
            <p className="mt-1 text-xs text-stone-500">
              Delivery charge (if applicable) calculated at checkout.
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2.5">
              <Link
                to="/cart"
                onClick={() => setCartOpen(false)}
                className="inline-flex items-center justify-center rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm font-semibold text-[#1C1917] transition hover:bg-stone-50"
              >
                Full Cart
              </Link>
              <button
                type="button"
                onClick={() => {
                  setBuyNowItem(null);
                  setCartOpen(false);
                  navigate('/checkout');
                }}
                className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#F5B800] px-4 py-3 text-sm font-bold text-[#1C1917] transition hover:bg-[#E0A700]"
              >
                Checkout
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
