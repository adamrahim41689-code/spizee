import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, ShoppingBag, Zap } from 'lucide-react';
import type { Product } from '../types';
import { useApp } from '../context/AppContext';
import { computeEffectivePrice, formatBdt } from '../utils/orderMath';
import { FoodImage } from './FoodImage';

interface ProductCardProps {
  product: Product;
  onInspect: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onInspect }) => {
  const { offers, addToCart, setBuyNowItem } = useApp();
  const navigate = useNavigate();

  const sortedSizes = useMemo(
    () => [...product.sizes].sort((a, b) => a.sortOrder - b.sortOrder),
    [product.sizes]
  );

  const [selectedSizeId, setSelectedSizeId] = useState<string | null>(
    sortedSizes.length > 0 ? sortedSizes[0].id : null
  );
  const [justAdded, setJustAdded] = useState(false);
  const addedTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (addedTimerRef.current) window.clearTimeout(addedTimerRef.current);
    };
  }, []);

  const activeSize = sortedSizes.find((s) => s.id === selectedSizeId) || sortedSizes[0] || null;

  const priced = useMemo(
    () =>
      computeEffectivePrice(
        {
          productId: product.id,
          basePrice: product.basePrice,
          discountPrice: product.discountPrice,
          sizePrice: activeSize ? activeSize.price : null,
          sizeDiscountPrice: activeSize ? activeSize.discountPrice : null,
          quantity: 1,
        },
        offers
      ),
    [product, activeSize, offers]
  );

  const hasDiscount = priced.effectiveUnitPrice < priced.originalUnitPrice;

  const kickerParts: string[] = [];
  if (product.categoryName) kickerParts.push(product.categoryName);
  if (!product.isAvailable) {
    kickerParts.push('Sold Out');
  } else if (priced.appliedOfferTitle) {
    kickerParts.push(priced.appliedOfferTitle);
  } else if (product.isNew) {
    kickerParts.push('New');
  } else if (product.isPopular) {
    kickerParts.push('Popular');
  }

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.isAvailable) return;
    addToCart(product.id, activeSize ? activeSize.id : null, 1, false);
    setJustAdded(true);
    if (addedTimerRef.current) window.clearTimeout(addedTimerRef.current);
    addedTimerRef.current = window.setTimeout(() => setJustAdded(false), 900);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!product.isAvailable) return;
    setBuyNowItem({
      productId: product.id,
      sizeId: activeSize ? activeSize.id : null,
      quantity: 1,
    });
    navigate('/checkout');
  };

  return (
    <article
      className={`glass-surface group flex flex-col overflow-hidden rounded-xl transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg sm:rounded-2xl ${
        !product.isAvailable ? 'opacity-75' : ''
      }`}
    >
      <button
        type="button"
        onClick={() => onInspect(product)}
        aria-label={`View details for ${product.name}`}
        className="relative aspect-square w-full overflow-hidden bg-[#FAF6EA] text-left focus-visible:outline-2 focus-visible:outline-[#F5B800] sm:aspect-[4/3]"
      >
        <FoodImage
          src={product.imageUrl}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
        />
        {!product.isAvailable && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/70 backdrop-blur-[2px]">
            <span className="font-display text-[10px] font-bold tracking-wide text-[#1C1917] sm:text-sm">
              Sold Out
            </span>
          </div>
        )}
      </button>

      <div className="flex flex-1 flex-col p-2 sm:p-5">
        <div className="hidden items-center gap-1.5 text-xs font-medium text-stone-500 sm:flex">
          {kickerParts.map((part, idx) => (
            <React.Fragment key={part}>
              {idx > 0 && <span aria-hidden="true">·</span>}
              <span
                className={
                  part === 'Sold Out'
                    ? 'font-semibold text-red-700'
                    : idx === 1
                    ? 'font-semibold text-[#B47B00]'
                    : ''
                }
              >
                {part}
              </span>
            </React.Fragment>
          ))}
        </div>

        <button
          type="button"
          onClick={() => onInspect(product)}
          className="line-clamp-2 min-h-[28px] text-left font-display text-[11px] font-bold leading-tight text-[#1C1917] transition-colors hover:text-[#B47B00] focus-visible:outline-2 focus-visible:outline-[#F5B800] sm:mt-1.5 sm:min-h-0 sm:line-clamp-none sm:text-lg sm:leading-snug"
        >
          {product.name}
        </button>

        {product.description && (
          <p className="mt-1.5 hidden line-clamp-2 text-sm leading-relaxed text-stone-600 sm:block">
            {product.description}
          </p>
        )}

        {sortedSizes.length > 0 && (
          <div className="mt-1.5 sm:mt-4">
            <span className="sr-only">Choose size for {product.name}</span>
            {/* Mobile compact size selector for 3-column grid */}
            <select
              aria-label={`Select size for ${product.name}`}
              value={activeSize?.id ?? ''}
              onChange={(e) => setSelectedSizeId(e.target.value)}
              className="w-full truncate rounded-md border border-stone-200 bg-stone-50 px-1 py-0.5 text-[10px] font-semibold text-stone-700 focus:border-[#F5B800] focus:outline-none sm:hidden"
            >
              {sortedSizes.map((sz) => (
                <option key={sz.id} value={sz.id}>
                  {sz.label}
                </option>
              ))}
            </select>

            {/* Desktop inline size buttons */}
            <div className="hidden flex-wrap gap-1.5 sm:flex">
              {sortedSizes.map((sz) => {
                const active = (activeSize?.id ?? null) === sz.id;
                return (
                  <button
                    key={sz.id}
                    type="button"
                    onClick={() => setSelectedSizeId(sz.id)}
                    className={`rounded-lg px-2.5 py-1.5 text-xs font-semibold transition whitespace-nowrap ${
                      active
                        ? 'bg-[#1C1917] text-white shadow-xs'
                        : 'bg-stone-100 text-stone-700 hover:bg-[#FFF3C4] hover:text-[#1C1917]'
                    }`}
                  >
                    {sz.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        <div className="mt-auto pt-1.5 sm:pt-4">
          <div className="flex flex-wrap items-baseline gap-1 tabular-nums sm:gap-2">
            <span className="font-mono text-xs font-bold text-[#1C1917] sm:text-lg">
              {formatBdt(priced.effectiveUnitPrice)}
            </span>
            {hasDiscount && (
              <span className="font-mono text-[10px] text-stone-400 line-through sm:text-sm">
                {formatBdt(priced.originalUnitPrice)}
              </span>
            )}
          </div>

          <div className="mt-1.5 grid grid-cols-1 gap-1 sm:mt-3 sm:grid-cols-2 sm:gap-2">
            <button
              type="button"
              disabled={!product.isAvailable}
              onClick={handleAdd}
              className={`inline-flex items-center justify-center gap-1 rounded-lg px-1.5 py-1.5 text-[10px] font-bold transition active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-stone-200 disabled:text-stone-500 whitespace-nowrap sm:gap-1.5 sm:rounded-xl sm:px-3 sm:py-2.5 sm:text-xs ${
                justAdded
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#F5B800] text-[#1C1917] hover:bg-[#E0A700]'
              }`}
            >
              {justAdded ? (
                <Check className="h-3.5 w-3.5 shrink-0 sm:h-4 sm:w-4" aria-label="Added" />
              ) : (
                <>
                  <ShoppingBag className="h-3 w-3 shrink-0 sm:h-3.5 sm:w-3.5" />
                  <span className="sm:hidden">{product.isAvailable ? 'Add' : 'Out'}</span>
                  <span className="hidden sm:inline">
                    {product.isAvailable ? 'Add to Cart' : 'Sold Out'}
                  </span>
                </>
              )}
            </button>
            <button
              type="button"
              disabled={!product.isAvailable}
              onClick={handleBuyNow}
              className="inline-flex items-center justify-center gap-1 rounded-lg border border-stone-300 bg-white px-1.5 py-1 text-[10px] font-semibold text-[#1C1917] transition hover:border-[#1C1917] hover:bg-stone-50 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap sm:gap-1.5 sm:rounded-xl sm:px-3 sm:py-2.5 sm:text-xs"
            >
              <Zap className="h-3 w-3 shrink-0 sm:h-3.5 sm:w-3.5" />
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </article>
  );
};
