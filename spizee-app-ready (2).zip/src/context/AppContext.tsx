import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  onAuthStateChanged,
  onIdTokenChanged,
  signInWithPopup,
  signOut as fbSignOut,
} from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase';
import {
  apiFetch,
  getStoredEmailToken,
  setEmailSessionToken,
  setMemoryFirebaseToken,
} from '../lib/api';
import type {
  Banner,
  CartItemEntry,
  Category,
  Offer,
  Product,
  SiteSettings,
  UserProfile,
} from '../types';
import { computeEffectivePrice, mergeCartEntries } from '../utils/orderMath';

const GUEST_CART_KEY = 'spizee_guest_cart_v1';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

export interface ConfirmOptions {
  title: string;
  message: string;
  confirmLabel?: string;
  destructive?: boolean;
}

interface AppContextValue {
  settings: SiteSettings | null;
  categories: Category[];
  products: Product[];
  banners: Banner[];
  offers: Offer[];
  catalogLoading: boolean;
  catalogError: string | null;
  refreshCatalog: () => Promise<void>;

  user: UserProfile | null;
  authLoading: boolean;
  signInWithEmail: (email: string, password: string) => Promise<UserProfile>;
  signUpWithEmail: (payload: {
    fullName: string;
    email: string;
    phone?: string;
    address?: string;
    password: string;
  }) => Promise<UserProfile>;
  signInWithGoogle: () => Promise<UserProfile>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;

  cartItems: CartItemEntry[];
  cartCount: number;
  cartSubtotal: number;
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  addToCart: (productId: string, sizeId: string | null, quantity?: number, openDrawer?: boolean) => void;
  updateCartQty: (productId: string, sizeId: string | null, quantity: number) => void;
  changeCartSize: (productId: string, oldSizeId: string | null, newSizeId: string | null) => void;
  removeFromCart: (productId: string, sizeId: string | null) => void;
  clearCart: () => void;

  buyNowItem: CartItemEntry | null;
  setBuyNowItem: (item: CartItemEntry | null) => void;

  toasts: ToastMessage[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;

  confirmState: (ConfirmOptions & { resolve: (val: boolean) => void }) | null;
  requestConfirm: (options: ConfirmOptions) => Promise<boolean>;
  resolveConfirm: (val: boolean) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

function loadGuestCart(): CartItemEntry[] {
  try {
    const raw = localStorage.getItem(GUEST_CART_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveGuestCart(items: CartItemEntry[]) {
  try {
    localStorage.setItem(GUEST_CART_KEY, JSON.stringify(items));
  } catch {
    // Ignore storage error
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [catalogLoading, setCatalogLoading] = useState(true);
  const [catalogError, setCatalogError] = useState<string | null>(null);

  const [user, setUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  const [cartItems, setCartItems] = useState<CartItemEntry[]>(() => loadGuestCart());
  const [cartOpen, setCartOpen] = useState(false);
  const [buyNowItem, setBuyNowItem] = useState<CartItemEntry | null>(null);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [confirmState, setConfirmState] = useState<
    (ConfirmOptions & { resolve: (val: boolean) => void }) | null
  >(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-3), { id, type, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3600);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const requestConfirm = useCallback((options: ConfirmOptions) => {
    return new Promise<boolean>((resolve) => {
      setConfirmState({ ...options, resolve });
    });
  }, []);

  const resolveConfirm = useCallback(
    (val: boolean) => {
      if (confirmState) {
        confirmState.resolve(val);
        setConfirmState(null);
      }
    },
    [confirmState]
  );

  const refreshCatalog = useCallback(async () => {
    try {
      setCatalogError(null);
      const data = await apiFetch<{
        settings: SiteSettings;
        categories: Category[];
        products: Product[];
        banners: Banner[];
        offers: Offer[];
      }>('/api/public/bootstrap');
      setSettings(data.settings);
      setCategories(data.categories);
      setProducts(data.products);
      setBanners(data.banners);
      setOffers(data.offers);

      if (data.settings?.logoUrl) {
        const link = document.querySelector<HTMLLinkElement>("link[rel='icon']");
        if (link) link.href = data.settings.logoUrl;
      }
    } catch (err: any) {
      setCatalogError(err.message || 'Unable to load menu right now.');
    } finally {
      setCatalogLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshCatalog();
  }, [refreshCatalog]);

  // Automatically reconcile cart & buy-now items if admin edited/removed a product or size
  useEffect(() => {
    if (products.length === 0) return;
    const prodMap = new Map(products.map((p) => [p.id, p]));

    setCartItems((prev) => {
      let changed = false;
      const next: CartItemEntry[] = [];
      for (const item of prev) {
        const prod = prodMap.get(item.productId);
        if (!prod) {
          changed = true;
          continue;
        }
        const validSize = item.sizeId ? prod.sizes.find((s) => s.id === item.sizeId) : undefined;
        const resolvedSizeId = validSize ? validSize.id : prod.sizes[0]?.id ?? null;
        if (resolvedSizeId !== (item.sizeId ?? null)) {
          changed = true;
        }
        const existingIdx = next.findIndex(
          (x) => x.productId === item.productId && (x.sizeId ?? null) === resolvedSizeId
        );
        if (existingIdx >= 0) {
          next[existingIdx] = {
            ...next[existingIdx],
            quantity: Math.min(99, next[existingIdx].quantity + item.quantity),
          };
          changed = true;
        } else {
          next.push({ productId: item.productId, sizeId: resolvedSizeId, quantity: item.quantity });
        }
      }
      if (changed) {
        saveGuestCart(next);
        return next;
      }
      return prev;
    });

    setBuyNowItem((prev) => {
      if (!prev) return prev;
      const prod = prodMap.get(prev.productId);
      if (!prod) return null;
      const validSize = prev.sizeId ? prod.sizes.find((s) => s.id === prev.sizeId) : undefined;
      const resolvedSizeId = validSize ? validSize.id : prod.sizes[0]?.id ?? null;
      if (resolvedSizeId === (prev.sizeId ?? null)) return prev;
      return { ...prev, sizeId: resolvedSizeId };
    });
  }, [products]);

  const mergeAndSyncCartOnLogin = useCallback(async (token?: string | null) => {
    try {
      const guest = loadGuestCart();
      const res = await apiFetch<{ items: CartItemEntry[] }>('/api/cart/merge', {
        method: 'POST',
        token,
        body: JSON.stringify({ items: guest }),
      });
      const synced = res.items.map((i) => ({
        productId: i.productId,
        sizeId: i.sizeId ?? null,
        quantity: i.quantity,
      }));
      setCartItems(synced);
      saveGuestCart([]);
    } catch {
      // Fallback safely
    }
  }, []);

  // Initialize auth state from email token or Firebase Auth listener
  useEffect(() => {
    let active = true;
    const initialStoredToken = getStoredEmailToken();
    let emailInitDone = !initialStoredToken;
    let fbInitDone = false;

    const finishIfReady = () => {
      if (active && emailInitDone && fbInitDone) {
        setAuthLoading(false);
      }
    };

    const initEmailToken = async () => {
      if (!initialStoredToken) return;
      try {
        const data = await apiFetch<{ profile: UserProfile }>('/api/auth/me', {
          token: initialStoredToken,
        });
        if (active && data.profile) {
          setUser(data.profile);
          await mergeAndSyncCartOnLogin(initialStoredToken);
          emailInitDone = true;
          if (active) setAuthLoading(false);
          return;
        }
      } catch {
        setEmailSessionToken(null);
        if (active) setUser(null);
      } finally {
        emailInitDone = true;
        finishIfReady();
      }
    };

    initEmailToken();

    const unsubToken = onIdTokenChanged(auth, async (fbUser) => {
      if (!active) return;
      if (getStoredEmailToken()) return;
      if (fbUser) {
        try {
          const fresh = await fbUser.getIdToken();
          if (active) setMemoryFirebaseToken(fresh);
        } catch {
          // Ignore transient refresh failure; apiFetch will force-refresh on demand
        }
      } else {
        setMemoryFirebaseToken(null);
      }
    });

    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      if (!active) return;
      // Do not allow an older Firebase browser session to overwrite an active Email/Password login
      if (getStoredEmailToken()) {
        fbInitDone = true;
        finishIfReady();
        return;
      }
      if (fbUser) {
        try {
          let idToken = await fbUser.getIdToken();
          setMemoryFirebaseToken(idToken);
          let data: { profile: UserProfile };
          try {
            data = await apiFetch<{ profile: UserProfile }>('/api/auth/firebase-sync', {
              method: 'POST',
              token: idToken,
            });
          } catch {
            // Force-refresh ID token if cached browser token was expired
            idToken = await fbUser.getIdToken(true);
            setMemoryFirebaseToken(idToken);
            data = await apiFetch<{ profile: UserProfile }>('/api/auth/firebase-sync', {
              method: 'POST',
              token: idToken,
            });
          }
          if (active && data.profile && !getStoredEmailToken()) {
            setUser(data.profile);
            await mergeAndSyncCartOnLogin(idToken);
          }
        } catch (err) {
          console.error('Firebase auth sync failed:', err);
        } finally {
          fbInitDone = true;
          if (active) setAuthLoading(false);
        }
      } else {
        setMemoryFirebaseToken(null);
        if (!getStoredEmailToken()) {
          setUser(null);
        }
        fbInitDone = true;
        finishIfReady();
      }
    });

    return () => {
      active = false;
      unsub();
      unsubToken();
    };
  }, [mergeAndSyncCartOnLogin]);

  const persistCart = useCallback(
    (next: CartItemEntry[]) => {
      setCartItems(next);
      if (user) {
        apiFetch('/api/cart', {
          method: 'PUT',
          body: JSON.stringify({ items: next }),
        }).catch(() => {});
      } else {
        saveGuestCart(next);
      }
    },
    [user]
  );

  const addToCart = useCallback(
    (productId: string, sizeId: string | null, quantity = 1, openDrawer = false) => {
      const next = mergeCartEntries(cartItems, [{ productId, sizeId, quantity }]);
      persistCart(next);
      if (openDrawer) setCartOpen(true);
    },
    [cartItems, persistCart]
  );

  const updateCartQty = useCallback(
    (productId: string, sizeId: string | null, quantity: number) => {
      const next =
        quantity <= 0
          ? cartItems.filter((i) => !(i.productId === productId && i.sizeId === sizeId))
          : cartItems.map((i) =>
              i.productId === productId && i.sizeId === sizeId
                ? { ...i, quantity: Math.min(50, quantity) }
                : i
            );
      persistCart(next);
    },
    [cartItems, persistCart]
  );

  const changeCartSize = useCallback(
    (productId: string, oldSizeId: string | null, newSizeId: string | null) => {
      if (oldSizeId === newSizeId) return;
      const target = cartItems.find((i) => i.productId === productId && i.sizeId === oldSizeId);
      if (!target) return;
      const withoutOld = cartItems.filter(
        (i) => !(i.productId === productId && i.sizeId === oldSizeId)
      );
      const next = mergeCartEntries(withoutOld, [
        { productId, sizeId: newSizeId, quantity: target.quantity },
      ]);
      persistCart(next);
    },
    [cartItems, persistCart]
  );

  const removeFromCart = useCallback(
    (productId: string, sizeId: string | null) => {
      const next = cartItems.filter((i) => !(i.productId === productId && i.sizeId === sizeId));
      persistCart(next);
      showToast('Item removed from cart', 'info');
    },
    [cartItems, persistCart, showToast]
  );

  const clearCart = useCallback(() => {
    persistCart([]);
  }, [persistCart]);

  const signInWithEmail = useCallback(
    async (email: string, password: string) => {
      const data = await apiFetch<{ token: string; profile: UserProfile }>('/api/auth/login', {
        method: 'POST',
        token: null,
        body: JSON.stringify({ email, password }),
      });
      // Clear any previous Google Firebase session so it cannot override this login
      setMemoryFirebaseToken(null);
      setEmailSessionToken(data.token);
      try {
        await fbSignOut(auth);
      } catch {
        // Ignore if not signed into Firebase
      }
      setUser(data.profile);
      await mergeAndSyncCartOnLogin(data.token);
      return data.profile;
    },
    [mergeAndSyncCartOnLogin]
  );

  const signUpWithEmail = useCallback(
    async (payload: {
      fullName: string;
      email: string;
      phone?: string;
      address?: string;
      password: string;
    }) => {
      const data = await apiFetch<{ token: string; profile: UserProfile }>('/api/auth/signup', {
        method: 'POST',
        token: null,
        body: JSON.stringify(payload),
      });
      // Clear any previous Google Firebase session so it cannot override this signup
      setMemoryFirebaseToken(null);
      setEmailSessionToken(data.token);
      try {
        await fbSignOut(auth);
      } catch {
        // Ignore if not signed into Firebase
      }
      setUser(data.profile);
      await mergeAndSyncCartOnLogin(data.token);
      return data.profile;
    },
    [mergeAndSyncCartOnLogin]
  );

  const signInWithGoogle = useCallback(async () => {
    const cred = await signInWithPopup(auth, googleAuthProvider);
    const idToken = await cred.user.getIdToken(true);
    // Clear any previous email/password session token so Google session is sole active auth
    setEmailSessionToken(null);
    setMemoryFirebaseToken(idToken);
    const data = await apiFetch<{ profile: UserProfile }>('/api/auth/firebase-sync', {
      method: 'POST',
      token: idToken,
    });
    setUser(data.profile);
    await mergeAndSyncCartOnLogin(idToken);
    return data.profile;
  }, [mergeAndSyncCartOnLogin]);

  const logout = useCallback(async () => {
    setEmailSessionToken(null);
    setMemoryFirebaseToken(null);
    try {
      await fbSignOut(auth);
    } catch {
      // Ignore if not signed into Firebase
    }
    setUser(null);
    setCartItems(loadGuestCart());
    showToast('Signed out successfully', 'info');
  }, [showToast]);

  const refreshProfile = useCallback(async () => {
    try {
      const data = await apiFetch<{ profile: UserProfile }>('/api/auth/me');
      if (data.profile) setUser(data.profile);
    } catch {
      // Ignore
    }
  }, []);

  // Keep user role (e.g. newly granted Admin/Manager access) fresh when returning to tab
  useEffect(() => {
    if (!user) return;
    const onFocus = () => {
      refreshProfile();
    };
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, [user, refreshProfile]);

  const cartCount = useMemo(
    () => cartItems.reduce((sum, i) => sum + i.quantity, 0),
    [cartItems]
  );

  const cartSubtotal = useMemo(() => {
    return cartItems.reduce((sum, entry) => {
      const prod = products.find((p) => p.id === entry.productId);
      if (!prod) return sum;
      const size = entry.sizeId ? prod.sizes.find((s) => s.id === entry.sizeId) : undefined;
      const priced = computeEffectivePrice(
        {
          productId: prod.id,
          basePrice: prod.basePrice,
          discountPrice: prod.discountPrice,
          sizePrice: size ? size.price : null,
          sizeDiscountPrice: size ? size.discountPrice : null,
          quantity: entry.quantity,
        },
        offers
      );
      return sum + priced.lineSubtotal;
    }, 0);
  }, [cartItems, products, offers]);

  const value: AppContextValue = {
    settings,
    categories,
    products,
    banners,
    offers,
    catalogLoading,
    catalogError,
    refreshCatalog,
    user,
    authLoading,
    signInWithEmail,
    signUpWithEmail,
    signInWithGoogle,
    logout,
    refreshProfile,
    cartItems,
    cartCount,
    cartSubtotal,
    cartOpen,
    setCartOpen,
    addToCart,
    updateCartQty,
    changeCartSize,
    removeFromCart,
    clearCart,
    buyNowItem,
    setBuyNowItem,
    toasts,
    showToast,
    dismissToast,
    confirmState,
    requestConfirm,
    resolveConfirm,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
