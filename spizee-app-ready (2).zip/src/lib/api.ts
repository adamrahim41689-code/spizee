import { auth } from './firebase';

const SESSION_TOKEN_KEY = 'spizee_session_token';

// In the browser (served by our own backend) this is '' (same origin).
// In the Android app, set VITE_API_URL=https://your-backend.onrender.com at build time.
export const API_BASE: string = ((import.meta as any).env?.VITE_API_URL || '').replace(/\/+$/, '');

/** Prefix backend-served media (/uploads/...) with the API base so images work inside the app. */
export function resolveMediaUrl(url?: string | null): string {
  if (!url) return '';
  if (API_BASE && url.startsWith('/uploads/')) return `${API_BASE}${url}`;
  return url;
}
let memoryFirebaseToken: string | null = null;

export function setMemoryFirebaseToken(token: string | null) {
  memoryFirebaseToken = token;
}

export function setEmailSessionToken(token: string | null) {
  try {
    if (token) {
      localStorage.setItem(SESSION_TOKEN_KEY, token);
      sessionStorage.removeItem(SESSION_TOKEN_KEY);
    } else {
      localStorage.removeItem(SESSION_TOKEN_KEY);
      sessionStorage.removeItem(SESSION_TOKEN_KEY);
    }
  } catch {
    // Ignore storage restriction
  }
}

export function getStoredEmailToken(): string | null {
  try {
    return localStorage.getItem(SESSION_TOKEN_KEY) || sessionStorage.getItem(SESSION_TOKEN_KEY);
  } catch {
    return null;
  }
}

export function getActiveToken(): string | null {
  return getStoredEmailToken() || memoryFirebaseToken;
}

async function resolveFreshToken(forceRefresh = false): Promise<string | null> {
  // If user explicitly signed in with Email + Password, always honor that session
  const emailToken = getStoredEmailToken();
  if (emailToken) {
    return emailToken;
  }
  if (auth.currentUser) {
    try {
      const fresh = await auth.currentUser.getIdToken(forceRefresh);
      memoryFirebaseToken = fresh;
      return fresh;
    } catch {
      // Fall back to cached token if Firebase refresh fails temporarily
    }
  }
  return memoryFirebaseToken;
}

export async function apiFetch<T = any>(
  path: string,
  options: RequestInit & { token?: string | null } = {}
): Promise<T> {
  const { token, headers, ...rest } = options;

  const execute = async (authToken: string | null) => {
    const mergedHeaders: Record<string, string> = {
      ...(headers as Record<string, string>),
    };

    if (!(rest.body instanceof FormData) && !mergedHeaders['Content-Type']) {
      mergedHeaders['Content-Type'] = 'application/json';
    }
    if (authToken) {
      mergedHeaders['Authorization'] = `Bearer ${authToken}`;
    }

    return fetch(path.startsWith('/') ? `${API_BASE}${path}` : path, {
      ...rest,
      headers: mergedHeaders,
    });
  };

  const initialToken = token !== undefined ? token : await resolveFreshToken(false);
  let res = await execute(initialToken);

  // If Firebase token just expired (e.g. tab slept > 1h), force-refresh and retry once
  if (res.status === 401 && token === undefined && auth.currentUser) {
    const refreshedToken = await resolveFreshToken(true);
    if (refreshedToken && refreshedToken !== initialToken) {
      res = await execute(refreshedToken);
    }
  }

  const text = await res.text();
  let json: any = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { error: text || 'Unexpected server response.' };
  }

  if (!res.ok) {
    throw new Error(json.error || `Request failed (${res.status})`);
  }
  return json as T;
}

export async function uploadImageFile(
  bucket: 'product-images' | 'banners' | 'site-assets' | 'avatars',
  file: File
): Promise<string> {
  const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
  if (!allowed.includes(file.type)) {
    throw new Error('Please upload a JPG, PNG, WebP, or GIF image.');
  }
  if (file.size > 5 * 1024 * 1024) {
    throw new Error('Image size must be 5 MB or smaller.');
  }
  const form = new FormData();
  form.append('file', file);
  const data = await apiFetch<{ url: string }>(`/api/upload/${bucket}`, {
    method: 'POST',
    body: form,
  });
  return data.url;
}
