// True when running inside the Capacitor Android/iOS app (not a normal browser).
export const isNativeApp: boolean =
  typeof window !== 'undefined' &&
  !!(window as any).Capacitor &&
  typeof (window as any).Capacitor.isNativePlatform === 'function' &&
  (window as any).Capacitor.isNativePlatform();
