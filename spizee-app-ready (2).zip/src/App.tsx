import { Suspense, lazy } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { PublicLayout } from './components/PublicLayout';
import { FeedbackOverlays } from './components/FeedbackOverlays';
import { HomePage } from './pages/HomePage';

const pick = <T extends Record<string, any>, K extends keyof T>(p: Promise<T>, k: K) =>
  p.then((m) => ({ default: m[k] }));

const MenuPage = lazy(() => pick(import('./pages/MenuPage'), 'MenuPage'));
const AboutPage = lazy(() => pick(import('./pages/AboutContactPage'), 'AboutPage'));
const ContactPage = lazy(() => pick(import('./pages/AboutContactPage'), 'ContactPage'));
const CartPage = lazy(() => pick(import('./pages/CartPage'), 'CartPage'));
const CheckoutPage = lazy(() => pick(import('./pages/CheckoutPage'), 'CheckoutPage'));
const OrderConfirmationPage = lazy(() => pick(import('./pages/OrderConfirmationPage'), 'OrderConfirmationPage'));
const LoginPage = lazy(() => pick(import('./pages/LoginPage'), 'LoginPage'));
const ProfilePage = lazy(() => pick(import('./pages/ProfilePage'), 'ProfilePage'));
const AdminLayout = lazy(() => pick(import('./pages/admin/AdminLayout'), 'AdminLayout'));
const AdminOverview = lazy(() => pick(import('./pages/admin/AdminOverview'), 'AdminOverview'));
const AdminCategoriesPage = lazy(() => pick(import('./pages/admin/AdminCatalogPages'), 'AdminCategoriesPage'));
const AdminProductsPage = lazy(() => pick(import('./pages/admin/AdminCatalogPages'), 'AdminProductsPage'));
const AdminSizesPage = lazy(() => pick(import('./pages/admin/AdminCatalogPages'), 'AdminSizesPage'));
const AdminOrdersPage = lazy(() => pick(import('./pages/admin/AdminOrdersPosPages'), 'AdminOrdersPage'));
const AdminPosPage = lazy(() => pick(import('./pages/admin/AdminOrdersPosPages'), 'AdminPosPage'));
const AdminReceiptsPage = lazy(() => pick(import('./pages/admin/AdminOrdersPosPages'), 'AdminReceiptsPage'));
const AdminBannersPage = lazy(() => pick(import('./pages/admin/AdminMarketingSettingsPages'), 'AdminBannersPage'));
const AdminCustomersPage = lazy(() => pick(import('./pages/admin/AdminMarketingSettingsPages'), 'AdminCustomersPage'));
const AdminOffersPage = lazy(() => pick(import('./pages/admin/AdminMarketingSettingsPages'), 'AdminOffersPage'));
const AdminProfilePage = lazy(() => pick(import('./pages/admin/AdminMarketingSettingsPages'), 'AdminProfilePage'));
const AdminSettingsPage = lazy(() => pick(import('./pages/admin/AdminMarketingSettingsPages'), 'AdminSettingsPage'));
const AdminTeamPage = lazy(() => pick(import('./pages/admin/AdminTeamPage'), 'AdminTeamPage'));

function PageLoader() {
  return (
    <div className="flex min-h-[40vh] items-center justify-center">
      <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#F5B800] border-t-transparent" />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <Suspense fallback={<PageLoader />}>
        <Routes>
          {/* Public Storefront & Customer Routes */}
          <Route element={<PublicLayout />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/menu" element={<MenuPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/checkout" element={<CheckoutPage />} />
            <Route path="/order/:id" element={<OrderConfirmationPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/profile" element={<ProfilePage />} />
          </Route>

          {/* Role-Guarded Admin Dashboard Routes */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminOverview />} />
            <Route path="products" element={<AdminProductsPage />} />
            <Route path="categories" element={<AdminCategoriesPage />} />
            <Route path="sizes" element={<AdminSizesPage />} />
            <Route path="orders" element={<AdminOrdersPage />} />
            <Route path="pos" element={<AdminPosPage />} />
            <Route path="customers" element={<AdminCustomersPage />} />
            <Route path="team" element={<AdminTeamPage />} />
            <Route path="banners" element={<AdminBannersPage />} />
            <Route path="offers" element={<AdminOffersPage />} />
            <Route path="receipts" element={<AdminReceiptsPage />} />
            <Route path="settings" element={<AdminSettingsPage section="general" />} />
            <Route path="contact-social" element={<AdminSettingsPage section="contact" />} />
            <Route path="profile" element={<AdminProfilePage />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        </Suspense>
        <FeedbackOverlays />
      </AppProvider>
    </BrowserRouter>
  );
}
