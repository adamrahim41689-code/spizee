export interface SiteSettings {
  id: number;
  restaurantName: string;
  logoUrl: string | null;
  address: string | null;
  phone: string | null;
  email: string | null;
  openingHours: string | null;
  facebook: string | null;
  instagram: string | null;
  tiktok: string | null;
  whatsapp: string | null;
  googleMapsUrl: string | null;
  deliveryInfo: string | null;
  deliveryCharge: number;
  shortDescription: string | null;
  footerCopyright?: string | null;
  footerRightText?: string | null;
  footerTextSize?: 'xs' | 'sm' | 'base' | 'lg' | string | null;
}

export interface Category {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  isActive: boolean;
  sortOrder: number;
  createdAt?: string;
}

export interface ProductSize {
  id: string;
  productId: string;
  label: string;
  price: number;
  discountPrice: number | null;
  sortOrder: number;
}

export interface Product {
  id: string;
  categoryId: string | null;
  categoryName?: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  basePrice: number;
  discountPrice: number | null;
  isAvailable: boolean;
  isFeatured: boolean;
  isPopular: boolean;
  isNew: boolean;
  createdAt?: string;
  sizes: ProductSize[];
}

export interface Banner {
  id: string;
  imageUrl: string | null;
  title: string | null;
  subtitle: string | null;
  offerText: string | null;
  buttonText: string | null;
  buttonLink: string | null;
  startDate: string | null;
  endDate: string | null;
  isActive: boolean;
  position: number;
}

export interface Offer {
  id: string;
  title: string;
  description: string | null;
  offerType: 'percentage' | 'fixed' | 'combo' | 'special_price' | 'limited_time' | string;
  discountPercentage: number | null;
  discountAmount: number | null;
  startDate: string | null;
  endDate: string | null;
  applicableProductIds: string[];
  isActive: boolean;
}

export type UserRole = 'customer' | 'admin' | 'manager';

export interface UserProfile {
  id: string;
  fullName: string | null;
  email: string;
  phone: string | null;
  address: string | null;
  avatarUrl: string | null;
  role: UserRole;
  isActive: boolean;
  createdAt: string;
}

export interface TeamMember {
  id: string;
  fullName: string | null;
  email: string;
  phone: string | null;
  role: 'admin' | 'manager';
  isOwner: boolean;
  isActive: boolean;
  hasSignedIn: boolean;
  hasPassword?: boolean;
  hasGoogle?: boolean;
  createdAt: string;
}

export interface CartItemEntry {
  productId: string;
  sizeId: string | null;
  quantity: number;
}

export interface OrderItemDetail {
  id: string;
  orderId: string;
  productId: string | null;
  productName: string;
  sizeLabel: string | null;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
}

export interface ReceiptInfo {
  id: string;
  orderId: string;
  receiptNumber: string;
  issuedAt: string;
}

export interface OrderDetail {
  id: string;
  orderNumber: number;
  userId: string | null;
  source: 'online' | 'pos';
  customerName: string | null;
  customerPhone: string | null;
  orderType: 'home_delivery' | 'pickup' | 'dine_in';
  deliveryAddress: string | null;
  subtotal: number;
  discount: number;
  deliveryCharge: number;
  totalAmount: number;
  paymentMethod: string;
  status: 'pending' | 'confirmed' | 'preparing' | 'ready' | 'completed' | 'cancelled';
  notes: string | null;
  createdAt: string;
  items: OrderItemDetail[];
  receipt: ReceiptInfo | null;
}

export interface CustomerSummary extends UserProfile {
  totalOrders: number;
  totalSpent: number;
}

export interface AdminOverviewStats {
  kpis: {
    totalProducts: number;
    totalOrders: number;
    todayOrders: number;
    totalRevenue: number;
    todayRevenue: number;
    pendingOrders: number;
    completedOrders: number;
    totalCustomers: number;
  };
  dailySales: Array<{ date: string; sales: number; orders: number }>;
  monthlySales: Array<{ month: string; sales: number; orders: number }>;
  orderStats: Array<{ status: string; count: number }>;
  popularProducts: Array<{ name: string; quantity: number; revenue: number }>;
}
