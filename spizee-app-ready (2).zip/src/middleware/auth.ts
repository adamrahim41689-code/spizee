import crypto from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';
import { eq } from 'drizzle-orm';
import { adminAuth } from '../lib/firebase-admin.ts';
import { db } from '../db/index.ts';
import { profiles } from '../db/schema.ts';

export type UserRole = 'customer' | 'admin' | 'manager';

export interface AuthProfile {
  id: string;
  firebaseUid: string | null;
  fullName: string | null;
  email: string;
  phone: string | null;
  address: string | null;
  avatarUrl: string | null;
  role: UserRole;
  isActive: boolean;
  createdAt: Date;
}

export interface AuthRequest extends Request {
  profile?: AuthProfile;
}

export const SOLE_ADMIN_EMAIL = 'rigoshopbd@gmail.com';

export function isSoleAdminEmail(email?: string | null): boolean {
  return (email || '').trim().toLowerCase() === SOLE_ADMIN_EMAIL;
}

export function normalizeRole(email?: string | null, dbRole?: string | null): UserRole {
  if (isSoleAdminEmail(email)) return 'admin';
  if (dbRole === 'admin' || dbRole === 'manager') return dbRole;
  return 'customer';
}

export function hasAdminAccess(role?: string | null): boolean {
  return role === 'admin' || role === 'manager';
}

function getSessionSecret(): string {
  return (
    process.env.SESSION_SECRET ||
    process.env.SQL_PASSWORD ||
    'spizee-local-hmac-signing-key-v1'
  );
}

export function createSessionToken(profileId: string, email: string): string {
  const payload = Buffer.from(
    JSON.stringify({
      sub: profileId,
      email,
      exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
    })
  ).toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(payload)
    .digest('base64url');
  return `spz.${payload}.${sig}`;
}

export function verifySessionToken(token: string): { sub: string; email: string } | null {
  if (!token.startsWith('spz.')) return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [, payload, sig] = parts;
  const expected = crypto
    .createHmac('sha256', getSessionSecret())
    .update(payload)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!parsed.sub || !parsed.exp || Date.now() > Number(parsed.exp)) {
      return null;
    }
    return { sub: String(parsed.sub), email: String(parsed.email || '') };
  } catch {
    return null;
  }
}

export async function syncFirebaseUser(decoded: {
  uid: string;
  email?: string;
  name?: string;
  picture?: string;
}): Promise<AuthProfile> {
  const email = (decoded.email || `${decoded.uid}@firebase.local`).toLowerCase().trim();
  const isOwnerAdmin = isSoleAdminEmail(email);

  const existingByUid = await db
    .select()
    .from(profiles)
    .where(eq(profiles.firebaseUid, decoded.uid))
    .limit(1);

  if (existingByUid.length > 0) {
    const row = existingByUid[0];
    const resolvedRole = normalizeRole(email, row.role);
    const [updated] = await db
      .update(profiles)
      .set({
        email,
        fullName: row.fullName || decoded.name || null,
        avatarUrl: row.avatarUrl || decoded.picture || null,
        role: resolvedRole,
      })
      .where(eq(profiles.id, row.id))
      .returning();
    return { ...(updated as AuthProfile), role: resolvedRole };
  }

  const existingByEmail = await db
    .select()
    .from(profiles)
    .where(eq(profiles.email, email))
    .limit(1);

  if (existingByEmail.length > 0) {
    const row = existingByEmail[0];
    const resolvedRole = normalizeRole(email, row.role);
    const [updated] = await db
      .update(profiles)
      .set({
        firebaseUid: decoded.uid,
        fullName: row.fullName || decoded.name || null,
        avatarUrl: row.avatarUrl || decoded.picture || null,
        role: resolvedRole,
      })
      .where(eq(profiles.id, row.id))
      .returning();
    return { ...(updated as AuthProfile), role: resolvedRole };
  }

  const [created] = await db
    .insert(profiles)
    .values({
      firebaseUid: decoded.uid,
      email,
      fullName: decoded.name || email.split('@')[0],
      avatarUrl: decoded.picture || null,
      role: isOwnerAdmin ? 'admin' : 'customer',
      isActive: true,
    })
    .onConflictDoUpdate({
      target: profiles.email,
      set: {
        firebaseUid: decoded.uid,
      },
    })
    .returning();

  return created as AuthProfile;
}

async function resolveProfileFromHeader(authHeader?: string): Promise<AuthProfile | null> {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.slice('Bearer '.length).trim();
  if (!token) return null;

  if (token.startsWith('spz.')) {
    const verified = verifySessionToken(token);
    if (!verified) return null;
    const rows = await db
      .select()
      .from(profiles)
      .where(eq(profiles.id, verified.sub))
      .limit(1);
    const row = rows[0] as AuthProfile | undefined;
    if (!row) return null;
    return {
      ...row,
      role: normalizeRole(row.email, row.role),
    };
  }

  try {
    const decoded = await adminAuth.verifyIdToken(token);
    return await syncFirebaseUser({
      uid: decoded.uid,
      email: decoded.email,
      name: decoded.name,
      picture: decoded.picture,
    });
  } catch (err: any) {
    const code = err?.code || err?.errorInfo?.code;
    if (code !== 'auth/id-token-expired' && code !== 'auth/id-token-revoked') {
      console.error('Token verification failed:', err);
    }
    return null;
  }
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const profile = await resolveProfileFromHeader(req.headers.authorization);
    if (!profile) {
      return res.status(401).json({ error: 'Authentication required. Please sign in.' });
    }
    if (!profile.isActive) {
      return res.status(403).json({ error: 'Your account has been deactivated. Contact SPIZEE support.' });
    }
    req.profile = profile;
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    return res.status(401).json({ error: 'Invalid or expired session.' });
  }
};

export const requireAdmin = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const profile = await resolveProfileFromHeader(req.headers.authorization);
    if (!profile) {
      return res.status(401).json({ error: 'Authentication required.' });
    }
    if (!profile.isActive || !hasAdminAccess(profile.role)) {
      return res.status(403).json({ error: 'Admin or Manager access required.' });
    }
    req.profile = profile;
    next();
  } catch (error) {
    console.error('Admin middleware error:', error);
    return res.status(403).json({ error: 'Admin authorization failed.' });
  }
};

export const optionalAuth = async (
  req: AuthRequest,
  _res: Response,
  next: NextFunction
) => {
  try {
    const profile = await resolveProfileFromHeader(req.headers.authorization);
    if (profile && profile.isActive) {
      req.profile = profile;
    }
  } catch {
    // Ignore optional auth failures
  }
  next();
};
