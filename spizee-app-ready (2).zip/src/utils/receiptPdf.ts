import { resolveMediaUrl } from '../lib/api';
import type jsPDF from 'jspdf';

// jsPDF is large (~300 KB). Load it only when the user actually downloads a PDF receipt.
let JsPDFCtor!: typeof import('jspdf').default;
let autoTableFn!: typeof import('jspdf-autotable').default;
async function loadPdfLibs() {
  if (JsPDFCtor && autoTableFn) return;
  const [pdfMod, tableMod] = await Promise.all([import('jspdf'), import('jspdf-autotable')]);
  JsPDFCtor = pdfMod.default;
  autoTableFn = tableMod.default;
}
import type { OrderDetail, SiteSettings } from '../types';
import { formatBdt, formatDhakaDateTime, roundBdt } from './orderMath';
import { copy } from '../i18n/en';

interface LoadedLogoAsset {
  dataUrl: string;
  widthMm: number;
  heightMm: number;
}

function formatPdfBdt(val: number): string {
  const n = roundBdt(Number(val || 0));
  return `BDT ${n.toLocaleString('en-US', {
    minimumFractionDigits: Number.isInteger(n) ? 0 : 2,
    maximumFractionDigits: 2,
  })}`;
}

function escapeHtml(text: string): string {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Converts any uploaded logo (PNG, JPEG, WebP, SVG) into a clean PNG data URL
 * with preserved aspect ratio so jsPDF ALWAYS renders the logo reliably.
 */
async function loadLogoForPdf(url: string): Promise<LoadedLogoAsset | null> {
  try {
    const res = await fetch(resolveMediaUrl(url));
    if (!res.ok) return null;
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);

    try {
      const img = await new Promise<HTMLImageElement | null>((resolve) => {
        const el = new Image();
        el.crossOrigin = 'anonymous';
        el.onload = () => resolve(el);
        el.onerror = () => resolve(null);
        el.src = objectUrl;
      });
      if (!img || !img.naturalWidth || !img.naturalHeight) return null;

      const canvas = document.createElement('canvas');
      const maxPx = 220;
      const scale = Math.min(1, maxPx / Math.max(img.naturalWidth, img.naturalHeight));
      canvas.width = Math.max(1, Math.round(img.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(img.naturalHeight * scale));

      const ctx = canvas.getContext('2d');
      if (!ctx) return null;
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      const pngDataUrl = canvas.toDataURL('image/png');
      const aspect = canvas.width / canvas.height;
      const maxH = 10.5;
      const maxW = 24;
      let widthMm = maxH * aspect;
      let heightMm = maxH;
      if (widthMm > maxW) {
        widthMm = maxW;
        heightMm = maxW / aspect;
      }

      return { dataUrl: pngDataUrl, widthMm, heightMm };
    } finally {
      URL.revokeObjectURL(objectUrl);
    }
  } catch {
    return null;
  }
}

function computeVerifiedTotals(order: OrderDetail) {
  const computedItemsSubtotal = roundBdt(
    order.items.reduce((sum, item) => sum + roundBdt(Number(item.unitPrice) * Number(item.quantity)), 0)
  );
  const displaySubtotal = roundBdt(Number(order.subtotal) || computedItemsSubtotal);
  const displayDiscount = roundBdt(Math.max(0, Number(order.discount || 0)));
  const displayDelivery = 0;
  const displayTotal = roundBdt(Math.max(0, displaySubtotal - displayDiscount));
  const totalQty = order.items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  return {
    displaySubtotal,
    displayDiscount,
    displayDelivery,
    displayTotal,
    totalQty,
  };
}

function drawCopyBanner(doc: jsPDF, pageWidth: number, margin: number, y: number, label: string): number {
  const bannerHeight = 5.2;
  doc.setFillColor(0, 0, 0);
  doc.rect(margin, y, pageWidth - margin * 2, bannerHeight, 'F');
  doc.setFont('courier', 'bold');
  doc.setFontSize(8.2);
  doc.setTextColor(255, 255, 255);
  doc.text(label, pageWidth / 2, y + 3.6, { align: 'center' });
  doc.setTextColor(0, 0, 0);
  return y + bannerHeight + 2.8;
}

function renderDualCopyReceiptToDoc(
  doc: jsPDF,
  order: OrderDetail,
  settings: SiteSettings | null,
  logo: LoadedLogoAsset | null
): number {
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 4.5;
  let y = 4.5;

  const restaurantName = settings?.restaurantName || 'SPIZEE';
  const dhaka = formatDhakaDateTime(order.receipt?.issuedAt || order.createdAt);
  const orderTypeLabel = copy.orderTypes[order.orderType] || order.orderType;
  const statusLabel = (copy.orderStatuses[order.status] || order.status).toUpperCase();
  const { displaySubtotal, displayDiscount, displayDelivery, displayTotal, totalQty } =
    computeVerifiedTotals(order);

  // ==================== PART 1: CUSTOMER COPY ====================
  y = drawCopyBanner(doc, pageWidth, margin, y, 'CUSTOMER COPY');

  if (logo) {
    try {
      doc.addImage(
        logo.dataUrl,
        'PNG',
        (pageWidth - logo.widthMm) / 2,
        y,
        logo.widthMm,
        logo.heightMm,
        undefined,
        'FAST'
      );
      y += logo.heightMm + 2.4;
    } catch {
      // Fallback cleanly to text header
    }
  }

  doc.setFont('courier', 'bold');
  doc.setFontSize(12.2);
  doc.setTextColor(0, 0, 0);
  doc.text(restaurantName.toUpperCase(), pageWidth / 2, y, { align: 'center' });
  y += 3.6;

  if (settings?.phone) {
    doc.setFont('courier', 'bold');
    doc.setFontSize(7.6);
    doc.text(`Mobile: ${settings.phone}`, pageWidth / 2, y, { align: 'center' });
    y += 3.3;
  }
  if (settings?.address) {
    doc.setFont('courier', 'normal');
    doc.setFontSize(6.9);
    const addrLines = doc.splitTextToSize(settings.address, pageWidth - margin * 2);
    doc.text(addrLines, pageWidth / 2, y, { align: 'center' });
    y += addrLines.length * 3.0;
  }

  doc.setFont('courier', 'normal');
  doc.setFontSize(7.2);
  doc.text('------------------------------------------', pageWidth / 2, y, { align: 'center' });
  y += 3.2;

  const metaRows: Array<[string, string]> = [
    ['Order #:', `#${order.orderNumber} (${order.source.toUpperCase()})`],
    ['Date:', dhaka.dateStr],
    ['Time:', dhaka.timeStr],
    ['Type:', orderTypeLabel],
    ['Status:', statusLabel],
  ];
  if (order.customerPhone) metaRows.push(['Mobile:', order.customerPhone]);

  doc.setFontSize(7.4);
  for (const [label, value] of metaRows) {
    doc.setFont('courier', 'bold');
    doc.text(label, margin, y);
    doc.setFont('courier', 'normal');
    doc.text(String(value), pageWidth - margin, y, { align: 'right' });
    y += 3.4;
  }

  if (order.orderType === 'home_delivery' && order.deliveryAddress) {
    doc.setFont('courier', 'bold');
    doc.text('Address:', margin, y);
    y += 3.0;
    doc.setFont('courier', 'normal');
    const addr = doc.splitTextToSize(order.deliveryAddress, pageWidth - margin * 2);
    doc.text(addr, margin, y);
    y += addr.length * 3.0 + 0.6;
  }

  doc.text('------------------------------------------', pageWidth / 2, y, { align: 'center' });
  y += 1.4;

  autoTableFn(doc, {
    startY: y,
    margin: { left: margin, right: margin, bottom: 2 },
    pageBreak: 'avoid',
    theme: 'plain',
    styles: {
      font: 'courier',
      fontSize: 7.0,
      textColor: [0, 0, 0],
      cellPadding: { top: 0.8, bottom: 0.8, left: 0.4, right: 0.4 },
    },
    headStyles: {
      fontStyle: 'bold',
      lineWidth: { bottom: 0.2 },
      lineColor: [0, 0, 0],
    },
    head: [['Item', 'Qty', 'Total']],
    body: order.items.map((item) => {
      const unitPrice = roundBdt(Number(item.unitPrice));
      const lineTotal = roundBdt(unitPrice * Number(item.quantity));
      return [
        item.sizeLabel
          ? `${item.productName}\n(${item.sizeLabel} @ ${formatPdfBdt(unitPrice)})`
          : `${item.productName}\n(@ ${formatPdfBdt(unitPrice)})`,
        String(item.quantity),
        formatPdfBdt(lineTotal),
      ];
    }),
    columnStyles: {
      0: { cellWidth: 43 },
      1: { cellWidth: 8, halign: 'center' },
      2: { cellWidth: 20, halign: 'right' },
    },
  });

  y = ((doc as any).lastAutoTable?.finalY ?? y + 18) + 2.2;

  doc.setFont('courier', 'normal');
  doc.setFontSize(7.4);
  doc.text('------------------------------------------', pageWidth / 2, y, { align: 'center' });
  y += 3.2;

  const summaryRows: Array<[string, string]> = [['Subtotal', formatPdfBdt(displaySubtotal)]];
  if (displayDiscount > 0) {
    summaryRows.push(['Discount', `-${formatPdfBdt(displayDiscount)}`]);
  }
  if (displayDelivery > 0) {
    summaryRows.push(['Delivery Charge', formatPdfBdt(displayDelivery)]);
  }

  for (const [label, val] of summaryRows) {
    doc.text(label, margin, y);
    doc.text(val, pageWidth - margin, y, { align: 'right' });
    y += 3.4;
  }

  doc.setFont('courier', 'bold');
  doc.setFontSize(9.0);
  doc.text('TOTAL', margin, y + 0.8);
  doc.text(formatPdfBdt(displayTotal), pageWidth - margin, y + 0.8, { align: 'right' });
  y += 4.5;

  doc.setFont('courier', 'normal');
  doc.setFontSize(7.1);
  doc.text('Payment:', margin, y);
  doc.text(String(order.paymentMethod || 'CASH').toUpperCase(), pageWidth - margin, y, {
    align: 'right',
  });
  y += 3.3;

  doc.text('==========================================', pageWidth / 2, y, { align: 'center' });
  y += 3.2;
  doc.setFont('courier', 'bold');
  doc.text(`Thank you for ordering from ${restaurantName}!`, pageWidth / 2, y, {
    align: 'center',
  });

  // ==================== TEAR-OFF / CUT PERFORATION LINE ====================
  y += 6.0;
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.25);
  doc.setLineDashPattern([1.6, 1.4], 0);
  doc.line(margin, y, pageWidth - margin, y);
  doc.setLineDashPattern([], 0);
  y += 3.3;
  doc.setFont('courier', 'bold');
  doc.setFontSize(7.0);
  doc.text('- - - [ CUT / TEAR HERE ] - - -', pageWidth / 2, y, { align: 'center' });
  y += 2.5;
  doc.setLineDashPattern([1.6, 1.4], 0);
  doc.line(margin, y, pageWidth - margin, y);
  doc.setLineDashPattern([], 0);
  y += 4.8;

  // ==================== PART 2: KITCHEN COPY ====================
  y = drawCopyBanner(doc, pageWidth, margin, y, 'KITCHEN COPY');

  if (logo) {
    try {
      const kScale = 0.82;
      const kw = logo.widthMm * kScale;
      const kh = logo.heightMm * kScale;
      doc.addImage(logo.dataUrl, 'PNG', (pageWidth - kw) / 2, y, kw, kh, undefined, 'FAST');
      y += kh + 2.0;
    } catch {
      // ignore
    }
  }

  doc.setFont('courier', 'bold');
  doc.setFontSize(10.5);
  doc.text(restaurantName.toUpperCase(), pageWidth / 2, y, { align: 'center' });
  y += 3.3;

  if (settings?.phone) {
    doc.setFont('courier', 'bold');
    doc.setFontSize(7.3);
    doc.text(`Mobile: ${settings.phone}`, pageWidth / 2, y, { align: 'center' });
    y += 3.4;
  }

  doc.setFont('courier', 'normal');
  doc.setFontSize(7.3);
  const kitchenMeta: Array<[string, string]> = [
    ['Order #:', `#${order.orderNumber} (${order.source.toUpperCase()})`],
    ['Date:', dhaka.dateStr],
    ['Time:', dhaka.timeStr],
    ['Type:', orderTypeLabel],
    ['Status:', statusLabel],
  ];
  if (order.customerPhone) kitchenMeta.push(['Mobile:', order.customerPhone]);

  for (const [label, value] of kitchenMeta) {
    doc.setFont('courier', 'bold');
    doc.text(label, margin, y);
    doc.setFont('courier', 'normal');
    doc.text(String(value), pageWidth - margin, y, { align: 'right' });
    y += 3.4;
  }

  doc.text('------------------------------------------', pageWidth / 2, y, { align: 'center' });
  y += 1.4;

  autoTableFn(doc, {
    startY: y,
    margin: { left: margin, right: margin, bottom: 2 },
    pageBreak: 'avoid',
    theme: 'plain',
    styles: {
      font: 'courier',
      fontSize: 7.8,
      fontStyle: 'bold',
      textColor: [0, 0, 0],
      cellPadding: { top: 0.9, bottom: 0.9, left: 0.4, right: 0.4 },
    },
    headStyles: {
      fontStyle: 'bold',
      fontSize: 7.2,
      lineWidth: { bottom: 0.25 },
      lineColor: [0, 0, 0],
    },
    head: [['Qty', 'Kitchen Prep Item']],
    body: order.items.map((item) => [
      `${item.quantity}x`,
      item.sizeLabel ? `${item.productName}\n[${item.sizeLabel}]` : item.productName,
    ]),
    columnStyles: {
      0: { cellWidth: 11, halign: 'left' },
      1: { cellWidth: 60, halign: 'left' },
    },
  });

  y = ((doc as any).lastAutoTable?.finalY ?? y + 14) + 2.4;

  if (order.notes && order.notes.trim()) {
    const noteLines = doc.splitTextToSize(`NOTE: ${order.notes.trim()}`, pageWidth - margin * 2 - 3);
    const boxHeight = noteLines.length * 3.4 + 3.2;
    doc.setDrawColor(0, 0, 0);
    doc.setLineWidth(0.25);
    doc.rect(margin, y, pageWidth - margin * 2, boxHeight);
    doc.setFont('courier', 'bold');
    doc.setFontSize(7.4);
    doc.text(noteLines, margin + 1.5, y + 3.2);
    y += boxHeight + 2.6;
  }

  doc.setFont('courier', 'normal');
  doc.setFontSize(7.4);
  doc.text('------------------------------------------', pageWidth / 2, y, { align: 'center' });
  y += 3.3;

  doc.setFont('courier', 'bold');
  doc.setFontSize(8.0);
  doc.text(`Total Items: ${totalQty}`, margin, y);
  doc.text(formatPdfBdt(displayTotal), pageWidth - margin, y, { align: 'right' });

  return y;
}

export async function downloadReceiptPdf(order: OrderDetail, settings: SiteSettings | null) {
  await loadPdfLibs();
  const receiptNumber = order.receipt?.receiptNumber || `SPZ-${order.orderNumber}`;
  const logo = settings?.logoUrl ? await loadLogoForPdf(settings.logoUrl) : null;

  // Pass 1: Measure exact height of BOTH Customer Copy + Tear Line + Kitchen Copy on a single continuous page
  const measureDoc = new JsPDFCtor({ unit: 'mm', format: [80, 1400] });
  const contentEndY = renderDualCopyReceiptToDoc(measureDoc, order, settings, logo);
  const exactHeightMm = Math.max(90, Math.ceil(contentEndY + 7));

  // Pass 2: Render final single-page PDF with ZERO extra blank paper at the bottom
  const finalDoc = new JsPDFCtor({ unit: 'mm', format: [80, exactHeightMm] });
  renderDualCopyReceiptToDoc(finalDoc, order, settings, logo);
  finalDoc.save(`SPIZEE-Receipt-${receiptNumber}.pdf`);
}

export function buildDualCopyReceiptHtml(
  order: OrderDetail,
  settings: SiteSettings | null,
  logoSrc?: string | null
): string {
  const restaurantName = settings?.restaurantName || 'SPIZEE';
  const receiptNumber = order.receipt?.receiptNumber || `SPZ-${order.orderNumber}`;
  const dhaka = formatDhakaDateTime(order.receipt?.issuedAt || order.createdAt);
  const orderTypeLabel = copy.orderTypes[order.orderType] || order.orderType;
  const statusLabel = (copy.orderStatuses[order.status] || order.status).toUpperCase();
  const { displaySubtotal, displayDiscount, displayDelivery, displayTotal, totalQty } =
    computeVerifiedTotals(order);

  const itemsHtml = order.items
    .map((item) => {
      const unitPrice = roundBdt(Number(item.unitPrice));
      const lineTotal = roundBdt(unitPrice * Number(item.quantity));
      return `
        <tr>
          <td class="item-name">
            <div class="bold">${escapeHtml(item.productName)}</div>
            <div class="sub">${item.sizeLabel ? `${escapeHtml(item.sizeLabel)} &middot; ` : ''}${escapeHtml(formatBdt(unitPrice))} each</div>
          </td>
          <td class="center">${item.quantity}</td>
          <td class="right bold">${escapeHtml(formatBdt(lineTotal))}</td>
        </tr>
      `;
    })
    .join('');

  const kitchenItemsHtml = order.items
    .map(
      (item) => `
      <tr>
        <td class="k-qty">${item.quantity}x</td>
        <td class="k-item">
          <div class="bold">${escapeHtml(item.productName)}</div>
          ${item.sizeLabel ? `<div class="k-size">[${escapeHtml(item.sizeLabel)}]</div>` : ''}
        </td>
      </tr>
    `
    )
    .join('');

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>SPIZEE Receipt ${escapeHtml(receiptNumber)}</title>
  <style>
    @page {
      size: 80mm auto;
      margin: 2.5mm;
    }
    * {
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    html, body {
      margin: 0;
      padding: 0;
      background: #ffffff;
      color: #000000;
      font-family: "Courier New", Courier, ui-monospace, monospace;
      font-size: 11px;
      line-height: 1.32;
    }
    .sheet {
      width: 74mm;
      margin: 0 auto;
      padding: 2mm 1mm;
    }
    .copy-banner {
      background: #000000;
      color: #ffffff;
      text-align: center;
      font-weight: 800;
      font-size: 11px;
      letter-spacing: 1.2px;
      padding: 3px 6px;
      margin-bottom: 6px;
    }
    .header {
      text-align: center;
      margin-bottom: 5px;
    }
    .header img {
      max-height: 30px;
      max-width: 72px;
      object-fit: contain;
      display: block;
      margin: 0 auto 4px auto;
      filter: grayscale(100%) contrast(120%);
    }
    .brand {
      font-size: 14.5px;
      font-weight: 800;
      letter-spacing: 0.6px;
    }
    .mobile-line {
      font-size: 10.5px;
      font-weight: 700;
      margin-top: 2px;
    }
    .meta-sub {
      font-size: 9.5px;
      margin-top: 1px;
    }
    .rule {
      border: 0;
      border-top: 1px dashed #000000;
      margin: 6px 0;
    }
    .row {
      display: flex;
      justify-content: space-between;
      gap: 8px;
      margin: 2px 0;
      font-size: 10.5px;
    }
    .bold { font-weight: 700; }
    .center { text-align: center; }
    .right { text-align: right; }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th {
      text-align: left;
      font-size: 10.5px;
      padding-bottom: 3px;
      border-bottom: 1px dashed #000000;
    }
    th.center { text-align: center; }
    th.right { text-align: right; }
    td {
      vertical-align: top;
      padding: 3px 0;
      font-size: 10.5px;
      border-bottom: 1px dotted #999999;
    }
    tr:last-child td {
      border-bottom: none;
    }
    .sub {
      font-size: 9.5px;
    }
    .total-row {
      display: flex;
      justify-content: space-between;
      border-top: 1.5px solid #000000;
      margin-top: 4px;
      padding-top: 4px;
      font-size: 13.5px;
      font-weight: 800;
    }
    .footer {
      text-align: center;
      margin-top: 5px;
      font-size: 10px;
    }
    .cut-zone {
      margin: 12px 0;
      text-align: center;
    }
    .cut-line {
      border-top: 1.5px dashed #000000;
      margin: 4px 0;
    }
    .cut-label {
      font-size: 9.5px;
      font-weight: 800;
      letter-spacing: 0.8px;
    }
    .k-qty {
      width: 30px;
      font-size: 12.5px;
      font-weight: 800;
    }
    .k-item {
      font-size: 11.5px;
    }
    .k-size {
      font-size: 10px;
      font-weight: 700;
    }
    .k-note {
      border: 1.2px solid #000000;
      padding: 4px 6px;
      margin-top: 6px;
      font-size: 10.5px;
      font-weight: 700;
    }
  </style>
</head>
<body>
  <div class="sheet">
    <!-- PART 1: CUSTOMER COPY -->
    <div class="copy-banner">CUSTOMER COPY</div>
    <div class="header">
      ${logoSrc ? `<img src="${escapeHtml(logoSrc)}" alt="${escapeHtml(restaurantName)}" />` : ''}
      <div class="brand">${escapeHtml(restaurantName.toUpperCase())}</div>
      ${settings?.phone ? `<div class="mobile-line">Mobile: ${escapeHtml(settings.phone)}</div>` : ''}
      ${settings?.address ? `<div class="meta-sub">${escapeHtml(settings.address)}</div>` : ''}
    </div>

    <hr class="rule" />

    <div class="row"><span class="bold">Order #:</span><span>#${order.orderNumber} (${escapeHtml(order.source.toUpperCase())})</span></div>
    <div class="row"><span class="bold">Date:</span><span>${escapeHtml(dhaka.dateStr)}</span></div>
    <div class="row"><span class="bold">Time:</span><span>${escapeHtml(dhaka.timeStr)}</span></div>
    <div class="row"><span class="bold">Type:</span><span>${escapeHtml(orderTypeLabel)}</span></div>
    <div class="row"><span class="bold">Status:</span><span class="bold">${escapeHtml(statusLabel)}</span></div>
    ${order.customerPhone ? `<div class="row"><span class="bold">Mobile:</span><span>${escapeHtml(order.customerPhone)}</span></div>` : ''}
    ${
      order.orderType === 'home_delivery' && order.deliveryAddress
        ? `<div style="margin-top:4px;font-size:10px;"><span class="bold">Address:</span> ${escapeHtml(order.deliveryAddress)}</div>`
        : ''
    }

    <hr class="rule" />

    <table>
      <thead>
        <tr>
          <th>Item</th>
          <th class="center">Qty</th>
          <th class="right">Total</th>
        </tr>
      </thead>
      <tbody>
        ${itemsHtml}
      </tbody>
    </table>

    <hr class="rule" />

    <div class="row"><span>Subtotal</span><span>${escapeHtml(formatBdt(displaySubtotal))}</span></div>
    ${displayDiscount > 0 ? `<div class="row"><span>Discount</span><span>-${escapeHtml(formatBdt(displayDiscount))}</span></div>` : ''}
    ${displayDelivery > 0 ? `<div class="row"><span>Delivery Charge</span><span>${escapeHtml(formatBdt(displayDelivery))}</span></div>` : ''}
    <div class="total-row"><span>TOTAL</span><span>${escapeHtml(formatBdt(displayTotal))}</span></div>
    <div class="row" style="margin-top:3px;"><span>Payment</span><span>${escapeHtml(String(order.paymentMethod || 'CASH').toUpperCase())}</span></div>

    <hr class="rule" />
    <div class="footer">
      <div class="bold">Thank you for ordering from ${escapeHtml(restaurantName)}!</div>
    </div>

    <!-- TEAR-OFF PERFORATION LINE -->
    <div class="cut-zone">
      <div class="cut-line"></div>
      <div class="cut-label">&#9986; - - - CUT / TEAR HERE - - - &#9986;</div>
      <div class="cut-line"></div>
    </div>

    <!-- PART 2: KITCHEN COPY -->
    <div class="copy-banner">KITCHEN COPY</div>
    <div class="header">
      ${logoSrc ? `<img src="${escapeHtml(logoSrc)}" alt="${escapeHtml(restaurantName)}" style="max-height:24px;" />` : ''}
      <div class="brand" style="font-size:13px;">${escapeHtml(restaurantName.toUpperCase())}</div>
      ${settings?.phone ? `<div class="mobile-line">Mobile: ${escapeHtml(settings.phone)}</div>` : ''}
    </div>

    <div class="row"><span class="bold">Order #:</span><span class="bold">#${order.orderNumber} (${escapeHtml(order.source.toUpperCase())})</span></div>
    <div class="row"><span class="bold">Date:</span><span>${escapeHtml(dhaka.dateStr)}</span></div>
    <div class="row"><span class="bold">Time:</span><span>${escapeHtml(dhaka.timeStr)}</span></div>
    <div class="row"><span class="bold">Type:</span><span class="bold">${escapeHtml(orderTypeLabel)}</span></div>
    <div class="row"><span class="bold">Status:</span><span class="bold">${escapeHtml(statusLabel)}</span></div>
    ${order.customerPhone ? `<div class="row"><span class="bold">Mobile:</span><span>${escapeHtml(order.customerPhone)}</span></div>` : ''}

    <hr class="rule" />

    <table>
      <thead>
        <tr>
          <th style="width:30px;">Qty</th>
          <th>Kitchen Prep Item</th>
        </tr>
      </thead>
      <tbody>
        ${kitchenItemsHtml}
      </tbody>
    </table>

    ${order.notes && order.notes.trim() ? `<div class="k-note">NOTE: ${escapeHtml(order.notes.trim())}</div>` : ''}

    <hr class="rule" />
    <div class="row bold" style="font-size:11.5px;">
      <span>Total Items: ${totalQty}</span>
      <span>${escapeHtml(formatBdt(displayTotal))}</span>
    </div>
  </div>
</body>
</html>`;
}

/**
 * Dedicated hidden-iframe thermal print engine.
 * Prints ONLY the single-page dual-copy receipt (Customer Copy + Cut Line + Kitchen Copy)
 * without modal clipping, navigation bars, or setTimeout gesture issues.
 */
export async function printReceiptHtml(
  order: OrderDetail,
  settings: SiteSettings | null
): Promise<boolean> {
  if (typeof window === 'undefined' || typeof document === 'undefined') return false;

  const logo = settings?.logoUrl ? await loadLogoForPdf(settings.logoUrl) : null;
  const logoSrc = logo?.dataUrl || settings?.logoUrl || null;
  const html = buildDualCopyReceiptHtml(order, settings, logoSrc);

  // Clean up any previous receipt print iframe
  const existing = document.getElementById('spizee-receipt-print-frame');
  if (existing && existing.parentNode) {
    existing.parentNode.removeChild(existing);
  }

  return await new Promise<boolean>((resolve) => {
    const iframe = document.createElement('iframe');
    iframe.id = 'spizee-receipt-print-frame';
    iframe.title = 'SPIZEE Thermal Receipt Print';
    iframe.setAttribute('aria-hidden', 'true');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    iframe.style.opacity = '0';
    iframe.style.pointerEvents = 'none';

    let printed = false;
    const cleanup = () => {
      window.setTimeout(() => {
        if (iframe.parentNode) {
          iframe.parentNode.removeChild(iframe);
        }
      }, 1500);
    };

    const triggerPrint = () => {
      if (printed) return;
      printed = true;
      try {
        const win = iframe.contentWindow;
        if (win) {
          win.addEventListener('afterprint', cleanup, { once: true });
          win.focus();
          win.print();
          resolve(true);
          window.setTimeout(cleanup, 60000);
          return;
        }
      } catch {
        // Fallback below
      }
      try {
        window.print();
        resolve(true);
      } catch {
        resolve(false);
      }
      cleanup();
    };

    document.body.appendChild(iframe);

    const doc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!doc) {
      triggerPrint();
      return;
    }

    iframe.onload = () => {
      window.requestAnimationFrame(() => {
        window.setTimeout(triggerPrint, 60);
      });
    };

    doc.open();
    doc.write(html);
    doc.close();

    window.setTimeout(triggerPrint, 300);
  });
}
