import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateOrderTotals,
  computeEffectivePrice,
  formatBdt,
  formatDhakaDateTime,
  generateReceiptNumber,
  isWithinSchedule,
  mergeCartEntries,
  validateOrderInput,
} from './orderMath';

test('computeEffectivePrice prefers size price and applies best active offer', () => {
  const now = new Date('2026-11-20T12:00:00Z');
  const res = computeEffectivePrice(
    {
      productId: 'p1',
      basePrice: 250,
      discountPrice: null,
      sizePrice: 320,
      sizeDiscountPrice: 300,
      quantity: 2,
    },
    [
      {
        id: 'o1',
        title: '10% Flash Deal',
        offerType: 'percentage',
        discountPercentage: 10,
        discountAmount: null,
        startDate: '2026-11-01T00:00:00Z',
        endDate: '2026-11-30T23:59:59Z',
        applicableProductIds: ['p1'],
        isActive: true,
      },
    ],
    now
  );

  assert.equal(res.originalUnitPrice, 320);
  assert.equal(res.effectiveUnitPrice, 270);
  assert.equal(res.lineSubtotal, 540);
  assert.equal(res.appliedOfferTitle, '10% Flash Deal');
});

test('calculateOrderTotals applies zero delivery charge across all order types', () => {
  const delivery = calculateOrderTotals({
    lines: [{ effectiveUnitPrice: 250, quantity: 2 }],
    orderType: 'home_delivery',
    source: 'online',
    siteDeliveryCharge: 0,
  });
  assert.equal(delivery.subtotal, 500);
  assert.equal(delivery.deliveryCharge, 0);
  assert.equal(delivery.totalAmount, 500);

  const pickup = calculateOrderTotals({
    lines: [{ effectiveUnitPrice: 250, quantity: 2 }],
    orderType: 'pickup',
    source: 'online',
    siteDeliveryCharge: 0,
  });
  assert.equal(pickup.deliveryCharge, 0);
  assert.equal(pickup.totalAmount, 500);

  const pos = calculateOrderTotals({
    lines: [{ effectiveUnitPrice: 250, quantity: 2 }],
    orderType: 'dine_in',
    source: 'pos',
    siteDeliveryCharge: 0,
  });
  assert.equal(pos.deliveryCharge, 0);
  assert.equal(pos.totalAmount, 500);
});

test('validateOrderInput enforces delivery address for online delivery and blocks delivery in POS', () => {
  assert.ok(
    validateOrderInput({
      items: [{ productId: 'p1', quantity: 1 }],
      orderType: 'home_delivery',
      source: 'online',
      customerName: 'Rahim',
      customerPhone: '01711000000',
      deliveryAddress: '',
    })
  );

  assert.equal(
    validateOrderInput({
      items: [{ productId: 'p1', quantity: 1 }],
      orderType: 'home_delivery',
      source: 'online',
      customerName: 'Rahim',
      customerPhone: '01711000000',
      deliveryAddress: 'House 12, Road 4, Dhanmondi, Dhaka',
    }),
    null
  );

  assert.ok(
    validateOrderInput({
      items: [{ productId: 'p1', quantity: 1 }],
      orderType: 'home_delivery',
      source: 'pos',
    })
  );

  assert.equal(
    validateOrderInput({
      items: [{ productId: 'p1', quantity: 2 }],
      orderType: 'pickup',
      source: 'pos',
    }),
    null
  );

  assert.equal(
    validateOrderInput({
      items: [{ productId: 'p1', quantity: 1 }],
      orderType: 'pickup',
      source: 'online',
      customerName: '',
      customerPhone: '',
      deliveryAddress: '',
    }),
    null
  );
});

test('mergeCartEntries keeps different sizes separate and merges identical product+size', () => {
  const merged = mergeCartEntries(
    [
      { productId: 'p1', sizeId: 's1', quantity: 1 },
      { productId: 'p1', sizeId: 's2', quantity: 2 },
    ],
    [{ productId: 'p1', sizeId: 's1', quantity: 3 }]
  );
  assert.equal(merged.length, 2);
  const s1 = merged.find((m) => m.sizeId === 's1');
  const s2 = merged.find((m) => m.sizeId === 's2');
  assert.equal(s1?.quantity, 4);
  assert.equal(s2?.quantity, 2);
});

test('Asia/Dhaka receipt timestamp includes seconds and generates SPZ receipt number', () => {
  const date = new Date('2026-11-20T14:05:09Z'); // 20:05:09 in Asia/Dhaka (+06:00)
  const formatted = formatDhakaDateTime(date);
  assert.equal(formatted.dateStr, '20/11/2026');
  assert.equal(formatted.isoDate, '2026-11-20');
  assert.match(formatted.timeStr, /08:05:09 PM/);
  assert.equal(generateReceiptNumber(1001, date), 'SPZ-261120-1001');
  assert.equal(formatBdt(1250), '৳1,250');
});

test('isWithinSchedule respects start/end boundaries and isActive flag', () => {
  const now = new Date('2026-11-20T12:00:00Z');
  assert.equal(isWithinSchedule(false, null, null, now), false);
  assert.equal(isWithinSchedule(true, '2026-11-21T00:00:00Z', null, now), false);
  assert.equal(isWithinSchedule(true, '2026-11-01T00:00:00Z', '2026-11-25T00:00:00Z', now), true);
});
