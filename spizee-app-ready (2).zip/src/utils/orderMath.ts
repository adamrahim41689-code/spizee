export interface ActiveOfferInput {
  id: string;
  title: string;
  offerType: string;
  discountPercentage: number | null;
  discountAmount: number | null;
  startDate: string | Date | null;
  endDate: string | Date | null;
  applicableProductIds: string[];
  isActive: boolean;
}

export interface PricedItemInput {
  productId: string;
  basePrice: number;
  discountPrice: number | null;
  sizePrice?: number | null;
  sizeDiscountPrice?: number | null;
  quantity: number;
}

export interface ComputedLinePrice {
  originalUnitPrice: number;
  effectiveUnitPrice: number;
  lineSubtotal: number;
  offerDiscountPerUnit: number;
  appliedOfferTitle: string | null;
}

export interface OrderCalculationResult {
  subtotal: number;
  discount: number;
  deliveryCharge: number;
  totalAmount: number;
}

export interface CartEntry {
  productId: string;
  sizeId: string | null;
  quantity: number;
}

export function roundBdt(amount: number): number {
  return Math.round((amount + Number.EPSILON) * 100) / 100;
}

export function formatBdt(amount: number | string | null | undefined): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : Number(amount ?? 0);
  if (Number.isNaN(num)) return '৳0';
  const rounded = roundBdt(num);
  const formatted = Number.isInteger(rounded)
    ? rounded.toLocaleString('en-BD')
    : rounded.toLocaleString('en-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `৳${formatted}`;
}

export function isWithinSchedule(
  isActive: boolean,
  startDate: string | Date | null | undefined,
  endDate: string | Date | null | undefined,
  now: Date = new Date()
): boolean {
  if (!isActive) return false;
  if (startDate) {
    const start = new Date(startDate);
    if (!Number.isNaN(start.getTime()) && now < start) return false;
  }
  if (endDate) {
    const end = new Date(endDate);
    if (!Number.isNaN(end.getTime()) && now > end) return false;
  }
  return true;
}

export function computeEffectivePrice(
  item: PricedItemInput,
  offers: ActiveOfferInput[] = [],
  now: Date = new Date()
): ComputedLinePrice {
  const originalUnitPrice = roundBdt(
    item.sizePrice !== undefined && item.sizePrice !== null ? item.sizePrice : item.basePrice
  );
  const directDiscountPrice =
    item.sizePrice !== undefined && item.sizePrice !== null
      ? item.sizeDiscountPrice ?? null
      : item.discountPrice ?? null;

  let bestUnitPrice =
    directDiscountPrice !== null && directDiscountPrice < originalUnitPrice && directDiscountPrice >= 0
      ? roundBdt(directDiscountPrice)
      : originalUnitPrice;

  let appliedOfferTitle: string | null = null;
  const baselineForOffer = bestUnitPrice;

  for (const offer of offers) {
    if (!isWithinSchedule(offer.isActive, offer.startDate, offer.endDate, now)) continue;
    const applies =
      offer.applicableProductIds.length === 0 ||
      offer.applicableProductIds.includes(item.productId);
    if (!applies) continue;

    let candidate = baselineForOffer;
    if (offer.offerType === 'percentage' && offer.discountPercentage && offer.discountPercentage > 0) {
      const pct = Math.min(offer.discountPercentage, 95);
      candidate = roundBdt(baselineForOffer * (1 - pct / 100));
    } else if (
      (offer.offerType === 'fixed' || offer.offerType === 'combo' || offer.offerType === 'limited_time') &&
      offer.discountAmount &&
      offer.discountAmount > 0
    ) {
      candidate = roundBdt(Math.max(0, baselineForOffer - offer.discountAmount));
    } else if (offer.offerType === 'special_price' && offer.discountAmount && offer.discountAmount > 0) {
      candidate = roundBdt(offer.discountAmount);
    }

    if (candidate < bestUnitPrice) {
      bestUnitPrice = candidate;
      appliedOfferTitle = offer.title;
    }
  }

  const offerDiscountPerUnit = roundBdt(Math.max(0, baselineForOffer - bestUnitPrice));
  return {
    originalUnitPrice,
    effectiveUnitPrice: bestUnitPrice,
    lineSubtotal: roundBdt(bestUnitPrice * item.quantity),
    offerDiscountPerUnit,
    appliedOfferTitle,
  };
}

export function calculateOrderTotals(params: {
  lines: Array<{ effectiveUnitPrice: number; offerDiscountPerUnit?: number; quantity: number }>;
  orderType: 'home_delivery' | 'pickup' | 'dine_in';
  source: 'online' | 'pos';
  siteDeliveryCharge: number;
  extraDiscount?: number;
}): OrderCalculationResult {
  const subtotal = roundBdt(
    params.lines.reduce((acc, line) => acc + line.effectiveUnitPrice * line.quantity, 0)
  );
  const discount = roundBdt(Math.max(0, Math.min(params.extraDiscount ?? 0, subtotal)));
  const deliveryCharge = 0;
  const totalAmount = roundBdt(Math.max(0, subtotal - discount));

  return { subtotal, discount, deliveryCharge, totalAmount };
}

export function validateOrderInput(params: {
  items: Array<{ productId: string; quantity: number }>;
  orderType: string;
  source: 'online' | 'pos';
  deliveryAddress?: string | null;
  customerName?: string | null;
  customerPhone?: string | null;
}): string | null {
  if (!Array.isArray(params.items) || params.items.length === 0) {
    return 'Your order must include at least one item.';
  }
  for (const item of params.items) {
    if (!item.productId) return 'Invalid product in order.';
    if (!Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 50) {
      return 'Item quantity must be between 1 and 50.';
    }
  }
  if (params.source === 'pos' && params.orderType === 'home_delivery') {
    return 'POS orders do not support home delivery. Choose Pickup or Dine-In.';
  }
  if (!['home_delivery', 'pickup', 'dine_in'].includes(params.orderType)) {
    return 'Invalid order type selected.';
  }
  if (params.source === 'online' && params.orderType === 'home_delivery') {
    if (!params.customerName || params.customerName.trim().length < 2) {
      return 'Please enter your full name for home delivery.';
    }
    if (!params.customerPhone || params.customerPhone.trim().length < 6) {
      return 'Please enter a valid mobile number for home delivery.';
    }
    if (!params.deliveryAddress || params.deliveryAddress.trim().length < 5) {
      return 'Delivery address is required for Home Delivery (at least 5 characters).';
    }
  }
  return null;
}

export function mergeCartEntries(existing: CartEntry[], incoming: CartEntry[]): CartEntry[] {
  const map = new Map<string, CartEntry>();
  const keyOf = (e: CartEntry) => `${e.productId}::${e.sizeId ?? 'base'}`;

  for (const item of existing) {
    if (item.quantity <= 0) continue;
    const key = keyOf(item);
    const prev = map.get(key);
    map.set(key, {
      productId: item.productId,
      sizeId: item.sizeId ?? null,
      quantity: Math.min(50, (prev?.quantity ?? 0) + item.quantity),
    });
  }

  for (const item of incoming) {
    if (item.quantity <= 0) continue;
    const key = keyOf(item);
    const prev = map.get(key);
    map.set(key, {
      productId: item.productId,
      sizeId: item.sizeId ?? null,
      quantity: Math.min(50, (prev?.quantity ?? 0) + item.quantity),
    });
  }

  return Array.from(map.values());
}

export function formatDhakaDateTime(dateInput: string | Date): {
  dateStr: string;
  timeStr: string;
  yymmdd: string;
  isoDate: string;
} {
  const d = new Date(dateInput);
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Dhaka',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  }).formatToParts(d);

  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? '00';
  const year = get('year');
  const month = get('month');
  const day = get('day');
  const hour = get('hour');
  const minute = get('minute');
  const second = get('second');

  const time12 = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Dhaka',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  }).format(d);

  return {
    dateStr: `${day}/${month}/${year}`,
    timeStr: time12,
    yymmdd: `${year.slice(-2)}${month}${day}`,
    isoDate: `${year}-${month}-${day}`,
  };
}

export function generateReceiptNumber(orderNumber: number, dateInput: Date = new Date()): string {
  const { yymmdd } = formatDhakaDateTime(dateInput);
  return `SPZ-${yymmdd}-${orderNumber}`;
}
