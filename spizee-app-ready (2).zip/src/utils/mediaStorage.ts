import crypto from 'node:crypto';

export const ALLOWED_UPLOAD_BUCKETS = new Set([
  'product-images',
  'banners',
  'site-assets',
  'avatars',
]);

export const ALLOWED_IMAGE_MIME_MAP: Record<string, string> = {
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/gif': '.gif',
};

export function isAllowedUploadBucket(bucket: string): boolean {
  return ALLOWED_UPLOAD_BUCKETS.has(bucket);
}

export function resolveImageExtension(mimeType: string): string | null {
  return ALLOWED_IMAGE_MIME_MAP[mimeType] ?? null;
}

export function buildMediaStoragePath(
  bucket: string,
  filename: string,
  userId?: string | null
): string {
  if (bucket === 'avatars') {
    const safeUser = String(userId || 'user').replace(/[^a-zA-Z0-9_-]/g, '');
    return `avatars/${safeUser}/${filename}`;
  }
  return `${bucket}/${filename}`;
}

/**
 * Validates and normalizes a path requested under `/uploads/<path>`.
 * Returns null if the path contains traversal, null bytes, or an unrecognized bucket.
 */
export function normalizeUploadRequestPath(rawPath: string): string | null {
  const trimmed = String(rawPath || '').replace(/^\/+/, '').trim();
  if (!trimmed || trimmed.includes('\0') || trimmed.includes('\\')) {
    return null;
  }

  const segments = trimmed.split('/').filter(Boolean);
  if (segments.length < 2 || segments.length > 3) {
    return null;
  }

  for (const seg of segments) {
    if (seg === '.' || seg === '..' || !/^[a-zA-Z0-9._-]+$/.test(seg)) {
      return null;
    }
  }

  const bucket = segments[0];
  if (!ALLOWED_UPLOAD_BUCKETS.has(bucket)) {
    return null;
  }
  if (bucket === 'avatars' && segments.length !== 3) {
    return null;
  }
  if (bucket !== 'avatars' && segments.length !== 2) {
    return null;
  }

  return segments.join('/');
}

export function computeMediaEtag(storagePath: string, sizeBytes: number): string {
  const hash = crypto
    .createHash('sha1')
    .update(`${storagePath}:${sizeBytes}`)
    .digest('hex')
    .slice(0, 16);
  return `"${hash}"`;
}
