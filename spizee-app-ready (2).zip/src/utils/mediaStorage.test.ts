import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildMediaStoragePath,
  computeMediaEtag,
  isAllowedUploadBucket,
  normalizeUploadRequestPath,
  resolveImageExtension,
} from './mediaStorage';

test('isAllowedUploadBucket permits only configured storefront/avatar buckets', () => {
  assert.equal(isAllowedUploadBucket('product-images'), true);
  assert.equal(isAllowedUploadBucket('banners'), true);
  assert.equal(isAllowedUploadBucket('site-assets'), true);
  assert.equal(isAllowedUploadBucket('avatars'), true);
  assert.equal(isAllowedUploadBucket('scripts'), false);
  assert.equal(isAllowedUploadBucket('../etc'), false);
});

test('resolveImageExtension maps supported image MIME types and rejects others', () => {
  assert.equal(resolveImageExtension('image/jpeg'), '.jpg');
  assert.equal(resolveImageExtension('image/png'), '.png');
  assert.equal(resolveImageExtension('image/webp'), '.webp');
  assert.equal(resolveImageExtension('image/gif'), '.gif');
  assert.equal(resolveImageExtension('image/svg+xml'), null);
  assert.equal(resolveImageExtension('application/octet-stream'), null);
});

test('buildMediaStoragePath builds consistent paths for storefront and avatar uploads', () => {
  assert.equal(
    buildMediaStoragePath('site-assets', '12345-abc.png'),
    'site-assets/12345-abc.png'
  );
  assert.equal(
    buildMediaStoragePath('avatars', '12345-abc.jpg', 'user-123'),
    'avatars/user-123/12345-abc.jpg'
  );
});

test('normalizeUploadRequestPath accepts valid upload paths and blocks traversal', () => {
  assert.equal(
    normalizeUploadRequestPath('/site-assets/1795192366413-40a6e1091494.png'),
    'site-assets/1795192366413-40a6e1091494.png'
  );
  assert.equal(
    normalizeUploadRequestPath('product-images/1795194973622-ca1af254cc02.png'),
    'product-images/1795194973622-ca1af254cc02.png'
  );
  assert.equal(
    normalizeUploadRequestPath('avatars/d9deb3cf-4f3d/1234-abcd.webp'),
    'avatars/d9deb3cf-4f3d/1234-abcd.webp'
  );

  // Reject traversal, invalid buckets, wrong depth, or special chars
  assert.equal(normalizeUploadRequestPath('../.env'), null);
  assert.equal(normalizeUploadRequestPath('site-assets/../secret.txt'), null);
  assert.equal(normalizeUploadRequestPath('unknown-bucket/file.png'), null);
  assert.equal(normalizeUploadRequestPath('avatars/no-user-dir.png'), null);
  assert.equal(normalizeUploadRequestPath('site-assets/a/b.png'), null);
  assert.equal(normalizeUploadRequestPath('site-assets/bad\0file.png'), null);
});

test('computeMediaEtag is deterministic and quoted', () => {
  const a = computeMediaEtag('site-assets/logo.png', 4096);
  const b = computeMediaEtag('site-assets/logo.png', 4096);
  const c = computeMediaEtag('site-assets/logo.png', 4097);
  assert.equal(a, b);
  assert.notEqual(a, c);
  assert.equal(a.startsWith('"') && a.endsWith('"'), true);
});
