import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  CheckCircle2,
  Download,
  MapPin,
  Printer,
  Store,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiFetch } from '../lib/api';
import {
  calculateOrderTotals,
  computeEffectivePrice,
  formatBdt,
  validateOrderInput,
} from '../utils/orderMath';
import { downloadReceiptPdf, printReceiptHtml } from '../utils/receiptPdf';
import { ReceiptPaper } from '../components/ReceiptPaper';
import type { OrderDetail } from '../types';

export const CheckoutPage: React.FC = () => {
  const {
    user,
    cartItems,
    buyNowItem,
    setBuyNowItem,
    products,
    offers,
    settings,
    clearCart,
    showToast,
  } = useApp();
  const navigate = useNavigate();

  const activeEntries = useMemo(
    () => (buyNowItem ? [buyNowItem] : cartItems),
    [buyNowItem, cartItems]
  );

  const [orderType, setOrderType] = useState<'pickup' | 'home_delivery'>('pickup');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [receiptActionBusy, setReceiptActionBusy] = useState<'download' | 'print' | null>(null);
  const [placedOrder, setPlacedOrder] = useState<OrderDetail | null>(null);
  const [showReceiptModal, setShowReceiptModal] = useState(false);

  useEffect(() => {
    if (user) {
      setCustomerName((prev) => prev || user.fullName || '');
      setCustomerPhone((prev) => prev || user.phone || '');
      setDeliveryAddress((prev) => prev || user.address || '');
    }
  }, [user]);

  const enrichedLines = useMemo(() => {
    return activeEntries
      .map((entry) => {
        const prod = products.find((p) => p.id === entry.productId);
        if (!prod) return null;
        const size =
          (entry.sizeId ? prod.sizes.find((s) => s.id === entry.sizeId) : undefined) ||
          prod.sizes[0];
        const priced = computeEffectivePrice(
          {
            productId: prod.id,
            basePrice: prod.basePrice,
            discountPrice: prod.discountPrice,
            sizePrice: size ? size.price : null,
            sizeDiscountPrice: size ? size.discountPrice : null,
            quantity: entry.quantity,
          },
          offers
        );
        return {
          ...entry,
          resolvedSizeId: size?.id ?? null,
          productName: prod.name,
          sizeLabel: size?.label || null,
          ...priced,
        };
      })
      .filter((x): x is NonNullable<typeof x> => x !== null);
  }, [activeEntries, products, offers]);

  const totals = useMemo(
    () =>
      calculateOrderTotals({
        lines: enrichedLines.map((l) => ({
          effectiveUnitPrice: l.effectiveUnitPrice,
          quantity: l.quantity,
        })),
        orderType,
        source: 'online',
        siteDeliveryCharge: 0,
      }),
    [enrichedLines, orderType]
  );

  // If no active items AND no just-completed order receipt to display
  if (enrichedLines.length === 0 && !placedOrder) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <div className="glass-surface rounded-3xl p-10">
          <h1 className="font-display text-2xl font-bold text-[#1C1917]">No items to checkout</h1>
          <p className="mt-2 text-sm text-stone-600">
            Add delicious SPIZEE dishes to your cart first.
          </p>
          <Link
            to="/menu"
            className="mt-6 inline-block rounded-xl bg-[#F5B800] px-6 py-3 text-sm font-bold text-[#1C1917]"
          >
            Browse Menu
          </Link>
        </div>
      </div>
    );
  }

  const createOrReuseOrder = async (): Promise<OrderDetail | null> => {
    if (placedOrder) {
      return placedOrder;
    }

    setError(null);
    const validationErr = validateOrderInput({
      items: activeEntries.map((i) => ({ productId: i.productId, quantity: i.quantity })),
      orderType,
      source: 'online',
      customerName,
      customerPhone,
      deliveryAddress,
    });
    if (validationErr) {
      setError(validationErr);
      return null;
    }

    const data = await apiFetch<{ order: OrderDetail }>('/api/orders', {
      method: 'POST',
      body: JSON.stringify({
        items: enrichedLines.map((i) => ({
          productId: i.productId,
          sizeId: i.resolvedSizeId,
          quantity: i.quantity,
        })),
        orderType,
        deliveryAddress: orderType === 'home_delivery' ? deliveryAddress.trim() : null,
        customerName:
          customerName.trim() || (orderType === 'home_delivery' ? '' : 'Walk-in Customer'),
        customerPhone: customerPhone.trim() || null,
        paymentMethod,
        notes: notes.trim() || null,
      }),
    });

    if (buyNowItem) {
      setBuyNowItem(null);
    } else {
      clearCart();
    }
    return data.order;
  };

  const handleConfirmOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting || receiptActionBusy) return;

    if (placedOrder) {
      navigate(`/order/${placedOrder.id}`);
      return;
    }

    setSubmitting(true);
    try {
      const order = await createOrReuseOrder();
      if (!order) return;
      showToast(`Order #${order.orderNumber} confirmed!`, 'success');
      navigate(`/order/${order.id}`);
    } catch (err: any) {
      setError(err.message || 'Failed to place order. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDownloadReceiptAction = async () => {
    if (submitting || receiptActionBusy) return;
    setReceiptActionBusy('download');
    try {
      const order = await createOrReuseOrder();
      if (!order) return;
      setPlacedOrder(order);
      setShowReceiptModal(true);
      await downloadReceiptPdf(order, settings);
      showToast(`Order #${order.orderNumber} confirmed & receipt PDF downloaded!`, 'success');
    } catch (err: any) {
      setError(err.message || 'Could not download receipt. Please try again.');
    } finally {
      setReceiptActionBusy(null);
    }
  };

  const handlePrintReceiptAction = async () => {
    if (submitting || receiptActionBusy) return;
    setReceiptActionBusy('print');
    try {
      const order = await createOrReuseOrder();
      if (!order) return;
      setPlacedOrder(order);
      setShowReceiptModal(true);
      showToast(`Order #${order.orderNumber} confirmed & sent to printer!`, 'success');
      await printReceiptHtml(order, settings);
    } catch (err: any) {
      setError(err.message || 'Could not prepare receipt for printing.');
    } finally {
      setReceiptActionBusy(null);
    }
  };

  const isHomeDelivery = orderType === 'home_delivery';

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      {/* Main checkout UI hidden when printing the thermal receipt */}
      <div className="no-print">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-3xl font-extrabold text-[#1C1917]">Checkout</h1>
            <p className="mt-1 text-sm text-stone-600">
              {user
                ? 'All order totals are verified securely on our server before issuing your dual-copy receipt.'
                : 'No sign-up required — order directly as a guest and get your official SPIZEE Customer + Kitchen receipt instantly.'}
            </p>
          </div>
          {buyNowItem && !placedOrder && (
            <button
              type="button"
              onClick={() => setBuyNowItem(null)}
              className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50"
            >
              Switch to Full Cart ({cartItems.length})
            </button>
          )}
        </div>

        {placedOrder ? (
          <div className="mt-8 glass-surface rounded-3xl p-8 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
              <CheckCircle2 className="h-7 w-7" />
            </div>
            <h2 className="mt-4 font-display text-2xl font-extrabold text-[#1C1917]">
              Order #{placedOrder.orderNumber} Confirmed
            </h2>
            <p className="mt-1.5 text-sm text-stone-600">
              Dual-copy receipt{' '}
              <span className="font-mono font-bold text-[#1C1917]">
                {placedOrder.receipt?.receiptNumber}
              </span>{' '}
              (Customer Copy + Kitchen Copy) is saved and ready.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={handlePrintReceiptAction}
                disabled={receiptActionBusy !== null}
                className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white shadow-xs transition hover:bg-emerald-700 disabled:opacity-60"
              >
                <Printer className="h-4 w-4" />
                {receiptActionBusy === 'print' ? 'Printing…' : 'Print Receipt'}
              </button>
              <button
                type="button"
                onClick={handleDownloadReceiptAction}
                disabled={receiptActionBusy !== null}
                className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-[#F5B800] px-5 py-2.5 text-sm font-bold text-[#1C1917] shadow-xs transition hover:bg-[#E0A700] disabled:opacity-60"
              >
                <Download className="h-4 w-4" />
                {receiptActionBusy === 'download' ? 'Downloading…' : 'Download Receipt (PDF)'}
              </button>
              <button
                type="button"
                onClick={() => setShowReceiptModal(true)}
                className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-stone-300 bg-white px-5 py-2.5 text-sm font-semibold text-[#1C1917] hover:bg-stone-50"
              >
                View Receipt
              </button>
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 rounded-xl border border-stone-200 bg-[#FFF9E6] px-5 py-2.5 text-sm font-semibold text-[#1C1917] hover:bg-[#FFF3C4]"
              >
                Order More Food
              </Link>
            </div>
          </div>
        ) : (
          <form onSubmit={handleConfirmOrder} className="mt-8 grid gap-8 lg:grid-cols-12" noValidate>
            <div className="space-y-6 lg:col-span-7">
              {error && (
                <div
                  role="alert"
                  className="flex items-start gap-2.5 rounded-2xl border border-red-200 bg-red-50 px-4 py-3.5 text-sm font-medium text-red-800"
                >
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Order Type Selector: 1. Instant Pickup (Default), 2. Home Delivery */}
              <div className="glass-surface rounded-3xl p-6">
                <h2 className="font-display text-lg font-bold text-[#1C1917]">1. Order Type</h2>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  {(
                    [
                      {
                        id: 'pickup',
                        label: 'Instant Pickup',
                        sub: 'Instant Receipt · No delivery address',
                        icon: Store,
                      },
                      {
                        id: 'home_delivery',
                        label: 'Home Delivery',
                        sub: 'Delivered to your doorstep',
                        icon: MapPin,
                      },
                    ] as const
                  ).map((opt) => {
                    const Icon = opt.icon;
                    const active = orderType === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => {
                          setOrderType(opt.id);
                          setError(null);
                        }}
                        className={`flex cursor-pointer flex-col items-start rounded-2xl border p-4 text-left transition ${
                          active
                            ? 'border-[#1C1917] bg-[#FFF8DC] shadow-xs'
                            : 'border-stone-200 bg-white hover:border-[#F5B800]'
                        }`}
                      >
                        <Icon className={`h-5 w-5 ${active ? 'text-[#B47B00]' : 'text-stone-500'}`} />
                        <span className="mt-2 font-display text-sm font-bold text-[#1C1917]">
                          {opt.label}
                        </span>
                        <span className="mt-0.5 text-xs text-stone-500">{opt.sub}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Customer Details */}
              <div className="glass-surface rounded-3xl p-6">
                <h2 className="font-display text-lg font-bold text-[#1C1917]">2. Customer Details</h2>
                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="chk-name" className="block text-xs font-semibold text-stone-700">
                      Full Name {isHomeDelivery ? '*' : '(Optional)'}
                    </label>
                    <input
                      id="chk-name"
                      type="text"
                      required={isHomeDelivery}
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder={isHomeDelivery ? 'Your full name' : 'Your name (optional)'}
                      className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label htmlFor="chk-phone" className="block text-xs font-semibold text-stone-700">
                      Mobile Number {isHomeDelivery ? '*' : '(Optional)'}
                    </label>
                    <input
                      id="chk-phone"
                      type="tel"
                      required={isHomeDelivery}
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="017XX-XXXXXX"
                      className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                    />
                  </div>
                </div>

                {isHomeDelivery ? (
                  <div className="mt-4">
                    <label
                      htmlFor="chk-address"
                      className="block text-xs font-semibold text-stone-700"
                    >
                      Delivery Address *
                    </label>
                    <textarea
                      id="chk-address"
                      rows={3}
                      required
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="House, Road, Area, Floor / Landmark in Dhaka"
                      className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                    />
                  </div>
                ) : (
                  <div className="mt-4 rounded-2xl bg-[#FFF9E6] px-4 py-3 text-xs text-stone-700">
                    <span className="font-semibold text-[#1C1917]">No delivery address needed.</span>{' '}
                    Collect your order fresh at {settings?.address || 'SPIZEE Kitchen'}. Click{' '}
                    <strong>Confirm Order</strong>, <strong>Download Receipt</strong>, or{' '}
                    <strong>Print Receipt</strong> to confirm immediately with a tear-off Customer +
                    Kitchen copy.
                  </div>
                )}

                <div className="mt-4 grid gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="chk-payment" className="block text-xs font-semibold text-stone-700">
                      Payment Method
                    </label>
                    <select
                      id="chk-payment"
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                    >
                      <option value="cash">Cash on Delivery / Counter</option>
                      <option value="bkash">bKash (Pay on Delivery/Counter)</option>
                      <option value="nagad">Nagad (Pay on Delivery/Counter)</option>
                      <option value="card">Card at Counter</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="chk-notes" className="block text-xs font-semibold text-stone-700">
                      Order Notes (Optional)
                    </label>
                    <input
                      id="chk-notes"
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Extra spicy, less sauce, ring bell…"
                      className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Summary Column */}
            <aside className="glass-surface h-fit rounded-3xl p-6 lg:col-span-5">
              <h2 className="font-display text-lg font-bold text-[#1C1917]">Order Summary</h2>
              <ul className="mt-4 divide-y divide-stone-200/80 text-sm">
                {enrichedLines.map((line) => (
                  <li
                    key={`${line.productId}-${line.sizeId ?? 'base'}`}
                    className="flex items-start justify-between gap-3 py-3"
                  >
                    <div>
                      <p className="font-semibold text-[#1C1917]">{line.productName}</p>
                      <p className="text-xs text-stone-500 tabular-nums">
                        {line.sizeLabel ? `${line.sizeLabel} · ` : ''}
                        {line.quantity} × {formatBdt(line.effectiveUnitPrice)}
                      </p>
                    </div>
                    <span className="font-mono font-semibold text-[#1C1917] tabular-nums">
                      {formatBdt(line.lineSubtotal)}
                    </span>
                  </li>
                ))}
              </ul>

              <dl className="mt-4 space-y-2 border-t border-stone-200 pt-4 text-sm tabular-nums">
                <div className="flex justify-between">
                  <dt className="text-stone-600">Subtotal</dt>
                  <dd className="font-mono font-semibold">{formatBdt(totals.subtotal)}</dd>
                </div>
                <div className="flex justify-between border-t border-stone-200 pt-3 text-base font-bold">
                  <dt>Total Payable</dt>
                  <dd className="font-mono text-lg text-[#1C1917]">{formatBdt(totals.totalAmount)}</dd>
                </div>
              </dl>

              {/* All 3 actions confirm the order immediately: Confirm Order, Download Receipt, Print Receipt */}
              <div className="mt-6 space-y-2.5">
                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                  <button
                    type="submit"
                    disabled={submitting || receiptActionBusy !== null}
                    className="flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-[#F5B800] px-4 py-3.5 text-sm font-bold text-[#1C1917] shadow-xs transition hover:bg-[#E0A700] disabled:opacity-60 whitespace-nowrap"
                  >
                    <CheckCircle2 className="h-4 w-4 shrink-0" />
                    {submitting ? 'Confirming…' : 'Confirm Order'}
                  </button>
                  <button
                    type="button"
                    disabled={submitting || receiptActionBusy !== null}
                    onClick={handleDownloadReceiptAction}
                    className="flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-[#1C1917] px-4 py-3.5 text-sm font-bold text-white shadow-xs transition hover:bg-stone-800 disabled:opacity-60 whitespace-nowrap"
                  >
                    <Download className="h-4 w-4 shrink-0" />
                    {receiptActionBusy === 'download' ? 'Downloading…' : 'Download Receipt'}
                  </button>
                </div>
                <button
                  type="button"
                  disabled={submitting || receiptActionBusy !== null}
                  onClick={handlePrintReceiptAction}
                  className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-3.5 text-sm font-bold text-white shadow-xs transition hover:bg-emerald-700 disabled:opacity-60 whitespace-nowrap"
                >
                  <Printer className="h-4 w-4 shrink-0" />
                  {receiptActionBusy === 'print' ? 'Confirming & Printing…' : 'Print Receipt'}
                </button>
                <p className="text-center text-[11px] text-stone-500">
                  Clicking any button confirms your order and issues a single-page Customer Copy +
                  Kitchen Copy receipt.
                </p>
              </div>
            </aside>
          </form>
        )}
      </div>

      {/* Dual-Copy Receipt Modal */}
      {placedOrder && showReceiptModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Order receipt"
          className="print-modal-backdrop fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-stone-900/45 p-4 backdrop-blur-xs"
          onClick={() => setShowReceiptModal(false)}
        >
          <div
            className="print-modal-card relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-3xl bg-[#FFFDF7] px-6 pb-6 pt-12 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setShowReceiptModal(false)}
              aria-label="Close receipt"
              className="no-print absolute right-4 top-4 inline-flex h-8 w-8 cursor-pointer items-center justify-center rounded-full bg-white text-stone-700 shadow hover:bg-stone-100"
            >
              <X className="h-4 w-4" />
            </button>
            <ReceiptPaper order={placedOrder} settings={settings} showActions />
          </div>
        </div>
      )}
    </div>
  );
};
