import { isNativeApp } from '../lib/native';
import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { AlertCircle, CheckCircle2, Eye, EyeOff, Lock, Mail, Phone, User } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiFetch } from '../lib/api';
import { SpizeeLogo } from '../components/SpizeeLogo';

// Optional Phone OTP login feature flag (OFF by default as it requires an SMS provider)
const ENABLE_PHONE_OTP = false;

export const LoginPage: React.FC = () => {
  const { signInWithEmail, signUpWithEmail, signInWithGoogle, showToast } = useApp();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const redirect = searchParams.get('redirect');

  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const routeAfterAuth = (role: 'customer' | 'admin' | 'manager') => {
    if (role === 'admin' || role === 'manager') {
      navigate('/admin', { replace: true });
    } else if (redirect && redirect.startsWith('/')) {
      navigate(redirect, { replace: true });
    } else {
      navigate('/profile', { replace: true });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setInfo(null);

    if (mode === 'forgot') {
      if (!email.trim()) {
        setError('Please enter your email address.');
        return;
      }
      setBusy(true);
      try {
        const res = await apiFetch<{ message: string }>('/api/auth/forgot-password', {
          method: 'POST',
          body: JSON.stringify({ email }),
        });
        setInfo(res.message);
      } catch (err: any) {
        setError(err.message || 'Could not process reset request.');
      } finally {
        setBusy(false);
      }
      return;
    }

    if (mode === 'signup') {
      if (fullName.trim().length < 2) {
        setError('Please enter your full name.');
        return;
      }
      if (password.length < 6) {
        setError('Password must be at least 6 characters.');
        return;
      }
      setBusy(true);
      try {
        const profile = await signUpWithEmail({
          fullName: fullName.trim(),
          email: email.trim(),
          phone: phone.trim(),
          address: address.trim(),
          password,
        });
        showToast('Welcome to SPIZEE!', 'success');
        routeAfterAuth(profile.role);
      } catch (err: any) {
        setError(err.message || 'Sign up failed.');
      } finally {
        setBusy(false);
      }
      return;
    }

    setBusy(true);
    try {
      const profile = await signInWithEmail(email.trim(), password);
      showToast(`Signed in as ${profile.fullName || profile.email}`, 'success');
      routeAfterAuth(profile.role);
    } catch (err: any) {
      setError(err.message || 'Invalid email or password.');
    } finally {
      setBusy(false);
    }
  };

  const handleGoogle = async () => {
    setError(null);
    setBusy(true);
    try {
      const profile = await signInWithGoogle();
      showToast(`Signed in with Google as ${profile.fullName || profile.email}`, 'success');
      routeAfterAuth(profile.role);
    } catch (err: any) {
      setError(err.message || 'Google sign-in was cancelled or failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-4 py-12 sm:py-16">
      <div className="mb-6">
        <SpizeeLogo size="lg" />
      </div>

      <div className="glass-surface w-full rounded-3xl p-7 sm:p-8">
        <div className="grid grid-cols-2 gap-1 rounded-xl border border-stone-200 bg-stone-50 p-1">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError(null);
              setInfo(null);
            }}
            className={`rounded-lg py-2 text-xs font-bold transition ${
              mode === 'login' ? 'bg-[#F5B800] text-[#1C1917] shadow-xs' : 'text-stone-600'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setError(null);
              setInfo(null);
            }}
            className={`rounded-lg py-2 text-xs font-bold transition ${
              mode === 'signup' ? 'bg-[#F5B800] text-[#1C1917] shadow-xs' : 'text-stone-600'
            }`}
          >
            Create Account
          </button>
        </div>

        <h1 className="mt-5 font-display text-2xl font-bold text-[#1C1917]">
          {mode === 'login'
            ? 'Welcome back'
            : mode === 'signup'
            ? 'Join SPIZEE'
            : 'Reset password'}
        </h1>
        <p className="mt-1 text-xs text-stone-500">
          {mode === 'login'
            ? 'Sign in to track your orders and access saved receipts.'
            : mode === 'signup'
            ? 'Create an account to save your delivery details and order history.'
            : 'Enter your email address to request a password reset.'}
        </p>

        {error && (
          <div
            role="alert"
            className="mt-4 flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-800"
          >
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {info && (
          <div className="mt-4 flex items-start gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2.5 text-xs font-medium text-emerald-800">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
            <span>{info}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {mode === 'signup' && (
            <div>
              <label htmlFor="auth-name" className="block text-xs font-semibold text-stone-700">
                Full Name *
              </label>
              <div className="relative mt-1">
                <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
                <input
                  id="auth-name"
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Your full name"
                  className="w-full rounded-xl border border-stone-200 bg-white py-2.5 pl-9 pr-3 text-sm focus:border-[#F5B800] focus:outline-none"
                />
              </div>
            </div>
          )}

          <div>
            <label htmlFor="auth-email" className="block text-xs font-semibold text-stone-700">
              Email Address *
            </label>
            <div className="relative mt-1">
              <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
              <input
                id="auth-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-xl border border-stone-200 bg-white py-2.5 pl-9 pr-3 text-sm focus:border-[#F5B800] focus:outline-none"
              />
            </div>
          </div>

          {mode === 'signup' && (
            <>
              <div>
                <label htmlFor="auth-phone" className="block text-xs font-semibold text-stone-700">
                  Mobile Number
                </label>
                <div className="relative mt-1">
                  <Phone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
                  <input
                    id="auth-phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="017XX-XXXXXX"
                    className="w-full rounded-xl border border-stone-200 bg-white py-2.5 pl-9 pr-3 text-sm focus:border-[#F5B800] focus:outline-none"
                  />
                </div>
              </div>
              <div>
                <label
                  htmlFor="auth-address"
                  className="block text-xs font-semibold text-stone-700"
                >
                  Delivery Address (Optional)
                </label>
                <input
                  id="auth-address"
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="House, Road, Area"
                  className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                />
              </div>
            </>
          )}

          {mode !== 'forgot' && (
            <div>
              <div className="flex items-center justify-between">
                <label
                  htmlFor="auth-password"
                  className="block text-xs font-semibold text-stone-700"
                >
                  Password *
                </label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-xs font-semibold text-[#B47B00] hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative mt-1">
                <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
                <input
                  id="auth-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  className="w-full rounded-xl border border-stone-200 bg-white py-2.5 pl-9 pr-10 text-sm focus:border-[#F5B800] focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-lg p-1 text-stone-400 hover:text-stone-700"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-xl bg-[#F5B800] py-3 text-sm font-bold text-[#1C1917] transition hover:bg-[#E0A700] disabled:opacity-60"
          >
            {busy
              ? 'Please wait…'
              : mode === 'login'
              ? 'Sign In'
              : mode === 'signup'
              ? 'Create Customer Account'
              : 'Request Password Reset'}
          </button>
        </form>

        {mode !== 'forgot' && (
          <>
            <div className="my-5 flex items-center gap-3">
              <div className="h-px flex-1 bg-stone-200" />
              <span className="text-xs font-medium text-stone-400">or</span>
              <div className="h-px flex-1 bg-stone-200" />
            </div>

            {!isNativeApp && (
            <button
              type="button"
              disabled={busy}
              onClick={handleGoogle}
              className="flex w-full items-center justify-center gap-2.5 rounded-xl border border-stone-300 bg-white py-2.5 text-sm font-semibold text-[#1C1917] transition hover:bg-stone-50 disabled:opacity-60"
            >
              <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.79-.07-1.54-.19-2.27h-11.3v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
                />
                <path
                  fill="#34A853"
                  d="M12.255 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96h-3.98v3.09C3.515 21.3 7.565 24 12.255 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.525 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62h-3.98a11.86 11.86 0 000 10.76l3.98-3.09z"
                />
                <path
                  fill="#EA4335"
                  d="M12.255 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C18.205 1.19 15.495 0 12.255 0c-4.69 0-8.74 2.7-10.71 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
                />
              </svg>
              Continue with Google
            </button>
            )}

            {ENABLE_PHONE_OTP && (
              <button
                type="button"
                className="mt-2.5 w-full rounded-xl border border-stone-200 bg-stone-50 py-2.5 text-xs font-semibold text-stone-600"
              >
                Continue with Phone OTP
              </button>
            )}
          </>
        )}

        {mode === 'forgot' && (
          <button
            type="button"
            onClick={() => setMode('login')}
            className="mt-4 w-full text-center text-xs font-semibold text-stone-600 hover:text-[#1C1917]"
          >
            Back to Sign In
          </button>
        )}
      </div>
    </div>
  );
};
