import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { computeEffectivePrice, formatBdt } from '../utils/orderMath';
import { FoodImage } from '../components/FoodImage';

export const CartPage: React.FC = () => {
  const {
    cartItems,
    cartSubtotal,
    products,
    offers,
    updateCartQty,
    changeCartSize,
    removeFromCart,
    setBuyNowItem,
  } = useApp();
  const navigate = useNavigate();

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-extrabold text-[#1C1917]">Shopping Cart</h1>

      {cartItems.length === 0 ? (
        <div className="mt-8 rounded-3xl border border-stone-200 bg-white p-14 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#FFF3C4] text-[#B47B00]">
            <ShoppingBag className="h-8 w-8" />
          </div>
          <h2 className="mt-4 font-display text-xl font-bold text-[#1C1917]">
            Your cart is currently empty
          </h2>
          <p className="mt-2 text-sm text-stone-500">
            Add your favorite burgers, fried chicken, shawarma, or combos from our menu.
          </p>
          <Link
            to="/menu"
            className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#F5B800] px-6 py-3 text-sm font-bold text-[#1C1917] hover:bg-[#E0A700]"
          >
            Browse Menu
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-8 lg:grid-cols-12">
          <div className="glass-surface rounded-3xl p-6 lg:col-span-8">
            <ul className="divide-y divide-stone-200/80">
              {cartItems.map((entry) => {
                const prod = products.find((p) => p.id === entry.productId);
                if (!prod) return null;
                const size = entry.sizeId
                  ? prod.sizes.find((s) => s.id === entry.sizeId)
                  : undefined;
                const priced = computeEffectivePrice(
                  {
                    productId: prod.id,
                    basePrice: prod.basePrice,
                    discountPrice: prod.discountPrice,
                    sizePrice: size ? size.price : null,
                    sizeDiscountPrice: size ? size.discountPrice : null,
                    quantity: entry.quantity,
                  },
                  offers
                );

                return (
                  <li
                    key={`${entry.productId}-${entry.sizeId ?? 'base'}`}
                    className="flex flex-col gap-4 py-5 sm:flex-row sm:items-center"
                  >
                    <div className="h-24 w-24 shrink-0 overflow-hidden rounded-2xl bg-[#FAF6EA]">
                      <FoodImage
                        src={prod.imageUrl}
                        alt={prod.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h2 className="font-display text-base font-bold text-[#1C1917]">
                        {prod.name}
                      </h2>
                      <p className="mt-0.5 font-mono text-xs text-stone-500 tabular-nums">
                        Unit price: {formatBdt(priced.effectiveUnitPrice)}
                      </p>

                      {prod.sizes.length > 0 && (
                        <div className="mt-2">
                          <label className="mr-2 text-xs font-medium text-stone-500">Size:</label>
                          <select
                            aria-label={`Change size for ${prod.name}`}
                            value={entry.sizeId ?? ''}
                            onChange={(e) =>
                              changeCartSize(entry.productId, entry.sizeId, e.target.value || null)
                            }
                            className="rounded-lg border border-stone-200 bg-white px-2.5 py-1 text-xs font-semibold text-stone-800"
                          >
                            {prod.sizes.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.label}
                              </option>
                            ))}
                          </select>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-4 sm:flex-col sm:items-end">
                      <div className="inline-flex items-center rounded-xl border border-stone-200 bg-white">
                        <button
                          type="button"
                          aria-label={`Decrease quantity of ${prod.name}`}
                          onClick={() =>
                            updateCartQty(entry.productId, entry.sizeId, entry.quantity - 1)
                          }
                          className="inline-flex h-8 w-8 items-center justify-center hover:bg-stone-100"
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-8 text-center font-mono text-sm font-bold tabular-nums">
                          {entry.quantity}
                        </span>
                        <button
                          type="button"
                          aria-label={`Increase quantity of ${prod.name}`}
                          onClick={() =>
                            updateCartQty(entry.productId, entry.sizeId, entry.quantity + 1)
                          }
                          className="inline-flex h-8 w-8 items-center justify-center hover:bg-stone-100"
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="font-mono text-base font-bold text-[#1C1917] tabular-nums">
                          {formatBdt(priced.lineSubtotal)}
                        </span>
                        <button
                          type="button"
                          aria-label={`Remove ${prod.name}`}
                          onClick={() => removeFromCart(entry.productId, entry.sizeId)}
                          className="rounded-lg p-1.5 text-stone-400 hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>

          <aside className="glass-surface h-fit rounded-3xl p-6 lg:col-span-4">
            <h2 className="font-display text-lg font-bold text-[#1C1917]">Order Summary</h2>
            <dl className="mt-4 space-y-2.5 text-sm tabular-nums">
              <div className="flex justify-between">
                <dt className="text-stone-600">Subtotal</dt>
                <dd className="font-mono font-semibold text-[#1C1917]">{formatBdt(cartSubtotal)}</dd>
              </div>
              <div className="flex justify-between border-t border-stone-200 pt-3 text-base font-bold">
                <dt>Estimated Total</dt>
                <dd className="font-mono text-[#1C1917]">{formatBdt(cartSubtotal)}</dd>
              </div>
            </dl>

            <button
              type="button"
              onClick={() => {
                setBuyNowItem(null);
                navigate('/checkout');
              }}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-[#F5B800] px-5 py-3.5 text-sm font-bold text-[#1C1917] transition hover:bg-[#E0A700]"
            >
              Proceed to Checkout
              <ArrowRight className="h-4 w-4" />
            </button>

            <Link
              to="/menu"
              className="mt-3 block text-center text-xs font-semibold text-stone-600 hover:text-[#1C1917]"
            >
              Continue browsing menu
            </Link>
          </aside>
        </div>
      )}
    </div>
  );
};
