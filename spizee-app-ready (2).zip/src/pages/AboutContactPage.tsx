import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Clock, ExternalLink, Mail, MapPin, Phone, Truck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FoodImage } from '../components/FoodImage';

export const AboutPage: React.FC = () => {
  const { settings } = useApp();

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="grid items-stretch gap-8 lg:grid-cols-12">
        <div className="glass-surface flex flex-col justify-center rounded-3xl p-8 sm:p-10 lg:col-span-6">
          <p className="text-xs font-bold tracking-wide text-[#B47B00]">
            {settings?.restaurantName || 'SPIZEE'} · স্পাইজি
          </p>
          <h1 className="mt-2 font-display text-3xl font-extrabold text-[#1C1917] sm:text-4xl">
            Crafted Hot, Crispy &amp; Fresh to Order
          </h1>
          <p className="mt-4 text-sm leading-relaxed text-stone-600 sm:text-base">
            {settings?.shortDescription ||
              'SPIZEE (স্পাইজি) brings modern fast-food craft to Dhaka with signature 12-spice crispy fried chicken, toasted brioche zinger burgers, flame-grilled shawarma, and hand-stretched tandoori pizzas.'}
          </p>
          <p className="mt-3 text-sm leading-relaxed text-stone-600">
            Every order is fried fresh when placed — never sitting under heat lamps — and paired with house-blended sauces, generous portions, and honest BDT pricing.
          </p>

          <div className="mt-7 grid gap-4 border-t border-stone-200/80 pt-6 sm:grid-cols-2">
            <div>
              <p className="text-xs font-semibold text-stone-500">Opening Hours</p>
              <p className="mt-1 text-sm font-bold text-[#1C1917]">
                {settings?.openingHours || 'Daily: 11:00 AM – 11:30 PM'}
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-stone-500">Order Options</p>
              <p className="mt-1 text-sm font-bold text-[#1C1917]">
                Instant Pickup &amp; Home Delivery
              </p>
            </div>
          </div>

          <div className="mt-7 flex flex-wrap gap-3">
            <Link
              to="/menu"
              className="rounded-xl bg-[#F5B800] px-6 py-3 text-sm font-bold text-[#1C1917] hover:bg-[#E0A700]"
            >
              Explore Menu
            </Link>
            <Link
              to="/contact"
              className="rounded-xl border border-stone-300 bg-white px-5 py-3 text-sm font-semibold text-[#1C1917] hover:border-[#1C1917]"
            >
              Contact &amp; Location
            </Link>
          </div>
        </div>

        <div className="overflow-hidden rounded-3xl border border-stone-200/80 bg-[#FAF6EA] lg:col-span-6">
          <FoodImage
            src="/src/assets/images/hero_spizee_feast_1795162956502.webp"
            alt="SPIZEE kitchen feast"
            className="h-full min-h-[320px] w-full object-cover"
          />
        </div>
      </div>

      <div className="mt-10 grid gap-6 md:grid-cols-3">
        <div className="glass-surface rounded-2xl p-6">
          <Truck className="h-5 w-5 text-[#D99B00]" />
          <h2 className="mt-3 font-display text-lg font-bold text-[#1C1917]">Delivery Promise</h2>
          <p className="mt-2 text-sm leading-relaxed text-stone-600">
            {settings?.deliveryInfo ||
              'Fast, insulated home delivery and instant restaurant pickup options across the city.'}
          </p>
        </div>
        <div className="glass-surface rounded-2xl p-6">
          <MapPin className="h-5 w-5 text-[#D99B00]" />
          <h2 className="mt-3 font-display text-lg font-bold text-[#1C1917]">Flagship Kitchen</h2>
          <p className="mt-2 text-sm leading-relaxed text-stone-600">
            {settings?.address || 'Banani, Dhaka, Bangladesh'}
          </p>
        </div>
        <div className="glass-surface rounded-2xl p-6">
          <Phone className="h-5 w-5 text-[#D99B00]" />
          <h2 className="mt-3 font-display text-lg font-bold text-[#1C1917]">Direct Hotline</h2>
          <p className="mt-2 font-mono text-sm font-semibold text-[#1C1917] tabular-nums">
            {settings?.phone || '+880 1711-009988'}
          </p>
          <p className="mt-1 text-xs text-stone-500">{settings?.email || 'hello@spizee.com'}</p>
        </div>
      </div>
    </div>
  );
};

export const ContactPage: React.FC = () => {
  const { settings, showToast } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) {
      showToast('Please enter your name and message.', 'error');
      return;
    }
    showToast('Thank you! Your message has been sent to the SPIZEE team.', 'success');
    setName('');
    setPhone('');
    setMessage('');
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="max-w-2xl">
        <h1 className="font-display text-3xl font-extrabold text-[#1C1917] sm:text-4xl">
          Contact {settings?.restaurantName || 'SPIZEE'}
        </h1>
        <p className="mt-2 text-sm text-stone-600">
          Questions about bulk party orders, home delivery coverage, or feedback? Reach us directly.
        </p>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-12">
        <div className="space-y-4 lg:col-span-5">
          <div className="glass-surface rounded-2xl p-6">
            <h2 className="font-display text-lg font-bold text-[#1C1917]">Restaurant Details</h2>
            <dl className="mt-4 space-y-4 text-sm">
              <div className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#D99B00]" />
                <div>
                  <dt className="text-xs font-semibold text-stone-500">Address</dt>
                  <dd className="mt-0.5 text-[#1C1917]">
                    {settings?.address || 'House 24, Road 11, Banani, Dhaka'}
                  </dd>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-[#D99B00]" />
                <div>
                  <dt className="text-xs font-semibold text-stone-500">Phone / Hotline</dt>
                  <dd className="mt-0.5 font-mono text-[#1C1917] tabular-nums">
                    {settings?.phone || '+880 1711-009988'}
                  </dd>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-[#D99B00]" />
                <div>
                  <dt className="text-xs font-semibold text-stone-500">Email</dt>
                  <dd className="mt-0.5 text-[#1C1917]">{settings?.email || 'hello@spizee.com'}</dd>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="mt-0.5 h-4 w-4 shrink-0 text-[#D99B00]" />
                <div>
                  <dt className="text-xs font-semibold text-stone-500">Opening Hours</dt>
                  <dd className="mt-0.5 text-[#1C1917]">
                    {settings?.openingHours || 'Daily: 11:00 AM – 11:30 PM'}
                  </dd>
                </div>
              </div>
            </dl>

            {settings?.googleMapsUrl && (
              <a
                href={settings.googleMapsUrl}
                target="_blank"
                rel="noreferrer"
                className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#FFF3C4] px-4 py-2.5 text-xs font-bold text-[#1C1917] hover:bg-[#F5B800]"
              >
                View on Google Maps
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            )}
          </div>

          <div className="glass-yellow rounded-2xl p-6">
            <h3 className="font-display text-base font-bold text-[#1C1917]">Delivery Information</h3>
            <p className="mt-2 text-sm text-stone-700">
              {settings?.deliveryInfo ||
                'Fast home delivery and instant pickup available directly from our kitchen.'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="glass-surface rounded-3xl p-7 lg:col-span-7">
          <h2 className="font-display text-xl font-bold text-[#1C1917]">Send Us a Message</h2>
          <p className="mt-1 text-sm text-stone-500">
            We typically reply within a few hours during kitchen hours.
          </p>

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="contact-name" className="block text-xs font-semibold text-stone-700">
                Your Name *
              </label>
              <input
                id="contact-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Tariq Hasan"
                className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
              />
            </div>
            <div>
              <label htmlFor="contact-phone" className="block text-xs font-semibold text-stone-700">
                Phone Number
              </label>
              <input
                id="contact-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="017XX-XXXXXX"
                className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
              />
            </div>
          </div>

          <div className="mt-4">
            <label htmlFor="contact-message" className="block text-xs font-semibold text-stone-700">
              Message *
            </label>
            <textarea
              id="contact-message"
              rows={5}
              required
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell us how we can help…"
              className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
            />
          </div>

          <button
            type="submit"
            className="mt-5 rounded-xl bg-[#F5B800] px-6 py-3 text-sm font-bold text-[#1C1917] transition hover:bg-[#E0A700]"
          >
            Send Message
          </button>
        </form>
      </div>
    </div>
  );
};
