import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { Product } from '../types';
import { computeEffectivePrice } from '../utils/orderMath';
import { ProductCard } from '../components/ProductCard';
import { ProductModal } from '../components/ProductModal';

export const MenuPage: React.FC = () => {
  const { categories, products, offers, catalogLoading } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();

  const [selectedCategory, setSelectedCategory] = useState<string>(
    searchParams.get('category') || 'All'
  );
  const [searchQuery, setSearchQuery] = useState<string>(searchParams.get('q') || '');
  const [tagFilter, setTagFilter] = useState<'all' | 'popular' | 'new' | 'discount'>(
    (searchParams.get('filter') as any) || 'all'
  );
  const [priceSort, setPriceSort] = useState<'default' | 'low_to_high' | 'high_to_low'>('default');
  const [inspectProduct, setInspectProduct] = useState<Product | null>(null);

  useEffect(() => {
    const catParam = searchParams.get('category');
    if (catParam) setSelectedCategory(catParam);
    const filterParam = searchParams.get('filter');
    if (filterParam && ['all', 'popular', 'new', 'discount'].includes(filterParam)) {
      setTagFilter(filterParam as any);
    }
  }, [searchParams]);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const matched: Array<{ product: Product; effective: number }> = [];

    for (const p of products) {
      if (selectedCategory !== 'All' && (p.categoryName || '') !== selectedCategory) {
        continue;
      }
      if (
        q &&
        !p.name.toLowerCase().includes(q) &&
        !(p.description || '').toLowerCase().includes(q) &&
        !(p.categoryName || '').toLowerCase().includes(q)
      ) {
        continue;
      }

      const firstSize = p.sizes[0];
      const priced = computeEffectivePrice(
        {
          productId: p.id,
          basePrice: p.basePrice,
          discountPrice: p.discountPrice,
          sizePrice: firstSize ? firstSize.price : null,
          sizeDiscountPrice: firstSize ? firstSize.discountPrice : null,
          quantity: 1,
        },
        offers
      );
      const effective = priced.effectiveUnitPrice;

      if (tagFilter === 'popular' && !p.isPopular) continue;
      if (tagFilter === 'new' && !p.isNew) continue;
      if (tagFilter === 'discount' && effective >= priced.originalUnitPrice) continue;

      matched.push({ product: p, effective });
    }

    if (priceSort === 'low_to_high') {
      matched.sort((a, b) => a.effective - b.effective);
    } else if (priceSort === 'high_to_low') {
      matched.sort((a, b) => b.effective - a.effective);
    }

    return matched.map((m) => m.product);
  }, [products, selectedCategory, searchQuery, tagFilter, priceSort, offers]);

  const resetFilters = () => {
    setSelectedCategory('All');
    setSearchQuery('');
    setTagFilter('all');
    setPriceSort('default');
    setSearchParams({});
  };

  return (
    <div className="mx-auto max-w-7xl px-3 py-6 sm:px-6 sm:py-10 lg:px-8">
      <div className="flex flex-col justify-between gap-4 border-b border-stone-200/80 pb-6 md:flex-row md:items-end">
        <div>
          <h1 className="font-display text-3xl font-extrabold text-[#1C1917] sm:text-4xl">
            SPIZEE Menu
          </h1>
          <p className="mt-1.5 text-sm text-stone-600">
            Explore all freshly prepared burgers, crispy fried chicken, shawarma, pizzas, and value combos.
          </p>
        </div>

        {/* Live Search Input */}
        <div className="relative w-full md:w-80">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
          <label htmlFor="menu-search" className="sr-only">
            Search food items
          </label>
          <input
            id="menu-search"
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search Zinger, Chicken, Shawarma…"
            className="w-full rounded-xl border border-stone-200 bg-white py-2.5 pl-10 pr-9 text-sm text-[#1C1917] shadow-xs placeholder:text-stone-400 focus:border-[#F5B800] focus:outline-none"
          />
          {searchQuery && (
            <button
              type="button"
              aria-label="Clear search"
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-md p-1 text-stone-400 hover:text-stone-700"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      {/* Category Tabs & Filters */}
      <div className="mt-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-1.5" role="tablist" aria-label="Food categories">
          <button
            type="button"
            role="tab"
            aria-selected={selectedCategory === 'All'}
            onClick={() => setSelectedCategory('All')}
            className={`rounded-xl px-4 py-2 text-xs font-semibold transition whitespace-nowrap ${
              selectedCategory === 'All'
                ? 'bg-[#1C1917] text-white'
                : 'border border-stone-200 bg-white text-stone-700 hover:border-[#F5B800] hover:bg-[#FFF9E6]'
            }`}
          >
            All Items
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              role="tab"
              aria-selected={selectedCategory === cat.name}
              onClick={() => setSelectedCategory(cat.name)}
              className={`rounded-xl px-4 py-2 text-xs font-semibold transition whitespace-nowrap ${
                selectedCategory === cat.name
                  ? 'bg-[#1C1917] text-white'
                  : 'border border-stone-200 bg-white text-stone-700 hover:border-[#F5B800] hover:bg-[#FFF9E6]'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="inline-flex items-center gap-1 rounded-xl border border-stone-200 bg-white p-1">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'popular', label: 'Popular' },
                { id: 'new', label: 'New' },
                { id: 'discount', label: 'Deals' },
              ] as const
            ).map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setTagFilter(f.id)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition whitespace-nowrap ${
                  tagFilter === f.id
                    ? 'bg-[#F5B800] text-[#1C1917]'
                    : 'text-stone-600 hover:text-[#1C1917]'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-1.5">
            <SlidersHorizontal className="h-3.5 w-3.5 text-stone-500" />
            <label htmlFor="price-sort-select" className="sr-only">
              Sort by price
            </label>
            <select
              id="price-sort-select"
              value={priceSort}
              onChange={(e) => setPriceSort(e.target.value as 'default' | 'low_to_high' | 'high_to_low')}
              className="bg-transparent text-xs font-semibold text-stone-700 focus:outline-none"
            >
              <option value="default">Any Price (Default)</option>
              <option value="low_to_high">Low to High</option>
              <option value="high_to_low">High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Results count */}
      <div className="mt-5 flex items-center justify-between text-xs text-stone-500">
        <span className="tabular-nums">
          Showing {filteredProducts.length} of {products.length} menu items
        </span>
        {(selectedCategory !== 'All' || searchQuery || tagFilter !== 'all' || priceSort !== 'default') && (
          <button
            type="button"
            onClick={resetFilters}
            className="font-semibold text-[#B47B00] hover:underline"
          >
            Reset all filters
          </button>
        )}
      </div>

      {/* Product Grid (3-column on mobile & desktop) */}
      {catalogLoading ? (
        <div className="mt-4 grid grid-cols-3 gap-2 sm:mt-6 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3 lg:gap-6">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div key={n} className="h-52 animate-pulse rounded-xl bg-stone-200/70 sm:h-[380px] sm:rounded-2xl" />
          ))}
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="mt-8 rounded-3xl border border-stone-200 bg-white p-14 text-center">
          <h2 className="font-display text-xl font-bold text-[#1C1917]">No matching dishes found</h2>
          <p className="mt-2 text-sm text-stone-500">
            Try clearing your search or choosing another category.
          </p>
          <button
            type="button"
            onClick={resetFilters}
            className="mt-5 rounded-xl bg-[#F5B800] px-5 py-2.5 text-sm font-bold text-[#1C1917] hover:bg-[#E0A700]"
          >
            Show Full Menu
          </button>
        </div>
      ) : (
        <div className="mt-4 grid grid-cols-3 gap-2 sm:mt-6 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3 lg:gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} onInspect={setInspectProduct} />
          ))}
        </div>
      )}

      <ProductModal product={inspectProduct} onClose={() => setInspectProduct(null)} />
    </div>
  );
};
