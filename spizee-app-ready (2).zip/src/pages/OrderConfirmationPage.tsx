import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { OrderDetail, SiteSettings } from '../types';
import { ReceiptPaper } from '../components/ReceiptPaper';
import { copy } from '../i18n/en';
import { useApp } from '../context/AppContext';

export const OrderConfirmationPage: React.FC = () => {
  const { user } = useApp();
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<OrderDetail | null>(null);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    let active = true;
    apiFetch<{ order: OrderDetail; settings: SiteSettings }>(`/api/orders/${id}`)
      .then((data) => {
        if (!active) return;
        setOrder(data.order);
        setSettings(data.settings);
      })
      .catch((err: any) => {
        if (active) setError(err.message || 'Could not load order.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [id]);

  if (loading) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-14">
        <div className="h-96 animate-pulse rounded-3xl bg-stone-200/70" />
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <div className="glass-surface rounded-3xl p-10">
          <h1 className="font-display text-2xl font-bold text-[#1C1917]">Receipt Unavailable</h1>
          <p className="mt-2 text-sm text-stone-600">{error || 'Order could not be found.'}</p>
          <Link
            to="/"
            className="mt-6 inline-block rounded-xl bg-[#F5B800] px-6 py-2.5 text-sm font-bold text-[#1C1917]"
          >
            Back to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="no-print mb-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-700">
          <CheckCircle2 className="h-7 w-7" />
        </div>
        <h1 className="mt-4 font-display text-3xl font-extrabold text-[#1C1917]">
          Order #{order.orderNumber} Confirmed
        </h1>
        <p className="mt-1.5 text-sm text-stone-600">
          Current Status:{' '}
          <strong className="text-[#1C1917]">
            {copy.orderStatuses[order.status] || order.status}
          </strong>{' '}
          · Your official receipt is ready to print or download as PDF.
        </p>
      </div>

      <ReceiptPaper order={order} settings={settings} showActions />

      <div className="no-print mt-8 flex flex-wrap justify-center gap-3">
        {user ? (
          <Link
            to="/profile"
            className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-5 py-2.5 text-sm font-semibold text-[#1C1917] hover:bg-stone-50"
          >
            View Order History
          </Link>
        ) : (
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-5 py-2.5 text-sm font-semibold text-[#1C1917] hover:bg-stone-50"
          >
            Back to Home
          </Link>
        )}
        <Link
          to="/menu"
          className="inline-flex items-center gap-1.5 rounded-xl bg-[#FFF3C4] px-5 py-2.5 text-sm font-bold text-[#1C1917] hover:bg-[#F5B800]"
        >
          <ArrowLeft className="h-4 w-4" />
          Order More Food
        </Link>
      </div>
    </div>
  );
};
