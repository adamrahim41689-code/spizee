import React, { useCallback, useEffect, useState } from 'react';
import { Edit2, Plus, Search, Trash2, Upload, X } from 'lucide-react';
import { apiFetch, uploadImageFile } from '../../lib/api';
import type { Category, Product, ProductSize } from '../../types';
import { formatBdt } from '../../utils/orderMath';
import { useApp } from '../../context/AppContext';
import { FoodImage } from '../../components/FoodImage';

// ==================== ADMIN PRODUCTS ====================
interface DraftSize {
  id?: string;
  label: string;
  price: string;
  discountPrice: string;
  sortOrder: number;
}

export const AdminProductsPage: React.FC = () => {
  const { showToast, requestConfirm, refreshCatalog } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('all');

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [saving, setSaving] = useState(false);

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [basePrice, setBasePrice] = useState('');
  const [discountPrice, setDiscountPrice] = useState('');
  const [isAvailable, setIsAvailable] = useState(true);
  const [isFeatured, setIsFeatured] = useState(false);
  const [isPopular, setIsPopular] = useState(false);
  const [isNew, setIsNew] = useState(false);
  const [sizes, setSizes] = useState<DraftSize[]>([]);

  const loadData = useCallback(async () => {
    try {
      const data = await apiFetch<{ products: Product[]; categories: Category[] }>('/api/admin/catalog');
      setProducts(data.products);
      setCategories(data.categories);
    } catch (err: any) {
      showToast(err.message || 'Failed to load products', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const openCreate = () => {
    setEditing(null);
    setName('');
    setDescription('');
    setCategoryId(categories[0]?.id || '');
    setImageUrl('');
    setBasePrice('');
    setDiscountPrice('');
    setIsAvailable(true);
    setIsFeatured(false);
    setIsPopular(false);
    setIsNew(true);
    setSizes([{ label: 'Regular', price: '', discountPrice: '', sortOrder: 1 }]);
    setModalOpen(true);
  };

  const openEdit = (p: Product) => {
    setEditing(p);
    setName(p.name);
    setDescription(p.description || '');
    setCategoryId(p.categoryId || '');
    setImageUrl(p.imageUrl || '');
    setBasePrice(String(p.basePrice));
    setDiscountPrice(p.discountPrice !== null ? String(p.discountPrice) : '');
    setIsAvailable(p.isAvailable);
    setIsFeatured(p.isFeatured);
    setIsPopular(p.isPopular);
    setIsNew(p.isNew);
    setSizes(
      p.sizes.map((s) => ({
        id: s.id,
        label: s.label,
        price: String(s.price),
        discountPrice: s.discountPrice !== null ? String(s.discountPrice) : '',
        sortOrder: s.sortOrder,
      }))
    );
    setModalOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await uploadImageFile('product-images', file);
      setImageUrl(url);
      showToast('Product image uploaded', 'success');
    } catch (err: any) {
      showToast(err.message || 'Upload failed', 'error');
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !basePrice) {
      showToast('Name and base price are required', 'error');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: name.trim(),
        description: description.trim(),
        categoryId: categoryId || null,
        imageUrl: imageUrl.trim() || null,
        basePrice: Number(basePrice),
        discountPrice: discountPrice !== '' ? Number(discountPrice) : null,
        isAvailable,
        isFeatured,
        isPopular,
        isNew,
        sizes: sizes
          .filter((s) => s.label.trim() && s.price !== '')
          .map((s, idx) => ({
            id: s.id,
            label: s.label.trim(),
            price: Number(s.price),
            discountPrice: s.discountPrice !== '' ? Number(s.discountPrice) : null,
            sortOrder: idx + 1,
          })),
      };

      if (editing) {
        await apiFetch(`/api/admin/products/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
        showToast('Product updated', 'success');
      } else {
        await apiFetch('/api/admin/products', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
        showToast('Product created', 'success');
      }
      setModalOpen(false);
      await loadData();
      await refreshCatalog();
    } catch (err: any) {
      showToast(err.message || 'Could not save product', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (p: Product) => {
    const ok = await requestConfirm({
      title: `Delete "${p.name}"?`,
      message: 'This product and all its size variations will be removed from the menu.',
      confirmLabel: 'Delete Product',
      destructive: true,
    });
    if (!ok) return;
    try {
      await apiFetch(`/api/admin/products/${p.id}`, { method: 'DELETE' });
      showToast('Product deleted', 'info');
      await loadData();
      await refreshCatalog();
    } catch (err: any) {
      showToast(err.message || 'Delete failed', 'error');
    }
  };

  const catNameMap = new Map(categories.map((c) => [c.id, c.name]));
  const filtered = products.filter((p) => {
    if (catFilter !== 'all' && p.categoryId !== catFilter) return false;
    if (search.trim() && !p.name.toLowerCase().includes(search.trim().toLowerCase())) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#1C1917]">Products</h1>
          <p className="text-xs text-stone-500">
            Manage dishes, pricing, availability, and inline size variations. Changes publish live.
          </p>
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="inline-flex items-center gap-1.5 rounded-xl bg-[#F5B800] px-4 py-2.5 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700]"
        >
          <Plus className="h-4 w-4" />
          Add Product
        </button>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products…"
            className="w-full rounded-xl border border-stone-200 bg-white py-2 pl-9 pr-3 text-sm focus:border-[#F5B800] focus:outline-none"
          />
        </div>
        <select
          aria-label="Filter by category"
          value={catFilter}
          onChange={(e) => setCatFilter(e.target.value)}
          className="rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
        >
          <option value="all">All Categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      <div className="glass-surface overflow-x-auto rounded-2xl">
        {loading ? (
          <div className="p-8 text-center text-sm text-stone-500">Loading products…</div>
        ) : filtered.length === 0 ? (
          <div className="p-10 text-center text-sm text-stone-500">No products found.</div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-stone-200 text-xs text-stone-500">
                <th className="px-4 py-3 font-semibold">Product</th>
                <th className="px-4 py-3 font-semibold">Category</th>
                <th className="px-4 py-3 font-semibold">Price</th>
                <th className="px-4 py-3 font-semibold">Sizes</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 tabular-nums">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-[#FFFDF5]">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-[#FAF6EA]">
                        <FoodImage src={p.imageUrl} alt={p.name} className="h-full w-full object-cover" />
                      </div>
                      <div>
                        <p className="font-semibold text-[#1C1917]">{p.name}</p>
                        <p className="text-[11px] text-stone-500">
                          {[p.isFeatured && 'Featured', p.isPopular && 'Popular', p.isNew && 'New']
                            .filter(Boolean)
                            .join(' · ') || 'Standard'}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-stone-600">
                    {p.categoryId ? catNameMap.get(p.categoryId) || '—' : '—'}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs font-bold">
                    {p.discountPrice !== null ? (
                      <>
                        {formatBdt(p.discountPrice)}{' '}
                        <span className="font-normal text-stone-400 line-through">
                          {formatBdt(p.basePrice)}
                        </span>
                      </>
                    ) : (
                      formatBdt(p.basePrice)
                    )}
                  </td>
                  <td className="px-4 py-3 text-xs text-stone-600">
                    {p.sizes.length > 0 ? p.sizes.map((s) => s.label).join(', ') : 'Base only'}
                  </td>
                  <td className="px-4 py-3 text-xs font-semibold">
                    <span className={p.isAvailable ? 'text-emerald-700' : 'text-red-700'}>
                      {p.isAvailable ? 'Available' : 'Sold Out'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        aria-label={`Edit ${p.name}`}
                        onClick={() => openEdit(p)}
                        className="rounded-lg border border-stone-200 bg-white p-1.5 text-stone-700 hover:border-[#F5B800]"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete ${p.name}`}
                        onClick={() => handleDelete(p)}
                        className="rounded-lg border border-stone-200 bg-white p-1.5 text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Add / Edit Product Modal */}
      {modalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-stone-900/45 p-4 backdrop-blur-xs"
          onClick={() => setModalOpen(false)}
        >
          <form
            onSubmit={handleSave}
            onClick={(e) => e.stopPropagation()}
            className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-stone-200 pb-4">
              <h2 className="font-display text-xl font-bold text-[#1C1917]">
                {editing ? 'Edit Product' : 'Add New Product'}
              </h2>
              <button
                type="button"
                aria-label="Close modal"
                onClick={() => setModalOpen(false)}
                className="rounded-lg p-1.5 text-stone-500 hover:bg-stone-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-stone-700">Product Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-stone-200 px-3.5 py-2 text-sm focus:border-[#F5B800] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700">Category</label>
                <select
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-stone-200 px-3.5 py-2 text-sm"
                >
                  <option value="">Uncategorized</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700">Image Upload / URL</label>
                <div className="mt-1 flex gap-2">
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="/uploads/... or URL"
                    className="min-w-0 flex-1 rounded-xl border border-stone-200 px-3 py-2 text-xs"
                  />
                  <label className="inline-flex cursor-pointer items-center gap-1 rounded-xl bg-stone-100 px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-[#FFF3C4]">
                    <Upload className="h-3.5 w-3.5" />
                    Upload
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      onChange={handleImageUpload}
                      className="sr-only"
                    />
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700">Base Price (৳) *</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={basePrice}
                  onChange={(e) => setBasePrice(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-stone-200 px-3.5 py-2 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700">
                  Discount Price (৳, optional)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={discountPrice}
                  onChange={(e) => setDiscountPrice(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-stone-200 px-3.5 py-2 text-sm"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-stone-700">Description</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-stone-200 px-3.5 py-2 text-sm"
                />
              </div>

              <div className="flex flex-wrap gap-4 sm:col-span-2">
                {[
                  { label: 'Available', val: isAvailable, set: setIsAvailable },
                  { label: 'Featured', val: isFeatured, set: setIsFeatured },
                  { label: 'Popular', val: isPopular, set: setIsPopular },
                  { label: 'New', val: isNew, set: setIsNew },
                ].map((flag) => (
                  <label key={flag.label} className="inline-flex items-center gap-2 text-xs font-semibold">
                    <input
                      type="checkbox"
                      checked={flag.val}
                      onChange={(e) => flag.set(e.target.checked)}
                      className="h-4 w-4 accent-[#F5B800]"
                    />
                    {flag.label}
                  </label>
                ))}
              </div>
            </div>

            {/* Inline Sizes Editor */}
            <div className="mt-6 border-t border-stone-200 pt-4">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-bold text-[#1C1917]">
                  Product Sizes &amp; Variations
                </h3>
                <button
                  type="button"
                  onClick={() =>
                    setSizes((prev) => [
                      ...prev,
                      { label: '', price: '', discountPrice: '', sortOrder: prev.length + 1 },
                    ])
                  }
                  className="inline-flex items-center gap-1 rounded-lg bg-[#FFF3C4] px-3 py-1.5 text-xs font-bold text-[#1C1917]"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Add Size
                </button>
              </div>
              <div className="mt-3 space-y-2.5">
                {sizes.map((s, idx) => (
                  <div key={idx} className="grid grid-cols-12 gap-2">
                    <input
                      type="text"
                      placeholder="Size label (e.g. Regular, 4 Pieces)"
                      value={s.label}
                      onChange={(e) =>
                        setSizes((prev) =>
                          prev.map((x, i) => (i === idx ? { ...x, label: e.target.value } : x))
                        )
                      }
                      className="col-span-5 rounded-lg border border-stone-200 px-2.5 py-1.5 text-xs"
                    />
                    <input
                      type="number"
                      placeholder="Price ৳"
                      value={s.price}
                      onChange={(e) =>
                        setSizes((prev) =>
                          prev.map((x, i) => (i === idx ? { ...x, price: e.target.value } : x))
                        )
                      }
                      className="col-span-3 rounded-lg border border-stone-200 px-2.5 py-1.5 text-xs"
                    />
                    <input
                      type="number"
                      placeholder="Disc. ৳"
                      value={s.discountPrice}
                      onChange={(e) =>
                        setSizes((prev) =>
                          prev.map((x, i) =>
                            i === idx ? { ...x, discountPrice: e.target.value } : x
                          )
                        )
                      }
                      className="col-span-3 rounded-lg border border-stone-200 px-2.5 py-1.5 text-xs"
                    />
                    <button
                      type="button"
                      aria-label="Remove size"
                      onClick={() => setSizes((prev) => prev.filter((_, i) => i !== idx))}
                      className="col-span-1 inline-flex items-center justify-center rounded-lg text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2.5 border-t border-stone-200 pt-4">
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="rounded-xl border border-stone-300 px-4 py-2 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="rounded-xl bg-[#F5B800] px-5 py-2 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700]"
              >
                {saving ? 'Saving…' : editing ? 'Update Product' : 'Create Product'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

// ==================== ADMIN CATEGORIES ====================
export const AdminCategoriesPage: React.FC = () => {
  const { showToast, requestConfirm, refreshCatalog } = useApp();
  const [categories, setCategories] = useState<Category[]>([]);
  const [editing, setEditing] = useState<Category | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [sortOrder, setSortOrder] = useState('0');
  const [isActive, setIsActive] = useState(true);

  const load = useCallback(async () => {
    const data = await apiFetch<{ categories: Category[] }>('/api/admin/catalog');
    setCategories(data.categories);
  }, []);

  useEffect(() => {
    load().catch(() => {});
  }, [load]);

  const resetForm = () => {
    setEditing(null);
    setName('');
    setDescription('');
    setImageUrl('');
    setSortOrder('0');
    setIsActive(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    try {
      const payload = {
        name: name.trim(),
        description: description.trim(),
        imageUrl: imageUrl.trim() || null,
        sortOrder: Number(sortOrder) || 0,
        isActive,
      };
      if (editing) {
        await apiFetch(`/api/admin/categories/${editing.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
        showToast('Category updated', 'success');
      } else {
        await apiFetch('/api/admin/categories', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
        showToast('Category created', 'success');
      }
      resetForm();
      await load();
      await refreshCatalog();
    } catch (err: any) {
      showToast(err.message || 'Save failed', 'error');
    }
  };

  const handleDelete = async (c: Category) => {
    const ok = await requestConfirm({
      title: `Delete category "${c.name}"?`,
      message: 'Products in this category will become uncategorized.',
      confirmLabel: 'Delete',
      destructive: true,
    });
    if (!ok) return;
    await apiFetch(`/api/admin/categories/${c.id}`, { method: 'DELETE' });
    showToast('Category deleted', 'info');
    await load();
    await refreshCatalog();
  };

  return (
    <div className="grid gap-6 lg:grid-cols-12">
      <form onSubmit={handleSave} className="glass-surface h-fit rounded-2xl p-6 lg:col-span-4">
        <h1 className="font-display text-lg font-bold text-[#1C1917]">
          {editing ? 'Edit Category' : 'Add Category'}
        </h1>
        <div className="mt-4 space-y-3.5">
          <div>
            <label className="block text-xs font-semibold text-stone-700">Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Burgers, Combos"
              className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">Category Image</label>
            <div className="mt-1 flex gap-2">
              <input
                type="text"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="Image URL"
                className="min-w-0 flex-1 rounded-xl border border-stone-200 px-3 py-2 text-xs"
              />
              <label className="inline-flex cursor-pointer items-center rounded-xl bg-stone-100 px-3 py-2 text-xs font-semibold hover:bg-[#FFF3C4]">
                Upload
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    try {
                      setImageUrl(await uploadImageFile('product-images', f));
                      showToast('Category image uploaded', 'success');
                    } catch (err: any) {
                      showToast(err.message, 'error');
                    }
                  }}
                  className="sr-only"
                />
              </label>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-stone-700">Sort Order</label>
              <input
                type="number"
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value)}
                className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
              />
            </div>
            <label className="mt-6 inline-flex items-center gap-2 text-xs font-semibold">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="h-4 w-4 accent-[#F5B800]"
              />
              Active
            </label>
          </div>
          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              className="flex-1 rounded-xl bg-[#F5B800] py-2.5 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700]"
            >
              {editing ? 'Update Category' : 'Add Category'}
            </button>
            {editing && (
              <button
                type="button"
                onClick={resetForm}
                className="rounded-xl border border-stone-300 px-4 py-2 text-xs font-semibold"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </form>

      <div className="glass-surface overflow-x-auto rounded-2xl p-5 lg:col-span-8">
        <h2 className="font-display text-lg font-bold text-[#1C1917]">All Categories ({categories.length})</h2>
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-stone-200 text-xs text-stone-500">
              <th className="pb-2.5 font-semibold">Category</th>
              <th className="pb-2.5 font-semibold">Order</th>
              <th className="pb-2.5 font-semibold">Status</th>
              <th className="pb-2.5 text-right font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {categories.map((c) => (
              <tr key={c.id}>
                <td className="py-3">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 overflow-hidden rounded-lg bg-[#FAF6EA]">
                      <FoodImage src={c.imageUrl} alt={c.name} className="h-full w-full object-cover" />
                    </div>
                    <div>
                      <p className="font-semibold">{c.name}</p>
                      <p className="line-clamp-1 text-xs text-stone-500">{c.description}</p>
                    </div>
                  </div>
                </td>
                <td className="py-3 font-mono text-xs">{c.sortOrder}</td>
                <td className="py-3 text-xs font-semibold">
                  <span className={c.isActive ? 'text-emerald-700' : 'text-stone-400'}>
                    {c.isActive ? 'Active' : 'Hidden'}
                  </span>
                </td>
                <td className="py-3 text-right">
                  <div className="inline-flex gap-1.5">
                    <button
                      type="button"
                      aria-label={`Edit ${c.name}`}
                      onClick={() => {
                        setEditing(c);
                        setName(c.name);
                        setDescription(c.description || '');
                        setImageUrl(c.imageUrl || '');
                        setSortOrder(String(c.sortOrder));
                        setIsActive(c.isActive);
                      }}
                      className="rounded-lg border border-stone-200 p-1.5 hover:border-[#F5B800]"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </button>
                    <button
                      type="button"
                      aria-label={`Delete ${c.name}`}
                      onClick={() => handleDelete(c)}
                      className="rounded-lg border border-stone-200 p-1.5 text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ==================== ADMIN PRODUCT SIZES ====================
export const AdminSizesPage: React.FC = () => {
  const { showToast, requestConfirm, refreshCatalog } = useApp();
  const [products, setProducts] = useState<Product[]>([]);
  const [sizes, setSizes] = useState<ProductSize[]>([]);
  const [productId, setProductId] = useState('');
  const [label, setLabel] = useState('');
  const [price, setPrice] = useState('');
  const [discountPrice, setDiscountPrice] = useState('');

  const load = useCallback(async () => {
    const data = await apiFetch<{ products: Product[]; sizes: ProductSize[] }>('/api/admin/catalog');
    setProducts(data.products);
    setSizes(data.sizes);
    if (!productId && data.products[0]) setProductId(data.products[0].id);
  }, [productId]);

  useEffect(() => {
    load().catch(() => {});
  }, [load]);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productId || !label.trim() || !price) return;
    try {
      await apiFetch('/api/admin/sizes', {
        method: 'POST',
        body: JSON.stringify({
          productId,
          label: label.trim(),
          price: Number(price),
          discountPrice: discountPrice !== '' ? Number(discountPrice) : null,
        }),
      });
      setLabel('');
      setPrice('');
      setDiscountPrice('');
      showToast('Size added', 'success');
      await load();
      await refreshCatalog();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDelete = async (s: ProductSize) => {
    const ok = await requestConfirm({
      title: `Delete size "${s.label}"?`,
      message: 'Customers will no longer see this size option.',
      confirmLabel: 'Delete',
      destructive: true,
    });
    if (!ok) return;
    await apiFetch(`/api/admin/sizes/${s.id}`, { method: 'DELETE' });
    showToast('Size removed', 'info');
    await load();
    await refreshCatalog();
  };

  const prodMap = new Map(products.map((p) => [p.id, p.name]));

  return (
    <div className="space-y-6">
      <h1 className="font-display text-2xl font-extrabold text-[#1C1917]">Product Sizes</h1>

      <form onSubmit={handleAdd} className="glass-surface grid gap-3 rounded-2xl p-5 sm:grid-cols-5">
        <select
          aria-label="Product"
          value={productId}
          onChange={(e) => setProductId(e.target.value)}
          className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs sm:col-span-2"
        >
          {products.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
        <input
          type="text"
          required
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="Size (e.g. Large, 6 Pcs)"
          className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs"
        />
        <input
          type="number"
          required
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          placeholder="Price ৳"
          className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs"
        />
        <div className="flex gap-2">
          <input
            type="number"
            value={discountPrice}
            onChange={(e) => setDiscountPrice(e.target.value)}
            placeholder="Disc ৳"
            className="w-20 rounded-xl border border-stone-200 bg-white px-2.5 py-2 text-xs"
          />
          <button
            type="submit"
            className="flex-1 rounded-xl bg-[#F5B800] px-3 py-2 text-xs font-bold text-[#1C1917]"
          >
            Add
          </button>
        </div>
      </form>

      <div className="glass-surface overflow-x-auto rounded-2xl p-5">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-stone-200 text-xs text-stone-500">
              <th className="pb-2.5 font-semibold">Product</th>
              <th className="pb-2.5 font-semibold">Size Label</th>
              <th className="pb-2.5 font-semibold">Price</th>
              <th className="pb-2.5 font-semibold">Discount Price</th>
              <th className="pb-2.5 text-right font-semibold">Remove</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100 tabular-nums">
            {sizes.map((s) => (
              <tr key={s.id}>
                <td className="py-2.5 font-semibold">{prodMap.get(s.productId) || '—'}</td>
                <td className="py-2.5">{s.label}</td>
                <td className="py-2.5 font-mono">{formatBdt(s.price)}</td>
                <td className="py-2.5 font-mono text-stone-500">
                  {s.discountPrice !== null ? formatBdt(s.discountPrice) : '—'}
                </td>
                <td className="py-2.5 text-right">
                  <button
                    type="button"
                    aria-label={`Delete ${s.label}`}
                    onClick={() => handleDelete(s)}
                    className="rounded-lg p-1.5 text-red-600 hover:bg-red-50"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
