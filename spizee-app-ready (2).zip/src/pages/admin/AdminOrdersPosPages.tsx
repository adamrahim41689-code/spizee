import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Download,
  Minus,
  Plus,
  Printer,
  Receipt,
  RefreshCw,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { apiFetch } from '../../lib/api';
import type { Category, Offer, OrderDetail, Product } from '../../types';
import {
  calculateOrderTotals,
  computeEffectivePrice,
  formatBdt,
  formatDhakaDateTime,
} from '../../utils/orderMath';
import { downloadReceiptPdf, printReceiptHtml } from '../../utils/receiptPdf';
import { copy } from '../../i18n/en';
import { useApp } from '../../context/AppContext';
import { ReceiptPaper } from '../../components/ReceiptPaper';
import { FoodImage } from '../../components/FoodImage';

// ==================== ADMIN ORDERS ====================
export const AdminOrdersPage: React.FC = () => {
  const { settings, showToast } = useApp();
  const [orders, setOrders] = useState<OrderDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [sourceFilter, setSourceFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<OrderDetail | null>(null);
  const lastCountRef = useRef<number | null>(null);

  const loadOrders = useCallback(
    async (silent = false) => {
      try {
        const params = new URLSearchParams();
        if (statusFilter !== 'all') params.set('status', statusFilter);
        if (typeFilter !== 'all') params.set('orderType', typeFilter);
        if (sourceFilter !== 'all') params.set('source', sourceFilter);
        if (search.trim()) params.set('search', search.trim());
        if (dateFrom) params.set('dateFrom', dateFrom);
        if (dateTo) params.set('dateTo', dateTo);

        const data = await apiFetch<{ orders: OrderDetail[] }>(
          `/api/admin/orders?${params.toString()}`
        );
        if (
          silent &&
          lastCountRef.current !== null &&
          data.orders.length > lastCountRef.current
        ) {
          showToast('New order received!', 'info');
        }
        lastCountRef.current = data.orders.length;
        setOrders(data.orders);
      } catch (err: any) {
        if (!silent) showToast(err.message || 'Failed to load orders', 'error');
      } finally {
        setLoading(false);
      }
    },
    [statusFilter, typeFilter, sourceFilter, search, dateFrom, dateTo, showToast]
  );

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  // Live polling every 15 seconds for incoming orders
  useEffect(() => {
    const timer = setInterval(() => loadOrders(true), 15000);
    return () => clearInterval(timer);
  }, [loadOrders]);

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      await apiFetch(`/api/admin/orders/${orderId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status: newStatus }),
      });
      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, status: newStatus as any } : o))
      );
      if (selectedOrder?.id === orderId) {
        setSelectedOrder((prev) => (prev ? { ...prev, status: newStatus as any } : null));
      }
      showToast(`Order status updated to ${copy.orderStatuses[newStatus]}`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Could not update status', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#1C1917]">Orders Management</h1>
          <p className="text-xs text-stone-500">
            Track online &amp; POS orders, update preparation status, and print thermal receipts.
          </p>
        </div>
        <button
          type="button"
          onClick={() => loadOrders(false)}
          className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-4 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh Now
        </button>
      </div>

      {/* Filters */}
      <div className="no-print glass-surface grid gap-3 rounded-2xl p-4 sm:grid-cols-2 lg:grid-cols-6">
        <div className="relative lg:col-span-2">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Order #, receipt #, name, phone…"
            className="w-full rounded-xl border border-stone-200 bg-white py-2 pl-9 pr-3 text-xs"
          />
        </div>
        <select
          aria-label="Filter by status"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs"
        >
          <option value="all">All Statuses</option>
          {Object.entries(copy.orderStatuses).map(([k, v]) => (
            <option key={k} value={k}>
              {v}
            </option>
          ))}
        </select>
        <select
          aria-label="Filter by order type"
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs"
        >
          <option value="all">All Order Types</option>
          <option value="home_delivery">Home Delivery</option>
          <option value="pickup">Pickup</option>
          <option value="dine_in">Dine-In</option>
        </select>
        <select
          aria-label="Filter by source"
          value={sourceFilter}
          onChange={(e) => setSourceFilter(e.target.value)}
          className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs"
        >
          <option value="all">Online &amp; POS</option>
          <option value="online">Online Only</option>
          <option value="pos">POS Only</option>
        </select>
        <div className="flex gap-1.5">
          <input
            type="date"
            aria-label="From date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="w-1/2 rounded-xl border border-stone-200 bg-white px-2 py-2 text-[11px]"
          />
          <input
            type="date"
            aria-label="To date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="w-1/2 rounded-xl border border-stone-200 bg-white px-2 py-2 text-[11px]"
          />
        </div>
      </div>

      {/* Orders Table */}
      <div className="no-print glass-surface overflow-x-auto rounded-2xl">
        {loading ? (
          <div className="p-8 text-center text-sm text-stone-500">Loading orders…</div>
        ) : orders.length === 0 ? (
          <div className="p-10 text-center text-sm text-stone-500">
            No orders match your current filters.
          </div>
        ) : (
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-stone-200 text-stone-500">
                <th className="px-4 py-3 font-semibold">Order</th>
                <th className="px-4 py-3 font-semibold">Customer</th>
                <th className="px-4 py-3 font-semibold">Items</th>
                <th className="px-4 py-3 font-semibold">Type &amp; Address</th>
                <th className="px-4 py-3 text-right font-semibold">Total</th>
                <th className="px-4 py-3 font-semibold">Status</th>
                <th className="px-4 py-3 text-right font-semibold">Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 tabular-nums">
              {orders.map((o) => {
                const dt = formatDhakaDateTime(o.createdAt);
                return (
                  <tr key={o.id} className="hover:bg-[#FFFDF5]">
                    <td className="px-4 py-3 align-top">
                      <p className="font-mono font-bold text-[#1C1917]">#{o.orderNumber}</p>
                      <p className="text-[11px] text-stone-500">
                        {o.source.toUpperCase()} · {dt.dateStr} {dt.timeStr}
                      </p>
                    </td>
                    <td className="px-4 py-3 align-top">
                      <p className="font-semibold text-[#1C1917]">{o.customerName || 'Walk-in'}</p>
                      <p className="font-mono text-[11px] text-stone-500">{o.customerPhone || '—'}</p>
                    </td>
                    <td className="px-4 py-3 align-top">
                      {o.items.map((it) => (
                        <div key={it.id}>
                          {it.quantity}× {it.productName}
                          {it.sizeLabel ? ` (${it.sizeLabel})` : ''}
                        </div>
                      ))}
                    </td>
                    <td className="px-4 py-3 align-top">
                      <p className="font-semibold">{copy.orderTypes[o.orderType]}</p>
                      {o.orderType === 'home_delivery' && o.deliveryAddress && (
                        <p className="mt-0.5 max-w-[200px] text-[11px] text-stone-500">
                          {o.deliveryAddress}
                        </p>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right align-top font-mono font-bold text-[#1C1917]">
                      {formatBdt(o.totalAmount)}
                    </td>
                    <td className="px-4 py-3 align-top">
                      <select
                        aria-label={`Status for order ${o.orderNumber}`}
                        value={o.status}
                        onChange={(e) => handleStatusChange(o.id, e.target.value)}
                        className="rounded-lg border border-stone-200 bg-white px-2 py-1 text-xs font-semibold"
                      >
                        {Object.entries(copy.orderStatuses).map(([k, v]) => (
                          <option key={k} value={k}>
                            {v}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="px-4 py-3 text-right align-top">
                      <div className="inline-flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => setSelectedOrder(o)}
                          className="inline-flex items-center gap-1 rounded-lg bg-[#FFF3C4] px-2.5 py-1.5 text-xs font-bold text-[#1C1917] hover:bg-[#F5B800]"
                        >
                          <Receipt className="h-3.5 w-3.5" />
                          View
                        </button>
                        <button
                          type="button"
                          title="Download Receipt PDF"
                          aria-label={`Download PDF receipt for order ${o.orderNumber}`}
                          onClick={() => downloadReceiptPdf(o, settings)}
                          className="inline-flex items-center gap-1 rounded-lg bg-[#1C1917] px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-stone-800"
                        >
                          <Download className="h-3.5 w-3.5" />
                          PDF
                        </button>
                        <button
                          type="button"
                          title="Print Receipt (Customer + Kitchen Copy)"
                          aria-label={`Print receipt for order ${o.orderNumber}`}
                          onClick={() => {
                            void printReceiptHtml(o, settings);
                          }}
                          className="inline-flex cursor-pointer items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700"
                        >
                          <Printer className="h-3.5 w-3.5" />
                          Print
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {selectedOrder && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-stone-900/45 p-4 backdrop-blur-xs"
          onClick={() => setSelectedOrder(null)}
        >
          <div
            className="relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-3xl bg-[#FFFDF7] p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setSelectedOrder(null)}
              aria-label="Close receipt modal"
              className="no-print absolute right-4 top-4 rounded-full bg-white p-1.5 text-stone-700 shadow"
            >
              <X className="h-4 w-4" />
            </button>
            <ReceiptPaper order={selectedOrder} settings={settings} showActions />
          </div>
        </div>
      )}
    </div>
  );
};

// ==================== ADMIN POS / QUICK ORDER ====================
interface PosLine {
  productId: string;
  productName: string;
  sizeId: string | null;
  sizeLabel: string | null;
  unitPrice: number;
  quantity: number;
}

export const AdminPosPage: React.FC = () => {
  const { settings, showToast } = useApp();
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [selectedCat, setSelectedCat] = useState('all');
  const [search, setSearch] = useState('');
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({});

  const [lines, setLines] = useState<PosLine[]>([]);
  const [orderType, setOrderType] = useState<'pickup' | 'dine_in'>('pickup');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [extraDiscount, setExtraDiscount] = useState('0');
  const [submitting, setSubmitting] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<OrderDetail | null>(null);

  useEffect(() => {
    apiFetch<{ categories: Category[]; products: Product[]; offers: Offer[] }>('/api/admin/catalog')
      .then((d) => {
        setCategories(d.categories.filter((c) => c.isActive));
        setProducts(d.products.filter((p) => p.isAvailable));
        setOffers(d.offers.filter((o) => o.isActive));
      })
      .catch(() => {});
  }, []);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      if (selectedCat !== 'all' && p.categoryId !== selectedCat) return false;
      if (q && !p.name.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [products, selectedCat, search]);

  const addProductToPos = (prod: Product) => {
    const sizeId =
      prod.sizes.length > 0 ? selectedSizes[prod.id] || prod.sizes[0].id : null;
    const sizeObj = sizeId ? prod.sizes.find((s) => s.id === sizeId) : undefined;
    const priced = computeEffectivePrice(
      {
        productId: prod.id,
        basePrice: prod.basePrice,
        discountPrice: prod.discountPrice,
        sizePrice: sizeObj ? sizeObj.price : null,
        sizeDiscountPrice: sizeObj ? sizeObj.discountPrice : null,
        quantity: 1,
      },
      offers
    );

    setLines((prev) => {
      const idx = prev.findIndex((l) => l.productId === prod.id && l.sizeId === sizeId);
      if (idx >= 0) {
        return prev.map((l, i) =>
          i === idx ? { ...l, quantity: Math.min(50, l.quantity + 1) } : l
        );
      }
      return [
        ...prev,
        {
          productId: prod.id,
          productName: prod.name,
          sizeId,
          sizeLabel: sizeObj?.label || null,
          unitPrice: priced.effectiveUnitPrice,
          quantity: 1,
        },
      ];
    });
  };

  const totals = useMemo(
    () =>
      calculateOrderTotals({
        lines: lines.map((l) => ({ effectiveUnitPrice: l.unitPrice, quantity: l.quantity })),
        orderType,
        source: 'pos',
        siteDeliveryCharge: 0,
        extraDiscount: Number(extraDiscount) || 0,
      }),
    [lines, orderType, extraDiscount]
  );

  const handleConfirmPos = async () => {
    if (lines.length === 0 || submitting) return;
    setSubmitting(true);
    try {
      const data = await apiFetch<{ order: OrderDetail }>('/api/admin/pos/orders', {
        method: 'POST',
        body: JSON.stringify({
          items: lines.map((l) => ({
            productId: l.productId,
            sizeId: l.sizeId,
            quantity: l.quantity,
          })),
          orderType,
          customerName: customerName.trim() || null,
          customerPhone: customerPhone.trim() || null,
          paymentMethod,
          extraDiscount: Number(extraDiscount) || 0,
        }),
      });
      setCompletedOrder(data.order);
      setLines([]);
      setCustomerName('');
      setCustomerPhone('');
      setExtraDiscount('0');
      showToast(`POS Order #${data.order.orderNumber} completed!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'POS order failed', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="no-print">
        <h1 className="font-display text-2xl font-extrabold text-[#1C1917]">POS / Quick Order</h1>
        <p className="text-xs text-stone-500">
          Fast in-store counter ordering (Pickup &amp; Dine-In only — no delivery address needed).
        </p>
      </div>

      <div className="no-print grid gap-6 lg:grid-cols-12">
        {/* Left: Product Picker */}
        <div className="space-y-4 lg:col-span-7 xl:col-span-8">
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
              <input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search menu item…"
                className="w-full rounded-xl border border-stone-200 bg-white py-2 pl-9 pr-3 text-sm"
              />
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => setSelectedCat('all')}
                className={`rounded-xl px-3 py-2 text-xs font-bold ${
                  selectedCat === 'all' ? 'bg-[#1C1917] text-white' : 'bg-white text-stone-700 border border-stone-200'
                }`}
              >
                All
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedCat(c.id)}
                  className={`rounded-xl px-3 py-2 text-xs font-bold ${
                    selectedCat === c.id ? 'bg-[#1C1917] text-white' : 'bg-white text-stone-700 border border-stone-200'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {filteredProducts.map((prod) => {
              const chosenSizeId =
                prod.sizes.length > 0 ? selectedSizes[prod.id] || prod.sizes[0].id : null;
              const sizeObj = chosenSizeId
                ? prod.sizes.find((s) => s.id === chosenSizeId)
                : undefined;
              const priced = computeEffectivePrice(
                {
                  productId: prod.id,
                  basePrice: prod.basePrice,
                  discountPrice: prod.discountPrice,
                  sizePrice: sizeObj ? sizeObj.price : null,
                  sizeDiscountPrice: sizeObj ? sizeObj.discountPrice : null,
                  quantity: 1,
                },
                offers
              );

              return (
                <div key={prod.id} className="glass-surface flex flex-col rounded-2xl p-3.5">
                  <div className="flex items-center gap-3">
                    <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-[#FAF6EA]">
                      <FoodImage
                        src={prod.imageUrl}
                        alt={prod.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-display text-sm font-bold text-[#1C1917]">
                        {prod.name}
                      </p>
                      <p className="font-mono text-sm font-bold text-[#B47B00] tabular-nums">
                        {formatBdt(priced.effectiveUnitPrice)}
                      </p>
                    </div>
                  </div>

                  {prod.sizes.length > 0 && (
                    <div className="mt-2.5 flex flex-wrap gap-1">
                      {prod.sizes.map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() =>
                            setSelectedSizes((prev) => ({ ...prev, [prod.id]: s.id }))
                          }
                          className={`rounded-md px-2 py-1 text-[11px] font-semibold ${
                            chosenSizeId === s.id
                              ? 'bg-[#1C1917] text-white'
                              : 'bg-stone-100 text-stone-700'
                          }`}
                        >
                          {s.label}
                        </button>
                      ))}
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => addProductToPos(prod)}
                    className="mt-3 w-full rounded-xl bg-[#F5B800] py-2 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700]"
                  >
                    + Add to Ticket
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: POS Ticket */}
        <div className="glass-surface flex h-fit flex-col rounded-3xl p-5 lg:col-span-5 xl:col-span-4">
          <div className="flex items-center justify-between border-b border-stone-200 pb-3">
            <h2 className="font-display text-base font-bold text-[#1C1917]">Current Ticket</h2>
            {lines.length > 0 && (
              <button
                type="button"
                onClick={() => setLines([])}
                className="text-xs font-semibold text-red-600 hover:underline"
              >
                Clear
              </button>
            )}
          </div>

          {/* Pickup / Dine-In ONLY (No Home Delivery in POS) */}
          <div className="mt-3 grid grid-cols-2 gap-1.5 rounded-xl bg-stone-100 p-1">
            <button
              type="button"
              onClick={() => setOrderType('pickup')}
              className={`rounded-lg py-2 text-xs font-bold ${
                orderType === 'pickup' ? 'bg-white text-[#1C1917] shadow-xs' : 'text-stone-600'
              }`}
            >
              Counter Pickup
            </button>
            <button
              type="button"
              onClick={() => setOrderType('dine_in')}
              className={`rounded-lg py-2 text-xs font-bold ${
                orderType === 'dine_in' ? 'bg-white text-[#1C1917] shadow-xs' : 'text-stone-600'
              }`}
            >
              Dine-In
            </button>
          </div>

          <div className="mt-3 grid grid-cols-2 gap-2">
            <input
              type="text"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              placeholder="Customer name (opt.)"
              className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs"
            />
            <input
              type="tel"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
              placeholder="Phone (opt.)"
              className="rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs"
            />
          </div>

          <div className="mt-4 max-h-64 overflow-y-auto divide-y divide-stone-100">
            {lines.length === 0 ? (
              <p className="py-10 text-center text-xs text-stone-400">
                Tap items on the left to add them to this POS ticket.
              </p>
            ) : (
              lines.map((line) => (
                <div
                  key={`${line.productId}-${line.sizeId ?? 'base'}`}
                  className="flex items-center justify-between gap-2 py-2.5 text-xs"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-[#1C1917]">{line.productName}</p>
                    <p className="font-mono text-[11px] text-stone-500 tabular-nums">
                      {line.sizeLabel ? `${line.sizeLabel} · ` : ''}
                      {formatBdt(line.unitPrice)}
                    </p>
                  </div>
                  <div className="inline-flex items-center rounded-lg border border-stone-200 bg-white">
                    <button
                      type="button"
                      aria-label="Decrease POS item quantity"
                      onClick={() =>
                        setLines((prev) =>
                          prev
                            .map((x) =>
                              x.productId === line.productId && x.sizeId === line.sizeId
                                ? { ...x, quantity: x.quantity - 1 }
                                : x
                            )
                            .filter((x) => x.quantity > 0)
                        )
                      }
                      className="p-1.5 hover:bg-stone-100"
                    >
                      <Minus className="h-3 w-3" />
                    </button>
                    <span className="w-6 text-center font-mono font-bold tabular-nums">
                      {line.quantity}
                    </span>
                    <button
                      type="button"
                      aria-label="Increase POS item quantity"
                      onClick={() =>
                        setLines((prev) =>
                          prev.map((x) =>
                            x.productId === line.productId && x.sizeId === line.sizeId
                              ? { ...x, quantity: Math.min(50, x.quantity + 1) }
                              : x
                          )
                        )
                      }
                      className="p-1.5 hover:bg-stone-100"
                    >
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                  <button
                    type="button"
                    aria-label="Remove POS line"
                    onClick={() =>
                      setLines((prev) =>
                        prev.filter(
                          (x) => !(x.productId === line.productId && x.sizeId === line.sizeId)
                        )
                      )
                    }
                    className="p-1 text-stone-400 hover:text-red-600"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2 border-t border-stone-200 pt-3">
            <div>
              <label className="block text-[11px] font-semibold text-stone-500">Payment</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="mt-1 w-full rounded-lg border border-stone-200 bg-white px-2.5 py-1.5 text-xs"
              >
                <option value="cash">Cash</option>
                <option value="bkash">bKash</option>
                <option value="nagad">Nagad</option>
                <option value="card">Card</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-stone-500">
                Counter Discount (৳)
              </label>
              <input
                type="number"
                min="0"
                value={extraDiscount}
                onChange={(e) => setExtraDiscount(e.target.value)}
                className="mt-1 w-full rounded-lg border border-stone-200 bg-white px-2.5 py-1.5 text-xs"
              />
            </div>
          </div>

          <div className="mt-4 space-y-1 border-t border-stone-200 pt-3 text-sm tabular-nums">
            <div className="flex justify-between text-xs text-stone-600">
              <span>Subtotal</span>
              <span className="font-mono">{formatBdt(totals.subtotal)}</span>
            </div>
            {totals.discount > 0 && (
              <div className="flex justify-between text-xs text-emerald-700">
                <span>Discount</span>
                <span className="font-mono">-{formatBdt(totals.discount)}</span>
              </div>
            )}
            <div className="flex justify-between pt-1 text-base font-bold">
              <span>Total</span>
              <span className="font-mono">{formatBdt(totals.totalAmount)}</span>
            </div>
          </div>

          <button
            type="button"
            disabled={lines.length === 0 || submitting}
            onClick={handleConfirmPos}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-[#F5B800] py-3 text-sm font-bold text-[#1C1917] transition hover:bg-[#E0A700] disabled:opacity-50"
          >
            <CheckCircle2 className="h-4 w-4" />
            {submitting ? 'Processing…' : 'Confirm POS Order & Receipt'}
          </button>
        </div>
      </div>

      {/* Immediate POS Receipt Modal */}
      {completedOrder && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-stone-900/45 p-4 backdrop-blur-xs"
          onClick={() => setCompletedOrder(null)}
        >
          <div
            className="relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-3xl bg-[#FFFDF7] p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setCompletedOrder(null)}
              aria-label="Close POS receipt"
              className="no-print absolute right-4 top-4 rounded-full bg-white p-1.5 text-stone-700 shadow"
            >
              <X className="h-4 w-4" />
            </button>
            <ReceiptPaper order={completedOrder} settings={settings} showActions />
          </div>
        </div>
      )}
    </div>
  );
};

// ==================== ADMIN RECEIPT HISTORY ====================
export const AdminReceiptsPage: React.FC = () => {
  const { settings } = useApp();
  const [rows, setRows] = useState<
    Array<{ id: string; receiptNumber: string; issuedAt: string; order: OrderDetail }>
  >([]);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<OrderDetail | null>(null);

  const load = useCallback(async () => {
    const q = search.trim() ? `?search=${encodeURIComponent(search.trim())}` : '';
    const data = await apiFetch<{
      receipts: Array<{ id: string; receiptNumber: string; issuedAt: string; order: OrderDetail }>;
    }>(`/api/admin/receipts${q}`);
    setRows(data.receipts);
  }, [search]);

  useEffect(() => {
    load().catch(() => {});
  }, [load]);

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#1C1917]">Receipt History</h1>
          <p className="text-xs text-stone-500">
            Search, view, print, or download PDF copies of any issued SPIZEE receipt.
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search receipt #, order #, customer…"
            className="w-full rounded-xl border border-stone-200 bg-white py-2 pl-9 pr-3 text-xs"
          />
        </div>
      </div>

      <div className="no-print glass-surface overflow-x-auto rounded-2xl">
        {rows.length === 0 ? (
          <div className="p-10 text-center text-sm text-stone-500">No receipts found yet.</div>
        ) : (
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-stone-200 text-stone-500">
                <th className="px-4 py-3 font-semibold">Receipt #</th>
                <th className="px-4 py-3 font-semibold">Order</th>
                <th className="px-4 py-3 font-semibold">Customer</th>
                <th className="px-4 py-3 font-semibold">Issued (Asia/Dhaka)</th>
                <th className="px-4 py-3 text-right font-semibold">Total</th>
                <th className="px-4 py-3 text-right font-semibold">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 tabular-nums">
              {rows.map((r) => {
                const dt = formatDhakaDateTime(r.issuedAt);
                return (
                  <tr key={r.id} className="hover:bg-[#FFFDF5]">
                    <td className="px-4 py-3 font-mono font-bold text-[#1C1917]">
                      {r.receiptNumber}
                    </td>
                    <td className="px-4 py-3 font-mono">
                      #{r.order.orderNumber} ({r.order.source.toUpperCase()})
                    </td>
                    <td className="px-4 py-3">{r.order.customerName || 'Walk-in'}</td>
                    <td className="px-4 py-3 text-stone-600">
                      {dt.dateStr} · {dt.timeStr}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold">
                      {formatBdt(r.order.totalAmount)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="inline-flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => setSelected(r.order)}
                          className="rounded-lg bg-[#FFF3C4] px-2.5 py-1.5 text-xs font-bold text-[#1C1917] hover:bg-[#F5B800]"
                        >
                          View
                        </button>
                        <button
                          type="button"
                          onClick={() => downloadReceiptPdf(r.order, settings)}
                          className="inline-flex items-center gap-1 rounded-lg bg-[#1C1917] px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-stone-800"
                        >
                          <Download className="h-3.5 w-3.5" />
                          PDF
                        </button>
                        <button
                          type="button"
                          title="Print Receipt (Customer + Kitchen Copy)"
                          onClick={() => {
                            void printReceiptHtml(r.order, settings);
                          }}
                          className="inline-flex cursor-pointer items-center gap-1 rounded-lg bg-emerald-600 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700"
                        >
                          <Printer className="h-3.5 w-3.5" />
                          Print
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {selected && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-stone-900/45 p-4 backdrop-blur-xs"
          onClick={() => setSelected(null)}
        >
          <div
            className="relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-3xl bg-[#FFFDF7] p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setSelected(null)}
              aria-label="Close receipt modal"
              className="no-print absolute right-4 top-4 rounded-full bg-white p-1.5 text-stone-700 shadow"
            >
              <X className="h-4 w-4" />
            </button>
            <ReceiptPaper order={selected} settings={settings} showActions />
          </div>
        </div>
      )}
    </div>
  );
};
