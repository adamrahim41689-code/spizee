import React, { useCallback, useEffect, useState } from 'react';
import { Edit2, Eye, Save, Trash2, Upload, X } from 'lucide-react';
import { apiFetch, uploadImageFile } from '../../lib/api';
import type { Banner, CustomerSummary, Offer, OrderDetail, Product, SiteSettings } from '../../types';
import { formatBdt, formatDhakaDateTime } from '../../utils/orderMath';
import { copy } from '../../i18n/en';
import { useApp } from '../../context/AppContext';
import { FoodImage } from '../../components/FoodImage';
import { SpizeeLogo } from '../../components/SpizeeLogo';

// ==================== ADMIN CUSTOMERS ====================
export const AdminCustomersPage: React.FC = () => {
  const { showToast } = useApp();
  const [customers, setCustomers] = useState<CustomerSummary[]>([]);
  const [search, setSearch] = useState('');
  const [inspectCustomer, setInspectCustomer] = useState<CustomerSummary | null>(null);
  const [customerOrders, setCustomerOrders] = useState<OrderDetail[]>([]);

  const load = useCallback(async () => {
    const data = await apiFetch<{ customers: CustomerSummary[] }>('/api/admin/customers');
    setCustomers(data.customers);
  }, []);

  useEffect(() => {
    load().catch(() => {});
  }, [load]);

  const toggleActive = async (c: CustomerSummary) => {
    try {
      await apiFetch(`/api/admin/customers/${c.id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ isActive: !c.isActive }),
      });
      showToast(`${c.fullName || c.email} ${!c.isActive ? 'activated' : 'deactivated'}`, 'info');
      await load();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const openHistory = async (c: CustomerSummary) => {
    setInspectCustomer(c);
    const data = await apiFetch<{ orders: OrderDetail[] }>(`/api/admin/customers/${c.id}/orders`);
    setCustomerOrders(data.orders);
  };

  const filtered = customers.filter((c) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      (c.fullName || '').toLowerCase().includes(q) ||
      c.email.toLowerCase().includes(q) ||
      (c.phone || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#1C1917]">Customers</h1>
          <p className="text-xs text-stone-500">View customer profiles, purchase history, and account status.</p>
        </div>
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search name, email, phone…"
          className="w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-xs sm:w-72"
        />
      </div>

      <div className="glass-surface overflow-x-auto rounded-2xl">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-stone-200 text-stone-500">
              <th className="px-4 py-3 font-semibold">User</th>
              <th className="px-4 py-3 font-semibold">Phone &amp; Address</th>
              <th className="px-4 py-3 font-semibold">Role</th>
              <th className="px-4 py-3 text-right font-semibold">Orders</th>
              <th className="px-4 py-3 text-right font-semibold">Total Spent</th>
              <th className="px-4 py-3 font-semibold">Status</th>
              <th className="px-4 py-3 text-right font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100 tabular-nums">
            {filtered.map((c) => (
              <tr key={c.id}>
                <td className="px-4 py-3">
                  <p className="font-semibold text-[#1C1917]">{c.fullName || '—'}</p>
                  <p className="text-[11px] text-stone-500">{c.email}</p>
                </td>
                <td className="px-4 py-3">
                  <p className="font-mono">{c.phone || '—'}</p>
                  <p className="max-w-[200px] truncate text-[11px] text-stone-500">{c.address || '—'}</p>
                </td>
                <td className="px-4 py-3 font-semibold uppercase">{c.role}</td>
                <td className="px-4 py-3 text-right font-mono">{c.totalOrders}</td>
                <td className="px-4 py-3 text-right font-mono font-bold">{formatBdt(c.totalSpent)}</td>
                <td className="px-4 py-3 font-semibold">
                  <span className={c.isActive ? 'text-emerald-700' : 'text-red-700'}>
                    {c.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="inline-flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => openHistory(c)}
                      className="inline-flex items-center gap-1 rounded-lg border border-stone-200 bg-white px-2.5 py-1 text-[11px] font-semibold hover:border-[#F5B800]"
                    >
                      <Eye className="h-3 w-3" />
                      Orders
                    </button>
                    {c.role === 'customer' && (
                      <button
                        type="button"
                        onClick={() => toggleActive(c)}
                        className="rounded-lg bg-stone-100 px-2.5 py-1 text-[11px] font-semibold text-stone-700 hover:bg-[#FFF3C4]"
                      >
                        {c.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {inspectCustomer && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/45 p-4"
          onClick={() => setInspectCustomer(null)}
        >
          <div
            className="max-h-[85vh] w-full max-w-xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div>
                <h2 className="font-display text-lg font-bold">
                  {inspectCustomer.fullName || inspectCustomer.email}
                </h2>
                <p className="text-xs text-stone-500">{inspectCustomer.email}</p>
              </div>
              <button type="button" onClick={() => setInspectCustomer(null)} className="p-1">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="mt-4 space-y-3">
              {customerOrders.length === 0 ? (
                <p className="py-6 text-center text-xs text-stone-500">No orders placed yet.</p>
              ) : (
                customerOrders.map((o) => {
                  const dt = formatDhakaDateTime(o.createdAt);
                  return (
                    <div key={o.id} className="rounded-xl border border-stone-200 p-3.5 text-xs">
                      <div className="flex justify-between font-bold">
                        <span>Order #{o.orderNumber}</span>
                        <span className="font-mono">{formatBdt(o.totalAmount)}</span>
                      </div>
                      <p className="mt-0.5 text-stone-500">
                        {dt.dateStr} {dt.timeStr} · {copy.orderTypes[o.orderType]} · {copy.orderStatuses[o.status]}
                      </p>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// ==================== ADMIN BANNERS ====================
export const AdminBannersPage: React.FC = () => {
  const { showToast, requestConfirm, refreshCatalog } = useApp();
  const [banners, setBanners] = useState<Banner[]>([]);
  const [editing, setEditing] = useState<Banner | null>(null);
  const [imageUrl, setImageUrl] = useState('');
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [offerText, setOfferText] = useState('');
  const [buttonText, setButtonText] = useState('Order Now');
  const [buttonLink, setButtonLink] = useState('/menu');
  const [position, setPosition] = useState('1');
  const [isActive, setIsActive] = useState(true);

  const load = useCallback(async () => {
    const data = await apiFetch<{ banners: Banner[] }>('/api/admin/catalog');
    setBanners(data.banners);
  }, []);

  useEffect(() => {
    load().catch(() => {});
  }, [load]);

  const reset = () => {
    setEditing(null);
    setImageUrl('');
    setTitle('');
    setSubtitle('');
    setOfferText('');
    setButtonText('Order Now');
    setButtonLink('/menu');
    setPosition('1');
    setIsActive(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      imageUrl: imageUrl || null,
      title,
      subtitle,
      offerText,
      buttonText,
      buttonLink,
      position: Number(position) || 0,
      isActive,
    };
    if (editing) {
      await apiFetch(`/api/admin/banners/${editing.id}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
      showToast('Banner updated', 'success');
    } else {
      await apiFetch('/api/admin/banners', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      showToast('Banner added', 'success');
    }
    reset();
    await load();
    await refreshCatalog();
  };

  return (
    <div className="grid gap-6 lg:grid-cols-12">
      <form onSubmit={handleSave} className="glass-surface h-fit space-y-3 rounded-2xl p-5 lg:col-span-5">
        <h1 className="font-display text-lg font-bold">
          {editing ? 'Edit Banner' : 'Add Promotional Banner'}
        </h1>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Title</label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Subtitle</label>
          <textarea
            rows={2}
            value={subtitle}
            onChange={(e) => setSubtitle(e.target.value)}
            className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700">Offer Tagline</label>
            <input
              type="text"
              value={offerText}
              onChange={(e) => setOfferText(e.target.value)}
              placeholder="e.g. Save ৳100"
              className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-xs"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">Position</label>
            <input
              type="number"
              value={position}
              onChange={(e) => setPosition(e.target.value)}
              className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-xs"
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700">CTA Label</label>
            <input
              type="text"
              value={buttonText}
              onChange={(e) => setButtonText(e.target.value)}
              className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-xs"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">CTA Link</label>
            <input
              type="text"
              value={buttonLink}
              onChange={(e) => setButtonLink(e.target.value)}
              className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-xs"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Banner Image</label>
          <div className="mt-1 flex gap-2">
            <input
              type="text"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              placeholder="/uploads/banners/…"
              className="min-w-0 flex-1 rounded-xl border border-stone-200 px-3 py-2 text-xs"
            />
            <label className="inline-flex cursor-pointer items-center gap-1 rounded-xl bg-stone-100 px-3 py-2 text-xs font-semibold hover:bg-[#FFF3C4]">
              <Upload className="h-3.5 w-3.5" />
              Upload
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  try {
                    setImageUrl(await uploadImageFile('banners', f));
                    showToast('Banner uploaded', 'success');
                  } catch (err: any) {
                    showToast(err.message, 'error');
                  }
                }}
                className="sr-only"
              />
            </label>
          </div>
        </div>
        <label className="inline-flex items-center gap-2 text-xs font-semibold">
          <input
            type="checkbox"
            checked={isActive}
            onChange={(e) => setIsActive(e.target.checked)}
            className="h-4 w-4 accent-[#F5B800]"
          />
          Active on Homepage
        </label>
        <div className="flex gap-2 pt-2">
          <button
            type="submit"
            className="flex-1 rounded-xl bg-[#F5B800] py-2.5 text-xs font-bold text-[#1C1917]"
          >
            {editing ? 'Update Banner' : 'Add Banner'}
          </button>
          {editing && (
            <button
              type="button"
              onClick={reset}
              className="rounded-xl border border-stone-300 px-4 text-xs font-semibold"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <div className="space-y-4 lg:col-span-7">
        <h2 className="font-display text-lg font-bold">Active &amp; Scheduled Banners ({banners.length})</h2>
        {banners.map((b) => (
          <div key={b.id} className="glass-surface flex flex-col gap-4 rounded-2xl p-4 sm:flex-row">
            <div className="h-28 w-full shrink-0 overflow-hidden rounded-xl bg-[#FAF6EA] sm:w-44">
              <FoodImage src={b.imageUrl} alt={b.title || 'Banner'} className="h-full w-full object-cover" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-bold text-[#B47B00]">
                Position #{b.position} · {b.isActive ? 'Active' : 'Inactive'}
                {b.offerText ? ` · ${b.offerText}` : ''}
              </p>
              <h3 className="font-display text-base font-bold text-[#1C1917]">{b.title}</h3>
              <p className="mt-1 line-clamp-2 text-xs text-stone-600">{b.subtitle}</p>
              <div className="mt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditing(b);
                    setImageUrl(b.imageUrl || '');
                    setTitle(b.title || '');
                    setSubtitle(b.subtitle || '');
                    setOfferText(b.offerText || '');
                    setButtonText(b.buttonText || 'Order Now');
                    setButtonLink(b.buttonLink || '/menu');
                    setPosition(String(b.position));
                    setIsActive(b.isActive);
                  }}
                  className="inline-flex items-center gap-1 rounded-lg border border-stone-200 bg-white px-3 py-1 text-xs font-semibold"
                >
                  <Edit2 className="h-3 w-3" />
                  Edit
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    const ok = await requestConfirm({
                      title: 'Delete this banner?',
                      message: 'It will be removed from the homepage slider immediately.',
                      confirmLabel: 'Delete',
                      destructive: true,
                    });
                    if (!ok) return;
                    await apiFetch(`/api/admin/banners/${b.id}`, { method: 'DELETE' });
                    showToast('Banner deleted', 'info');
                    await load();
                    await refreshCatalog();
                  }}
                  className="inline-flex items-center gap-1 rounded-lg border border-stone-200 bg-white px-3 py-1 text-xs font-semibold text-red-600"
                >
                  <Trash2 className="h-3 w-3" />
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ==================== ADMIN OFFERS ====================
export const AdminOffersPage: React.FC = () => {
  const { showToast, requestConfirm, refreshCatalog } = useApp();
  const [offers, setOffers] = useState<Offer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [editing, setEditing] = useState<Offer | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [offerType, setOfferType] = useState('percentage');
  const [discountPercentage, setDiscountPercentage] = useState('10');
  const [discountAmount, setDiscountAmount] = useState('');
  const [applicableIds, setApplicableIds] = useState<string[]>([]);
  const [isActive, setIsActive] = useState(true);

  const load = useCallback(async () => {
    const data = await apiFetch<{ offers: Offer[]; products: Product[] }>('/api/admin/catalog');
    setOffers(data.offers);
    setProducts(data.products);
  }, []);

  useEffect(() => {
    load().catch(() => {});
  }, [load]);

  const reset = () => {
    setEditing(null);
    setTitle('');
    setDescription('');
    setOfferType('percentage');
    setDiscountPercentage('10');
    setDiscountAmount('');
    setApplicableIds([]);
    setIsActive(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      title,
      description,
      offerType,
      discountPercentage: offerType === 'percentage' ? Number(discountPercentage) : null,
      discountAmount: offerType !== 'percentage' && discountAmount ? Number(discountAmount) : null,
      applicableProductIds: applicableIds,
      isActive,
    };
    if (editing) {
      await apiFetch(`/api/admin/offers/${editing.id}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
      showToast('Offer updated live', 'success');
    } else {
      await apiFetch('/api/admin/offers', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      showToast('Offer created and applied to storefront', 'success');
    }
    reset();
    await load();
    await refreshCatalog();
  };

  return (
    <div className="grid gap-6 lg:grid-cols-12">
      <form onSubmit={handleSave} className="glass-surface h-fit space-y-3 rounded-2xl p-5 lg:col-span-5">
        <h1 className="font-display text-lg font-bold">
          {editing ? 'Edit Offer' : 'Create Offer / Discount'}
        </h1>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Offer Title *</label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Friday 15% Crunch"
            className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Description</label>
          <textarea
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-stone-700">Offer Type</label>
            <select
              value={offerType}
              onChange={(e) => setOfferType(e.target.value)}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs"
            >
              <option value="percentage">Percentage (%)</option>
              <option value="fixed">Fixed Discount (৳)</option>
              <option value="combo">Combo Savings (৳)</option>
              <option value="special_price">Special Fixed Price (৳)</option>
              <option value="limited_time">Limited Time (৳ off)</option>
            </select>
          </div>
          {offerType === 'percentage' ? (
            <div>
              <label className="block text-xs font-semibold text-stone-700">Discount %</label>
              <input
                type="number"
                min="1"
                max="95"
                value={discountPercentage}
                onChange={(e) => setDiscountPercentage(e.target.value)}
                className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-xs"
              />
            </div>
          ) : (
            <div>
              <label className="block text-xs font-semibold text-stone-700">Amount (৳)</label>
              <input
                type="number"
                min="1"
                value={discountAmount}
                onChange={(e) => setDiscountAmount(e.target.value)}
                className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-xs"
              />
            </div>
          )}
        </div>
        <div>
          <p className="text-xs font-semibold text-stone-700">
            Applicable Products (leave none selected for storewide)
          </p>
          <div className="mt-1.5 max-h-36 space-y-1 overflow-y-auto rounded-xl border border-stone-200 p-2.5 text-xs">
            {products.map((p) => (
              <label key={p.id} className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={applicableIds.includes(p.id)}
                  onChange={(e) =>
                    setApplicableIds((prev) =>
                      e.target.checked ? [...prev, p.id] : prev.filter((id) => id !== p.id)
                    )
                  }
                  className="accent-[#F5B800]"
                />
                <span>{p.name}</span>
              </label>
            ))}
          </div>
        </div>
        <label className="inline-flex items-center gap-2 text-xs font-semibold">
          <input
            type="checkbox"
            checked={isActive}
            onChange={(e) => setIsActive(e.target.checked)}
            className="h-4 w-4 accent-[#F5B800]"
          />
          Active Offer
        </label>
        <div className="flex gap-2">
          <button
            type="submit"
            className="flex-1 rounded-xl bg-[#F5B800] py-2.5 text-xs font-bold text-[#1C1917]"
          >
            {editing ? 'Update Offer' : 'Save Offer'}
          </button>
          {editing && (
            <button
              type="button"
              onClick={reset}
              className="rounded-xl border border-stone-300 px-4 text-xs font-semibold"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      <div className="space-y-3 lg:col-span-7">
        <h2 className="font-display text-lg font-bold">Configured Offers ({offers.length})</h2>
        {offers.map((o) => (
          <div key={o.id} className="glass-surface flex items-start justify-between gap-4 rounded-2xl p-4">
            <div>
              <p className="text-[11px] font-bold uppercase text-[#B47B00]">
                {o.offerType} · {o.isActive ? 'Active' : 'Paused'}
              </p>
              <h3 className="font-display text-base font-bold">{o.title}</h3>
              <p className="mt-1 text-xs text-stone-600">{o.description}</p>
              <p className="mt-1 font-mono text-xs font-semibold text-[#1C1917]">
                {o.discountPercentage ? `${o.discountPercentage}% Off` : formatBdt(o.discountAmount)} ·{' '}
                {o.applicableProductIds.length > 0
                  ? `${o.applicableProductIds.length} products`
                  : 'All products'}
              </p>
            </div>
            <div className="flex gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setEditing(o);
                  setTitle(o.title);
                  setDescription(o.description || '');
                  setOfferType(o.offerType);
                  setDiscountPercentage(o.discountPercentage ? String(o.discountPercentage) : '');
                  setDiscountAmount(o.discountAmount ? String(o.discountAmount) : '');
                  setApplicableIds(o.applicableProductIds);
                  setIsActive(o.isActive);
                }}
                className="rounded-lg border border-stone-200 p-1.5"
              >
                <Edit2 className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={async () => {
                  const ok = await requestConfirm({
                    title: `Delete offer "${o.title}"?`,
                    message: 'Prices will revert to regular catalog rates immediately.',
                    confirmLabel: 'Delete',
                    destructive: true,
                  });
                  if (!ok) return;
                  await apiFetch(`/api/admin/offers/${o.id}`, { method: 'DELETE' });
                  showToast('Offer deleted', 'info');
                  await load();
                  await refreshCatalog();
                }}
                className="rounded-lg border border-stone-200 p-1.5 text-red-600"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ==================== WEBSITE SETTINGS & CONTACT/SOCIAL ====================
export const AdminSettingsPage: React.FC<{ section?: 'general' | 'contact' }> = ({
  section = 'general',
}) => {
  const { settings, refreshCatalog, showToast } = useApp();
  const [form, setForm] = useState<Partial<SiteSettings>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) {
      const defaultCopyright = `© ${new Date().getFullYear()} ${settings.restaurantName || 'SPIZEE'} (স্পাইজি). All rights reserved.`;
      const defaultRightText = 'Prices in Bangladeshi Taka (৳ BDT) · Asia/Dhaka Time';
      setForm({
        ...settings,
        footerCopyright:
          settings.footerCopyright !== null && settings.footerCopyright !== undefined
            ? settings.footerCopyright
            : defaultCopyright,
        footerRightText:
          settings.footerRightText !== null && settings.footerRightText !== undefined
            ? settings.footerRightText
            : defaultRightText,
        footerTextSize: settings.footerTextSize || 'xs',
      });
    }
  }, [settings]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await apiFetch('/api/admin/settings', {
        method: 'PUT',
        body: JSON.stringify(form),
      });
      await refreshCatalog();
      showToast('Website settings updated live!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Save failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSave} className="glass-surface max-w-3xl space-y-5 rounded-3xl p-6 sm:p-8">
      <div>
        <h1 className="font-display text-2xl font-extrabold text-[#1C1917]">
          {section === 'general' ? 'Website Settings & Branding' : 'Contact & Social Media'}
        </h1>
        <p className="mt-1 text-xs text-stone-500">
          Updates reflect immediately across the Header, Footer, Contact page, Checkout, and Receipts.
        </p>
      </div>

      {section === 'general' ? (
        <>
          <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-stone-200 bg-[#FFFDF7] p-4">
            <SpizeeLogo size="lg" logoOverride={form.logoUrl ?? null} />
            <div className="flex-1">
              <p className="text-xs font-bold text-[#1C1917]">Upload Official SPIZEE Logo</p>
              <p className="text-[11px] text-stone-500">
                Used unaltered across Header, Footer, Login, Sidebar, Receipts, and Browser Favicon.
              </p>
              <label className="mt-2 inline-flex cursor-pointer items-center gap-1.5 rounded-xl bg-[#F5B800] px-3.5 py-2 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700]">
                <Upload className="h-3.5 w-3.5" />
                Upload Logo (PNG/JPG/WebP)
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    try {
                      const url = await uploadImageFile('site-assets', f);
                      setForm((prev) => ({ ...prev, logoUrl: url }));
                      showToast('Logo uploaded — click Save Settings to apply', 'success');
                    } catch (err: any) {
                      showToast(err.message, 'error');
                    }
                  }}
                  className="sr-only"
                />
              </label>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-semibold text-stone-700">Restaurant Name</label>
              <input
                type="text"
                value={form.restaurantName || ''}
                onChange={(e) => setForm({ ...form, restaurantName: e.target.value })}
                className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-700">Opening Hours</label>
              <input
                type="text"
                value={form.openingHours || ''}
                onChange={(e) => setForm({ ...form, openingHours: e.target.value })}
                className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700">Short Description</label>
            <textarea
              rows={3}
              value={form.shortDescription || ''}
              onChange={(e) => setForm({ ...form, shortDescription: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-700">Delivery Information</label>
            <textarea
              rows={2}
              value={form.deliveryInfo || ''}
              onChange={(e) => setForm({ ...form, deliveryInfo: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>

          <div className="space-y-4 rounded-2xl border border-stone-200 bg-[#FFFDF7] p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="font-display text-base font-bold text-[#1C1917]">
                  Footer Bottom Bar &amp; Copyright
                </h2>
                <p className="text-[11px] text-stone-500">
                  Edit or resize the copyright notice and currency/time note at the bottom of your website. Leave any field blank to hide it.
                </p>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="footer-copyright" className="block text-xs font-semibold text-stone-700">
                  Copyright Text (Left)
                </label>
                <input
                  id="footer-copyright"
                  type="text"
                  value={form.footerCopyright ?? ''}
                  onChange={(e) => setForm({ ...form, footerCopyright: e.target.value })}
                  placeholder="© 2026 SPIZEE (স্পাইজি). All rights reserved."
                  className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm focus:border-[#F5B800] focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="footer-right-text" className="block text-xs font-semibold text-stone-700">
                  Right Side Text (Currency / Time / Custom)
                </label>
                <input
                  id="footer-right-text"
                  type="text"
                  value={form.footerRightText ?? ''}
                  onChange={(e) => setForm({ ...form, footerRightText: e.target.value })}
                  placeholder="Prices in Bangladeshi Taka (৳ BDT) · Asia/Dhaka Time"
                  className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm focus:border-[#F5B800] focus:outline-none"
                />
              </div>
            </div>

            <div className="sm:max-w-xs">
              <label htmlFor="footer-text-size" className="block text-xs font-semibold text-stone-700">
                Footer Text Size
              </label>
              <select
                id="footer-text-size"
                value={form.footerTextSize || 'xs'}
                onChange={(e) => setForm({ ...form, footerTextSize: e.target.value })}
                className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm font-medium focus:border-[#F5B800] focus:outline-none"
              >
                <option value="xs">Small (Default · 12px)</option>
                <option value="sm">Medium (14px)</option>
                <option value="base">Large (16px)</option>
                <option value="lg">Extra Large (18px)</option>
              </select>
            </div>

            <div className="rounded-xl border border-dashed border-stone-300 bg-white px-4 py-3">
              <p className="mb-1.5 text-[10px] font-bold tracking-wider text-stone-400 uppercase">
                Live Footer Preview
              </p>
              <div
                className={`flex flex-col items-center justify-between gap-2 text-stone-600 sm:flex-row ${
                  form.footerTextSize === 'lg'
                    ? 'text-lg font-semibold'
                    : form.footerTextSize === 'base'
                    ? 'text-base font-medium'
                    : form.footerTextSize === 'sm'
                    ? 'text-sm'
                    : 'text-xs'
                }`}
              >
                <span>{form.footerCopyright || <em className="text-stone-300">(Hidden)</em>}</span>
                <span>{form.footerRightText || <em className="text-stone-300">(Hidden)</em>}</span>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-stone-700">Restaurant Address</label>
            <input
              type="text"
              value={form.address || ''}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">Phone</label>
            <input
              type="text"
              value={form.phone || ''}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">Email</label>
            <input
              type="email"
              value={form.email || ''}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">Facebook URL</label>
            <input
              type="url"
              value={form.facebook || ''}
              onChange={(e) => setForm({ ...form, facebook: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">Instagram URL</label>
            <input
              type="url"
              value={form.instagram || ''}
              onChange={(e) => setForm({ ...form, instagram: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">TikTok URL</label>
            <input
              type="url"
              value={form.tiktok || ''}
              onChange={(e) => setForm({ ...form, tiktok: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-stone-700">WhatsApp Number</label>
            <input
              type="text"
              value={form.whatsapp || ''}
              onChange={(e) => setForm({ ...form, whatsapp: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs font-semibold text-stone-700">Google Maps Link</label>
            <input
              type="url"
              value={form.googleMapsUrl || ''}
              onChange={(e) => setForm({ ...form, googleMapsUrl: e.target.value })}
              className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2 text-sm"
            />
          </div>
        </div>
      )}

      <button
        type="submit"
        disabled={saving}
        className="inline-flex items-center gap-2 rounded-xl bg-[#F5B800] px-6 py-2.5 text-sm font-bold text-[#1C1917] hover:bg-[#E0A700]"
      >
        <Save className="h-4 w-4" />
        {saving ? 'Saving…' : 'Save Settings'}
      </button>
    </form>
  );
};

// ==================== ADMIN PROFILE ====================
export const AdminProfilePage: React.FC = () => {
  const { user, refreshProfile, showToast } = useApp();
  const [fullName, setFullName] = useState(user?.fullName || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const saveInfo = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify({ fullName, phone }),
    });
    await refreshProfile();
    showToast('Admin profile updated', 'success');
  };

  const changePwd = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      setCurrentPassword('');
      setNewPassword('');
      showToast('Admin password updated', 'success');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  return (
    <div className="grid max-w-4xl gap-6 md:grid-cols-2">
      <form onSubmit={saveInfo} className="glass-surface space-y-4 rounded-3xl p-6">
        <h1 className="font-display text-lg font-bold">Admin Profile</h1>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Name</label>
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Email</label>
          <input
            type="email"
            disabled
            value={user?.email || ''}
            className="mt-1 w-full rounded-xl border border-stone-200 bg-stone-50 px-3 py-2 text-sm text-stone-500"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Phone</label>
          <input
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
          />
        </div>
        <button
          type="submit"
          className="rounded-xl bg-[#F5B800] px-5 py-2.5 text-xs font-bold text-[#1C1917]"
        >
          Save Profile
        </button>
      </form>

      <form onSubmit={changePwd} className="glass-surface space-y-4 rounded-3xl p-6">
        <h2 className="font-display text-lg font-bold">Change Admin Password</h2>
        <div>
          <label className="block text-xs font-semibold text-stone-700">Current Password</label>
          <input
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
          />
        </div>
        <div>
          <label className="block text-xs font-semibold text-stone-700">New Password</label>
          <input
            type="password"
            minLength={6}
            required
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="mt-1 w-full rounded-xl border border-stone-200 px-3 py-2 text-sm"
          />
        </div>
        <button
          type="submit"
          className="rounded-xl bg-[#1C1917] px-5 py-2.5 text-xs font-bold text-white"
        >
          Update Password
        </button>
      </form>
    </div>
  );
};
