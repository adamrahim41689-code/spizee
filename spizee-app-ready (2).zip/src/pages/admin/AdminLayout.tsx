import React, { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  FolderTree,
  Image as ImageIcon,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  Percent,
  Receipt,
  Ruler,
  Settings,
  Share2,
  ShieldCheck,
  ShoppingCart,
  Store,
  UserCog,
  Users,
  X,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { SpizeeLogo } from '../../components/SpizeeLogo';

const navItems = [
  { to: '/admin', label: 'Dashboard Overview', icon: LayoutDashboard, end: true },
  { to: '/admin/products', label: 'Products', icon: Package },
  { to: '/admin/categories', label: 'Categories', icon: FolderTree },
  { to: '/admin/sizes', label: 'Product Sizes', icon: Ruler },
  { to: '/admin/orders', label: 'Orders', icon: ShoppingCart },
  { to: '/admin/pos', label: 'POS / Quick Order', icon: Store },
  { to: '/admin/customers', label: 'Customers', icon: Users },
  { to: '/admin/team', label: 'Admins & Managers', icon: ShieldCheck },
  { to: '/admin/banners', label: 'Promotional Banners', icon: ImageIcon },
  { to: '/admin/offers', label: 'Offers & Discounts', icon: Percent },
  { to: '/admin/receipts', label: 'Receipt History', icon: Receipt },
  { to: '/admin/settings', label: 'Website Settings', icon: Settings },
  { to: '/admin/contact-social', label: 'Contact & Social', icon: Share2 },
  { to: '/admin/profile', label: 'Admin Profile', icon: UserCog },
];

export const AdminLayout: React.FC = () => {
  const { user, authLoading, logout, showToast } = useApp();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const hasDashboardAccess = user?.role === 'admin' || user?.role === 'manager';

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      navigate('/login?redirect=/admin', { replace: true });
    } else if (!hasDashboardAccess) {
      showToast('Admin or Manager privileges are required to view that page.', 'error');
      navigate('/', { replace: true });
    }
  }, [authLoading, user, hasDashboardAccess, navigate, showToast]);

  if (authLoading || !user || !hasDashboardAccess) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#FFFDF7] p-6">
        <div className="h-12 w-48 animate-pulse rounded-2xl bg-stone-200/80" />
      </div>
    );
  }

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition whitespace-nowrap ${
      isActive
        ? 'bg-[#F5B800] text-[#1C1917] shadow-xs'
        : 'text-stone-700 hover:bg-[#FFF6D6] hover:text-[#1C1917]'
    }`;

  return (
    <div className="flex min-h-screen bg-[#FAF7EE] text-[#1C1917]">
      {/* Desktop Collapsible Sidebar */}
      <aside
        className={`no-print sticky top-0 hidden h-screen flex-col border-r border-stone-200/90 bg-white/90 backdrop-blur-md transition-all duration-200 lg:flex ${
          collapsed ? 'w-[76px]' : 'w-64'
        }`}
      >
        <div className="flex h-16 items-center justify-between border-b border-stone-200/80 px-4">
          {!collapsed && (
            <Link to="/admin" className="shrink-0">
              <SpizeeLogo size="sm" />
            </Link>
          )}
          <button
            type="button"
            onClick={() => setCollapsed((c) => !c)}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-stone-200 bg-white text-stone-600 hover:bg-[#FFF9E6] hover:text-[#1C1917]"
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </button>
        </div>

        <nav aria-label="Admin navigation" className="flex-1 space-y-1 overflow-y-auto p-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                title={collapsed ? item.label : undefined}
                className={linkClass}
              >
                <Icon className="h-4 w-4 shrink-0" />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </NavLink>
            );
          })}
        </nav>

        <div className="border-t border-stone-200/80 p-3 space-y-1.5">
          <Link
            to="/"
            className="flex items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-stone-600 hover:bg-stone-100 hover:text-[#1C1917]"
          >
            <ExternalLink className="h-4 w-4 shrink-0" />
            {!collapsed && <span>View Storefront</span>}
          </Link>
          <button
            type="button"
            onClick={async () => {
              await logout();
              navigate('/login');
            }}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-50"
          >
            <LogOut className="h-4 w-4 shrink-0" />
            {!collapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* Mobile Sidebar Drawer */}
      {mobileOpen && (
        <div
          className="no-print fixed inset-0 z-50 flex bg-stone-900/40 backdrop-blur-xs lg:hidden"
          onClick={() => setMobileOpen(false)}
        >
          <aside
            className="flex h-full w-72 flex-col bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex h-16 items-center justify-between border-b border-stone-200 px-4">
              <SpizeeLogo size="sm" />
              <button
                type="button"
                aria-label="Close admin sidebar"
                onClick={() => setMobileOpen(false)}
                className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-stone-600 hover:bg-stone-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex-1 space-y-1 overflow-y-auto p-3">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.end}
                    onClick={() => setMobileOpen(false)}
                    className={linkClass}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </NavLink>
                );
              })}
            </nav>
            <div className="border-t border-stone-200 p-3 space-y-1">
              <Link
                to="/"
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-100"
              >
                <ExternalLink className="h-4 w-4" />
                View Storefront
              </Link>
              <button
                type="button"
                onClick={async () => {
                  await logout();
                  navigate('/login');
                }}
                className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold text-red-700 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Workspace */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="no-print sticky top-0 z-30 flex h-16 items-center justify-between gap-4 border-b border-stone-200/80 bg-white/85 px-4 backdrop-blur-md sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open admin menu"
              className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-stone-200 bg-white text-[#1C1917] lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="text-sm font-semibold text-stone-600">
              SPIZEE Admin Console
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to="/admin/pos"
              className="rounded-xl bg-[#F5B800] px-3.5 py-2 text-xs font-bold text-[#1C1917] transition hover:bg-[#E0A700] whitespace-nowrap"
            >
              Open POS
            </Link>
            <span className="hidden items-center gap-1.5 text-xs font-medium text-stone-600 sm:inline-flex">
              <span>{user.fullName || user.email}</span>
              <span className="rounded-md bg-[#FFF3C4] px-1.5 py-0.5 text-[10px] font-bold uppercase text-[#9A6700]">
                {user.role === 'manager' ? 'Manager' : 'Admin'}
              </span>
            </span>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
