import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { RefreshCw, Sparkles } from 'lucide-react';
import { apiFetch } from '../../lib/api';
import type { AdminOverviewStats } from '../../types';
import { formatBdt } from '../../utils/orderMath';
import { useApp } from '../../context/AppContext';

export const AdminOverview: React.FC = () => {
  const { showToast, refreshCatalog } = useApp();
  const [stats, setStats] = useState<AdminOverviewStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);

  const loadStats = useCallback(async () => {
    try {
      const data = await apiFetch<AdminOverviewStats>('/api/admin/overview');
      setStats(data);
    } catch (err: any) {
      showToast(err.message || 'Could not load dashboard metrics', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  const handleSeedSample = async () => {
    setSeeding(true);
    try {
      const res = await apiFetch<{ message: string }>('/api/admin/seed-sample', { method: 'POST' });
      showToast(res.message || 'Sample menu added!', 'success');
      await refreshCatalog();
      await loadStats();
    } catch (err: any) {
      showToast(err.message || 'Could not add sample menu', 'error');
    } finally {
      setSeeding(false);
    }
  };

  if (loading || !stats) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
            <div key={n} className="h-28 animate-pulse rounded-2xl bg-stone-200/70" />
          ))}
        </div>
      </div>
    );
  }

  const kpiCards = [
    { label: 'Total Revenue', value: formatBdt(stats.kpis.totalRevenue), sub: 'Excludes cancelled orders' },
    { label: "Today's Revenue", value: formatBdt(stats.kpis.todayRevenue), sub: 'Asia/Dhaka today' },
    { label: 'Total Orders', value: String(stats.kpis.totalOrders), sub: 'Online + POS combined' },
    { label: "Today's Orders", value: String(stats.kpis.todayOrders), sub: 'Placed today (BDT time)' },
    { label: 'Pending Orders', value: String(stats.kpis.pendingOrders), sub: 'Awaiting confirmation' },
    { label: 'Completed Orders', value: String(stats.kpis.completedOrders), sub: 'Fulfilled orders' },
    { label: 'Total Products', value: String(stats.kpis.totalProducts), sub: 'Active & draft menu items' },
    { label: 'Total Customers', value: String(stats.kpis.totalCustomers), sub: 'Registered customer profiles' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#1C1917] sm:text-3xl">
            Dashboard Overview
          </h1>
          <p className="mt-1 text-xs text-stone-500">
            All metrics and charts are computed live from your PostgreSQL database (Asia/Dhaka time).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {stats.kpis.totalProducts === 0 && (
            <button
              type="button"
              disabled={seeding}
              onClick={handleSeedSample}
              className="inline-flex items-center gap-1.5 rounded-xl bg-[#F5B800] px-4 py-2 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700]"
            >
              <Sparkles className="h-3.5 w-3.5" />
              {seeding ? 'Adding Sample Menu…' : 'Add Sample Menu'}
            </button>
          )}
          <button
            type="button"
            onClick={loadStats}
            className="inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-4 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </button>
        </div>
      </div>

      {/* 8 KPI Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpiCards.map((card) => (
          <div key={card.label} className="glass-surface rounded-2xl p-5">
            <p className="text-xs font-semibold text-stone-500">{card.label}</p>
            <p className="mt-2 font-mono text-2xl font-bold text-[#1C1917] tabular-nums">
              {card.value}
            </p>
            <p className="mt-1 text-[11px] text-stone-500">{card.sub}</p>
          </div>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Daily Sales */}
        <div className="glass-surface rounded-2xl p-6">
          <h2 className="font-display text-base font-bold text-[#1C1917]">Daily Sales (৳ BDT)</h2>
          <p className="text-xs text-stone-500">Revenue per day across recent active days</p>
          <div className="mt-4 h-64">
            {stats.dailySales.length === 0 ? (
              <EmptyChartState text="No sales data yet. Place an online or POS order to see daily revenue." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={stats.dailySales}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E7E5E4" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(v: any) => formatBdt(v)} />
                  <Area
                    type="monotone"
                    dataKey="sales"
                    stroke="#D99B00"
                    fill="#F5B800"
                    fillOpacity={0.28}
                    strokeWidth={2}
                    dot={{ r: 5, fill: '#F5B800', stroke: '#1C1917', strokeWidth: 1.5 }}
                    activeDot={{ r: 7, fill: '#1C1917', stroke: '#F5B800', strokeWidth: 2 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Monthly Sales */}
        <div className="glass-surface rounded-2xl p-6">
          <h2 className="font-display text-base font-bold text-[#1C1917]">Monthly Sales (৳ BDT)</h2>
          <p className="text-xs text-stone-500">Total monthly revenue excluding cancelled orders</p>
          <div className="mt-4 h-64">
            {stats.monthlySales.length === 0 ? (
              <EmptyChartState text="Monthly sales will populate automatically as orders come in." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.monthlySales}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E7E5E4" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip formatter={(v: any) => formatBdt(v)} />
                  <Bar dataKey="sales" fill="#1C1917" radius={[8, 8, 0, 0]} maxBarSize={56} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Order Statistics by Status */}
        <div className="glass-surface rounded-2xl p-6">
          <h2 className="font-display text-base font-bold text-[#1C1917]">Orders by Status</h2>
          <p className="text-xs text-stone-500">Live distribution across fulfillment states</p>
          <div className="mt-4 h-64">
            {stats.kpis.totalOrders === 0 ? (
              <EmptyChartState text="No orders recorded yet." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.orderStats}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E7E5E4" />
                  <XAxis dataKey="status" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="count" fill="#F5B800" radius={[8, 8, 0, 0]} maxBarSize={56} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Popular Products */}
        <div className="glass-surface rounded-2xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-bold text-[#1C1917]">Popular Products</h2>
              <p className="text-xs text-stone-500">Top dishes ranked by total quantity sold</p>
            </div>
            <Link to="/admin/pos" className="text-xs font-semibold text-[#B47B00] hover:underline">
              New POS Order →
            </Link>
          </div>
          <div className="mt-4 h-64">
            {stats.popularProducts.length === 0 ? (
              <EmptyChartState text="Best-selling items will appear after your first completed order." />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.popularProducts} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E7E5E4" />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                  <YAxis dataKey="name" type="category" width={130} tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="quantity" fill="#D99B00" radius={[0, 8, 8, 0]} maxBarSize={32} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const EmptyChartState: React.FC<{ text: string }> = ({ text }) => (
  <div className="flex h-full items-center justify-center rounded-xl border border-dashed border-stone-200 bg-stone-50/70 p-6 text-center text-xs text-stone-500">
    {text}
  </div>
);
