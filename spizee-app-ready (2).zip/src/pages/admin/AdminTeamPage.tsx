import React, { useCallback, useEffect, useState } from 'react';
import {
  Crown,
  KeyRound,
  Mail,
  RefreshCw,
  ShieldCheck,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import { apiFetch } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import type { TeamMember } from '../../types';

interface PromotableCustomer {
  id: string;
  fullName: string | null;
  email: string;
  phone: string | null;
  isActive: boolean;
  createdAt: string;
}

export const AdminTeamPage: React.FC = () => {
  const { user, showToast, requestConfirm } = useApp();
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [customers, setCustomers] = useState<PromotableCustomer[]>([]);
  const [loading, setLoading] = useState(true);

  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<'admin' | 'manager'>('manager');
  const [password, setPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [pwdTarget, setPwdTarget] = useState<TeamMember | null>(null);
  const [newMemberPwd, setNewMemberPwd] = useState('');
  const [savingPwd, setSavingPwd] = useState(false);

  const loadTeam = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetch<{
        team: TeamMember[];
        promotableCustomers: PromotableCustomer[];
      }>('/api/admin/team');
      setTeam(data.team || []);
      setCustomers(data.promotableCustomers || []);
    } catch (err: any) {
      showToast(err.message || 'Failed to load team members.', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadTeam();
  }, [loadTeam]);

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      showToast('Please enter a valid Gmail or email address.', 'error');
      return;
    }
    if (password && password.length < 6) {
      showToast('Password must be at least 6 characters (or leave blank for Google Sign-In).', 'error');
      return;
    }

    setSaving(true);
    try {
      await apiFetch('/api/admin/team', {
        method: 'POST',
        body: JSON.stringify({
          email: cleanEmail,
          fullName: fullName.trim() || undefined,
          role,
          password: password || undefined,
        }),
      });
      showToast(
        `${cleanEmail} added as ${role === 'admin' ? 'Admin' : 'Manager'} with full dashboard control!`,
        'success'
      );
      setEmail('');
      setFullName('');
      setPassword('');
      setRole('manager');
      await loadTeam();
    } catch (err: any) {
      showToast(err.message || 'Failed to add team member.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleRoleChange = async (member: TeamMember, nextRole: 'admin' | 'manager') => {
    if (member.isOwner || member.role === nextRole) return;
    setBusyId(member.id);
    try {
      await apiFetch(`/api/admin/team/${member.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ role: nextRole }),
      });
      showToast(
        `${member.fullName || member.email} updated to ${nextRole === 'admin' ? 'Admin' : 'Manager'}.`,
        'success'
      );
      await loadTeam();
    } catch (err: any) {
      showToast(err.message || 'Failed to update role.', 'error');
    } finally {
      setBusyId(null);
    }
  };

  const handleRemoveAccess = async (member: TeamMember) => {
    if (member.isOwner) return;
    const confirmed = await requestConfirm({
      title: 'Remove Admin / Manager Access?',
      message: `${member.fullName || member.email} (${member.email}) will immediately lose access to the SPIZEE Admin Dashboard and revert to a regular customer account.`,
      confirmLabel: 'Remove Access',
      destructive: true,
    });
    if (!confirmed) return;

    setBusyId(member.id);
    try {
      await apiFetch(`/api/admin/team/${member.id}`, {
        method: 'DELETE',
      });
      showToast(`Admin access removed for ${member.email}.`, 'success');
      await loadTeam();
    } catch (err: any) {
      showToast(err.message || 'Failed to remove access.', 'error');
    } finally {
      setBusyId(null);
    }
  };

  const handleQuickPromote = async (cust: PromotableCustomer, targetRole: 'admin' | 'manager') => {
    setBusyId(cust.id);
    try {
      await apiFetch('/api/admin/team', {
        method: 'POST',
        body: JSON.stringify({
          email: cust.email,
          fullName: cust.fullName || undefined,
          role: targetRole,
        }),
      });
      showToast(
        `${cust.fullName || cust.email} promoted to ${targetRole === 'admin' ? 'Admin' : 'Manager'}!`,
        'success'
      );
      await loadTeam();
    } catch (err: any) {
      showToast(err.message || 'Failed to promote user.', 'error');
    } finally {
      setBusyId(null);
    }
  };

  const handleSaveMemberPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pwdTarget) return;
    if (newMemberPwd.length < 6) {
      showToast('Password must be at least 6 characters.', 'error');
      return;
    }
    setSavingPwd(true);
    try {
      await apiFetch(`/api/admin/team/${pwdTarget.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ password: newMemberPwd }),
      });
      showToast(`Password updated for ${pwdTarget.email}. They can now sign in with email & password!`, 'success');
      setPwdTarget(null);
      setNewMemberPwd('');
      await loadTeam();
    } catch (err: any) {
      showToast(err.message || 'Failed to update password.', 'error');
    } finally {
      setSavingPwd(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-extrabold text-[#1C1917] sm:text-3xl">
            Admins &amp; Managers
          </h1>
          <p className="mt-1 text-sm text-stone-600">
            Add secondary Admins or Managers by Gmail/Email to give them full control over orders,
            menu, POS, receipts, and settings.
          </p>
        </div>
        <button
          type="button"
          onClick={loadTeam}
          className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-stone-200 bg-white px-4 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh
        </button>
      </div>

      {/* Add New Admin / Manager Form */}
      <form onSubmit={handleAddMember} className="glass-surface rounded-3xl p-6">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#FFF3C4] text-[#9A6700]">
            <UserPlus className="h-4 w-4" />
          </div>
          <div>
            <h2 className="font-display text-lg font-bold text-[#1C1917]">
              Add Admin or Manager
            </h2>
            <p className="text-xs text-stone-500">
              Works immediately — even before they sign in with Google or Email.
            </p>
          </div>
        </div>

        <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <label htmlFor="team-email" className="block text-xs font-semibold text-stone-700">
              Gmail / Email Address *
            </label>
            <div className="relative mt-1.5">
              <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
              <input
                id="team-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="manager@gmail.com"
                className="w-full rounded-xl border border-stone-200 bg-white py-2.5 pl-9 pr-3 text-sm focus:border-[#F5B800] focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label htmlFor="team-name" className="block text-xs font-semibold text-stone-700">
              Full Name (Optional)
            </label>
            <input
              id="team-name"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="e.g. Rahim Manager"
              className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="team-role" className="block text-xs font-semibold text-stone-700">
              Role &amp; Access Level *
            </label>
            <select
              id="team-role"
              value={role}
              onChange={(e) => setRole(e.target.value as 'admin' | 'manager')}
              className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm font-medium focus:border-[#F5B800] focus:outline-none"
            >
              <option value="manager">Manager (Full Control)</option>
              <option value="admin">Second Admin (Full Control)</option>
            </select>
          </div>

          <div>
            <label htmlFor="team-password" className="block text-xs font-semibold text-stone-700">
              Password (Optional)
            </label>
            <div className="relative mt-1.5">
              <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
              <input
                id="team-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Leave blank for Google login"
                className="w-full rounded-xl border border-stone-200 bg-white py-2.5 pl-9 pr-3 text-sm focus:border-[#F5B800] focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-stone-500">
            Added Admins &amp; Managers sign in on the normal Login page using Google or Email and
            automatically get full Admin Console access.
          </p>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-[#F5B800] px-5 py-2.5 text-sm font-bold text-[#1C1917] shadow-xs transition hover:bg-[#E0A700] disabled:opacity-60"
          >
            <ShieldCheck className="h-4 w-4" />
            {saving ? 'Adding…' : role === 'admin' ? 'Add Second Admin' : 'Add Manager'}
          </button>
        </div>
      </form>

      {/* Active Team Table */}
      <div className="glass-surface overflow-hidden rounded-3xl">
        <div className="border-b border-stone-200/80 px-6 py-4">
          <h2 className="font-display text-lg font-bold text-[#1C1917]">
            Active Admins &amp; Managers ({team.length})
          </h2>
        </div>

        {loading ? (
          <div className="p-8 text-center text-sm text-stone-500">Loading team members…</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-stone-200/80 bg-[#FAF7EE] text-xs font-bold text-stone-600 uppercase">
                  <th className="px-6 py-3">Member</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Login Status</th>
                  <th className="px-6 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200/70">
                {team.map((member) => {
                  const isSelf = user?.id === member.id;
                  return (
                    <tr key={member.id} className="hover:bg-[#FFFDF5]">
                      <td className="px-6 py-3.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-[#1C1917]">
                            {member.fullName || member.email.split('@')[0]}
                          </span>
                          {member.isOwner && (
                            <span className="inline-flex items-center gap-1 rounded-md bg-[#FFF3C4] px-2 py-0.5 text-[11px] font-bold text-[#9A6700]">
                              <Crown className="h-3 w-3" />
                              Primary Owner
                            </span>
                          )}
                          {isSelf && !member.isOwner && (
                            <span className="rounded-md bg-stone-100 px-2 py-0.5 text-[10px] font-semibold text-stone-600">
                              You
                            </span>
                          )}
                        </div>
                        <p className="mt-0.5 font-mono text-xs text-stone-500">{member.email}</p>
                      </td>
                      <td className="px-4 py-3.5">
                        {member.isOwner ? (
                          <span className="inline-flex items-center gap-1 rounded-lg bg-[#1C1917] px-2.5 py-1 text-xs font-bold text-white">
                            <ShieldCheck className="h-3.5 w-3.5 text-[#F5B800]" />
                            Owner Admin
                          </span>
                        ) : (
                          <select
                            aria-label={`Role for ${member.email}`}
                            disabled={busyId === member.id}
                            value={member.role}
                            onChange={(e) =>
                              handleRoleChange(member, e.target.value as 'admin' | 'manager')
                            }
                            className="rounded-lg border border-stone-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-[#1C1917] focus:border-[#F5B800] focus:outline-none"
                          >
                            <option value="admin">Admin</option>
                            <option value="manager">Manager</option>
                          </select>
                        )}
                      </td>
                      <td className="px-4 py-3.5 text-xs">
                        {member.hasSignedIn ? (
                          <div className="flex flex-wrap items-center gap-1.5">
                            <span className="inline-flex items-center gap-1 font-semibold text-emerald-700">
                              <UserCheck className="h-3.5 w-3.5" />
                              Active
                            </span>
                            {member.hasPassword && (
                              <span className="rounded bg-stone-100 px-1.5 py-0.5 text-[10px] font-semibold text-stone-600">
                                Password
                              </span>
                            )}
                            {member.hasGoogle && (
                              <span className="rounded bg-amber-50 px-1.5 py-0.5 text-[10px] font-semibold text-amber-800">
                                Google
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="font-medium text-amber-700">
                            Invited · Ready for First Login
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-3.5 text-right">
                        {member.isOwner ? (
                          <span className="text-xs font-medium text-stone-400">Protected</span>
                        ) : (
                          <div className="inline-flex flex-wrap items-center justify-end gap-2">
                            <button
                              type="button"
                              disabled={busyId === member.id}
                              onClick={() => {
                                setPwdTarget(member);
                                setNewMemberPwd('');
                              }}
                              className="inline-flex cursor-pointer items-center gap-1 rounded-lg border border-stone-200 bg-white px-2.5 py-1.5 text-xs font-semibold text-stone-700 transition hover:border-[#F5B800] hover:bg-[#FFF9E6] disabled:opacity-50"
                            >
                              <KeyRound className="h-3.5 w-3.5" />
                              {member.hasPassword ? 'Reset Password' : 'Set Password'}
                            </button>
                            {isSelf ? (
                              <span className="text-xs font-medium text-stone-400">Current Session</span>
                            ) : (
                              <button
                                type="button"
                                disabled={busyId === member.id}
                                onClick={() => handleRemoveAccess(member)}
                                className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 transition hover:bg-red-100 disabled:opacity-50"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                                Remove Access
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Quick Promote Existing Registered Customers */}
      {customers.length > 0 && (
        <div className="glass-surface overflow-hidden rounded-3xl">
          <div className="flex items-center gap-2 border-b border-stone-200/80 px-6 py-4">
            <Users className="h-4 w-4 text-stone-500" />
            <h2 className="font-display text-base font-bold text-[#1C1917]">
              Quick Promote Existing Accounts ({customers.length})
            </h2>
          </div>
          <div className="divide-y divide-stone-200/70">
            {customers.map((c) => (
              <div
                key={c.id}
                className="flex flex-wrap items-center justify-between gap-3 px-6 py-3.5 hover:bg-[#FFFDF5]"
              >
                <div>
                  <p className="text-sm font-semibold text-[#1C1917]">
                    {c.fullName || c.email.split('@')[0]}
                  </p>
                  <p className="font-mono text-xs text-stone-500">{c.email}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={busyId === c.id}
                    onClick={() => handleQuickPromote(c, 'manager')}
                    className="cursor-pointer rounded-lg border border-stone-200 bg-white px-3 py-1.5 text-xs font-semibold text-[#1C1917] transition hover:border-[#F5B800] hover:bg-[#FFF9E6] disabled:opacity-50"
                  >
                    Make Manager
                  </button>
                  <button
                    type="button"
                    disabled={busyId === c.id}
                    onClick={() => handleQuickPromote(c, 'admin')}
                    className="cursor-pointer rounded-lg bg-[#1C1917] px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-stone-800 disabled:opacity-50"
                  >
                    Make Admin
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Set / Reset Password Modal */}
      {pwdTarget && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/45 p-4 backdrop-blur-xs"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleSaveMemberPassword}
            className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl"
          >
            <h3 className="font-display text-lg font-bold text-[#1C1917]">
              {pwdTarget.hasPassword ? 'Reset Login Password' : 'Set Login Password'}
            </h3>
            <p className="mt-1 text-xs text-stone-500">
              Set an Email &amp; Password login for{' '}
              <span className="font-mono font-semibold text-[#1C1917]">{pwdTarget.email}</span>.
            </p>
            <div className="mt-4">
              <label htmlFor="member-new-pwd" className="block text-xs font-semibold text-stone-700">
                New Password (min 6 characters) *
              </label>
              <input
                id="member-new-pwd"
                type="text"
                required
                minLength={6}
                autoFocus
                value={newMemberPwd}
                onChange={(e) => setNewMemberPwd(e.target.value)}
                placeholder="Enter a new password"
                className="mt-1.5 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
              />
            </div>
            <div className="mt-5 flex justify-end gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setPwdTarget(null);
                  setNewMemberPwd('');
                }}
                className="cursor-pointer rounded-xl border border-stone-200 bg-white px-4 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingPwd}
                className="cursor-pointer rounded-xl bg-[#F5B800] px-5 py-2 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700] disabled:opacity-60"
              >
                {savingPwd ? 'Saving…' : 'Save Password'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
