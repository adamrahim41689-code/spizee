import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronLeft, ChevronRight, Percent, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';
import type { Product } from '../types';
import { formatBdt } from '../utils/orderMath';
import { FoodImage } from '../components/FoodImage';
import { ProductCard } from '../components/ProductCard';
import { ProductModal } from '../components/ProductModal';

type ShowcaseTab = 'featured' | 'combos' | 'popular' | 'new' | 'offers';

export const HomePage: React.FC = () => {
  const { banners, categories, products, offers, catalogLoading, catalogError, refreshCatalog } =
    useApp();
  const [slideIdx, setSlideIdx] = useState(0);
  const [activeTab, setActiveTab] = useState<ShowcaseTab>('featured');
  const [inspectProduct, setInspectProduct] = useState<Product | null>(null);
  const touchStartX = useRef<number | null>(null);

  const slides = useMemo(() => {
    if (banners.length > 0) return banners;
    return [
      {
        id: 'default-hero',
        imageUrl: '/src/assets/images/hero_spizee_feast_1795162956502.webp',
        title: 'Crispy. Juicy. Unmistakably SPIZEE.',
        subtitle:
          'Freshly cooked fried chicken, signature burgers, flame-grilled shawarma, and combo meals delivered fast.',
        offerText: 'Freshly Made to Order',
        buttonText: 'Explore Full Menu',
        buttonLink: '/menu',
        startDate: null,
        endDate: null,
        isActive: true,
        position: 0,
      },
    ];
  }, [banners]);

  useEffect(() => {
    if (slides.length <= 1) return;
    const timer = setInterval(() => {
      setSlideIdx((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  useEffect(() => {
    if (slideIdx >= slides.length) setSlideIdx(0);
  }, [slideIdx, slides.length]);

  const currentSlide = slides[slideIdx] || slides[0];

  const offerProductIds = useMemo(() => {
    const set = new Set<string>();
    for (const o of offers) {
      if (o.applicableProductIds.length === 0) {
        products.forEach((p) => set.add(p.id));
      } else {
        o.applicableProductIds.forEach((id) => set.add(id));
      }
    }
    return set;
  }, [offers, products]);

  const showcasedProducts = useMemo(() => {
    let list: Product[] = [];
    if (activeTab === 'featured') list = products.filter((p) => p.isFeatured);
    else if (activeTab === 'combos') {
      list = products.filter(
        (p) =>
          (p.categoryName || '').toLowerCase().includes('combo') ||
          p.name.toLowerCase().includes('combo') ||
          p.name.toLowerCase().includes('feast')
      );
    } else if (activeTab === 'popular') list = products.filter((p) => p.isPopular);
    else if (activeTab === 'new') list = products.filter((p) => p.isNew);
    else {
      list = products.filter(
        (p) =>
          p.discountPrice !== null ||
          p.sizes.some((s) => s.discountPrice !== null) ||
          offerProductIds.has(p.id)
      );
    }
    return list.slice(0, 6);
  }, [activeTab, products, offerProductIds]);

  const handlePrev = () => setSlideIdx((prev) => (prev - 1 + slides.length) % slides.length);
  const handleNext = () => setSlideIdx((prev) => (prev + 1) % slides.length);

  return (
    <div>
      {catalogError && (
        <div className="mx-auto mt-6 max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-800">
            <span>{catalogError}</span>
            <button
              type="button"
              onClick={refreshCatalog}
              className="rounded-lg bg-red-700 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-red-800"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* 1. Hero Promotional Slider (Compact slim strip on mobile, editorial split on desktop) */}
      <section className="mx-auto max-w-7xl px-3 pt-3 sm:px-6 sm:pt-6 lg:px-8 lg:pt-8">
        <div
          className="relative overflow-hidden rounded-2xl border border-stone-200/80 bg-[#FAF6EA] shadow-sm sm:rounded-3xl"
          onTouchStart={(e) => {
            touchStartX.current = e.touches[0].clientX;
          }}
          onTouchEnd={(e) => {
            if (touchStartX.current === null) return;
            const delta = e.changedTouches[0].clientX - touchStartX.current;
            if (delta > 45) handlePrev();
            if (delta < -45) handleNext();
            touchStartX.current = null;
          }}
        >
          <div className="grid min-h-[128px] grid-cols-12 items-stretch sm:min-h-[280px] lg:min-h-[420px]">
            {/* Editorial Copy Column */}
            <div className="relative z-10 col-span-7 flex flex-col justify-center bg-gradient-to-br from-white via-[#FFFDF5] to-[#FFF6D6] p-3 sm:p-8 lg:col-span-5 lg:p-12">
              {currentSlide.offerText && (
                <p className="truncate text-[10px] font-bold tracking-wide text-[#B47B00] sm:text-xs">
                  {currentSlide.offerText}
                </p>
              )}
              <h1 className="mt-0.5 line-clamp-2 font-display text-[15px] font-extrabold leading-tight tracking-tight text-[#1C1917] sm:mt-2 sm:line-clamp-none sm:text-3xl lg:text-[42px] lg:leading-[1.12]">
                {currentSlide.title || 'Crispy. Juicy. Unmistakably SPIZEE.'}
              </h1>
              {currentSlide.subtitle && (
                <p className="mt-4 hidden max-w-md text-sm leading-relaxed text-stone-600 sm:block sm:text-base">
                  {currentSlide.subtitle}
                </p>
              )}

              <div className="mt-2 flex flex-wrap items-center gap-1.5 sm:mt-7 sm:gap-3">
                <Link
                  to={currentSlide.buttonLink || '/menu'}
                  className="inline-flex items-center gap-1 rounded-lg bg-[#F5B800] px-2.5 py-1.5 text-[11px] font-bold text-[#1C1917] shadow-xs transition hover:bg-[#E0A700] whitespace-nowrap sm:gap-2 sm:rounded-xl sm:px-6 sm:py-3 sm:text-sm"
                >
                  {currentSlide.buttonText || 'Order Now'}
                  <ArrowRight className="h-3 w-3 sm:h-4 sm:w-4" />
                </Link>
                <Link
                  to={(currentSlide.buttonLink || '/menu') === '/menu' ? '/menu?filter=discount' : '/menu'}
                  className="hidden items-center rounded-xl border border-stone-300 bg-white px-5 py-3 text-sm font-semibold text-[#1C1917] transition hover:border-[#1C1917] whitespace-nowrap sm:inline-flex"
                >
                  {(currentSlide.buttonLink || '/menu') === '/menu' ? "Today's Offers" : 'Full Menu'}
                </Link>
              </div>

              {slides.length > 1 && (
                <div className="mt-2 flex items-center gap-2 sm:mt-8 sm:gap-3">
                  <div className="hidden items-center gap-1.5 sm:flex">
                    <button
                      type="button"
                      onClick={handlePrev}
                      aria-label="Previous promotional banner"
                      className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-stone-200 bg-white text-[#1C1917] transition hover:border-[#F5B800] hover:bg-[#FFF9E6]"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      onClick={handleNext}
                      aria-label="Next promotional banner"
                      className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-stone-200 bg-white text-[#1C1917] transition hover:border-[#F5B800] hover:bg-[#FFF9E6]"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="flex items-center gap-1 sm:gap-1.5" role="tablist" aria-label="Hero slides">
                    {slides.map((s, idx) => (
                      <button
                        key={s.id}
                        type="button"
                        role="tab"
                        aria-selected={idx === slideIdx}
                        aria-label={`Slide ${idx + 1}`}
                        onClick={() => setSlideIdx(idx)}
                        className={`h-1.5 rounded-full transition-all sm:h-2 ${
                          idx === slideIdx
                            ? 'w-4 bg-[#1C1917] sm:w-7'
                            : 'w-1.5 bg-stone-300 hover:bg-stone-400 sm:w-2'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Hero Photography Column */}
            <div className="relative col-span-5 min-h-[128px] sm:min-h-[280px] lg:col-span-7 lg:min-h-[440px]">
              <FoodImage
                src={currentSlide.imageUrl}
                alt={currentSlide.title || 'SPIZEE signature meal'}
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 2. Category Strip (3-grid on mobile, 5-grid on desktop) */}
      <section className="mx-auto mt-5 max-w-7xl px-3 sm:mt-12 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between gap-3">
          <div>
            <h2 className="font-display text-base font-bold text-[#1C1917] sm:text-2xl">
              Browse by Category
            </h2>
            <p className="mt-1 hidden text-sm text-stone-600 sm:block">
              Handcrafted fresh in our kitchen — pick your craving.
            </p>
          </div>
          <Link
            to="/menu"
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#B47B00] hover:text-[#1C1917] whitespace-nowrap sm:text-sm"
          >
            All Menu
            <ArrowRight className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
          </Link>
        </div>

        {catalogLoading ? (
          <div className="mt-3 grid grid-cols-3 gap-2 sm:mt-5 sm:gap-4 lg:grid-cols-5">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div key={n} className="h-24 animate-pulse rounded-xl bg-stone-200/70 sm:h-28 sm:rounded-2xl" />
            ))}
          </div>
        ) : categories.length === 0 ? (
          <div className="mt-4 rounded-2xl border border-stone-200 bg-white p-8 text-center text-sm text-stone-500">
            Categories will appear here as soon as items are published.
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-3 gap-2 sm:mt-5 sm:gap-4 lg:grid-cols-5">
            {categories.map((cat) => {
              const count = products.filter((p) => p.categoryId === cat.id).length;
              return (
                <Link
                  key={cat.id}
                  to={`/menu?category=${encodeURIComponent(cat.name)}`}
                  className="glass-surface group flex flex-col items-center gap-1.5 rounded-xl p-2 text-center transition hover:-translate-y-0.5 hover:border-[#F5B800] hover:shadow-md sm:flex-row sm:items-center sm:gap-3.5 sm:rounded-2xl sm:p-3 sm:text-left"
                >
                  <div className="h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-[#FAF6EA] sm:h-14 sm:w-14 sm:rounded-xl">
                    <FoodImage
                      src={cat.imageUrl}
                      alt={cat.name}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <div className="w-full min-w-0">
                    <h3 className="truncate font-display text-[11px] font-bold text-[#1C1917] sm:text-sm">
                      {cat.name}
                    </h3>
                    <p className="mt-0.5 line-clamp-1 text-[10px] text-stone-500 sm:text-xs">
                      {count} {count === 1 ? 'item' : 'items'}
                    </p>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </section>

      {/* 3. Curated Menu Collection (3-grid on mobile & desktop) */}
      <section className="mx-auto mt-6 max-w-7xl px-3 sm:mt-14 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-2.5 sm:flex-row sm:items-end sm:gap-4">
          <div>
            <h2 className="font-display text-base font-bold text-[#1C1917] sm:text-3xl">
              Fresh From the SPIZEE Kitchen
            </h2>
            <p className="mt-1 hidden text-sm text-stone-600 sm:block">
              Select your size right on any card — prices update live.
            </p>
          </div>

          <div
            role="tablist"
            aria-label="Menu collections"
            className="inline-flex max-w-full w-fit items-center gap-0.5 overflow-x-auto rounded-xl border border-stone-200/90 bg-white p-1 sm:gap-1"
          >
            {(
              [
                { id: 'featured', label: 'Featured' },
                { id: 'combos', label: 'Combo' },
                { id: 'popular', label: 'Popular' },
                { id: 'new', label: 'New' },
                { id: 'offers', label: 'Offers' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={activeTab === tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`cursor-pointer rounded-lg px-2.5 py-1.5 text-[11px] font-semibold transition whitespace-nowrap sm:px-3.5 sm:py-2 sm:text-xs ${
                  activeTab === tab.id
                    ? 'bg-[#F5B800] text-[#1C1917] shadow-xs'
                    : 'text-stone-600 hover:text-[#1C1917]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {catalogLoading ? (
          <div className="mt-3 grid grid-cols-3 gap-2 sm:mt-7 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3 lg:gap-6">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div key={n} className="h-52 animate-pulse rounded-xl bg-stone-200/70 sm:h-[380px] sm:rounded-2xl" />
            ))}
          </div>
        ) : showcasedProducts.length === 0 ? (
          <div className="mt-4 rounded-2xl border border-stone-200 bg-white px-6 py-10 text-center sm:mt-6">
            <p className="font-display text-base font-bold text-[#1C1917] sm:text-lg">
              {products.length === 0
                ? 'No menu items found'
                : activeTab === 'featured'
                  ? 'No featured items found'
                  : activeTab === 'combos'
                    ? 'No combo items found'
                    : activeTab === 'popular'
                      ? 'No popular items found'
                      : activeTab === 'new'
                        ? 'No new items found'
                        : 'No offer items found'}
            </p>
            <p className="mt-1 text-xs text-stone-500 sm:text-sm">
              {products.length === 0
                ? 'Admin can add products from the Admin Dashboard.'
                : 'No items are available in this section right now.'}
            </p>
          </div>
        ) : (
          <div className="mt-3 grid grid-cols-3 gap-2 sm:mt-7 sm:grid-cols-2 sm:gap-5 lg:grid-cols-3 lg:gap-6">
            {showcasedProducts.map((prod) => (
              <ProductCard key={prod.id} product={prod} onInspect={setInspectProduct} />
            ))}
          </div>
        )}

        <div className="mt-6 text-center sm:mt-8">
          <Link
            to="/menu"
            className="inline-flex items-center gap-2 rounded-xl border border-stone-300 bg-white px-5 py-2.5 text-xs font-semibold text-[#1C1917] transition hover:border-[#1C1917] hover:bg-stone-50 sm:px-6 sm:py-3 sm:text-sm"
          >
            Browse Complete Menu ({products.length} items)
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* 4. Active Offers Highlights */}
      {offers.length > 0 && (
        <section className="mx-auto mt-16 max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="glass-yellow rounded-3xl p-7 sm:p-10">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
              <div>
                <p className="text-xs font-bold tracking-wide text-[#9A6700]">
                  Active Deals · Automatically Applied at Checkout
                </p>
                <h2 className="mt-1 font-display text-2xl font-bold text-[#1C1917]">
                  Today&apos;s SPIZEE Offers
                </h2>
              </div>
              <Link
                to="/menu?filter=discount"
                className="inline-flex items-center gap-1.5 text-sm font-bold text-[#1C1917] hover:underline whitespace-nowrap"
              >
                Shop All Deals
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {offers.map((offer) => (
                <div
                  key={offer.id}
                  className="flex flex-col justify-between rounded-2xl border border-[#F5B800]/35 bg-white/90 p-5 shadow-xs"
                >
                  <div>
                    <div className="flex items-center justify-between gap-3">
                      <h3 className="font-display text-lg font-bold text-[#1C1917]">
                        {offer.title}
                      </h3>
                      <span className="inline-flex items-center gap-1 font-mono text-sm font-bold text-[#B47B00] tabular-nums whitespace-nowrap">
                        {offer.offerType === 'percentage' && offer.discountPercentage ? (
                          <>
                            <Percent className="h-3.5 w-3.5" />
                            {offer.discountPercentage}% OFF
                          </>
                        ) : offer.discountAmount ? (
                          <>
                            <Sparkles className="h-3.5 w-3.5" />
                            Save {formatBdt(offer.discountAmount)}
                          </>
                        ) : (
                          'Special Deal'
                        )}
                      </span>
                    </div>
                    {offer.description && (
                      <p className="mt-2 text-sm leading-relaxed text-stone-600">
                        {offer.description}
                      </p>
                    )}
                  </div>
                  <div className="mt-4 flex items-center justify-between border-t border-stone-100 pt-3 text-xs text-stone-500">
                    <span>
                      {offer.applicableProductIds.length > 0
                        ? `Applies to ${offer.applicableProductIds.length} selected items`
                        : 'Applies storewide'}
                    </span>
                    <Link
                      to="/menu?filter=discount"
                      className="font-semibold text-[#1C1917] hover:text-[#B47B00]"
                    >
                      Order now →
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      <ProductModal product={inspectProduct} onClose={() => setInspectProduct(null)} />
    </div>
  );
};
