import { resolveMediaUrl } from '../lib/api';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Camera,
  KeyRound,
  LogOut,
  Receipt,
  Save,
  User as UserIcon,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { apiFetch, uploadImageFile } from '../lib/api';
import type { OrderDetail } from '../types';
import { formatBdt, formatDhakaDateTime } from '../utils/orderMath';
import { copy } from '../i18n/en';
import { ReceiptPaper } from '../components/ReceiptPaper';

export const ProfilePage: React.FC = () => {
  const { user, authLoading, settings, logout, refreshProfile, showToast } = useApp();
  const navigate = useNavigate();

  const [tab, setTab] = useState<'profile' | 'orders' | 'receipts'>('profile');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [changingPwd, setChangingPwd] = useState(false);

  const [orders, setOrders] = useState<OrderDetail[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  const [activeReceiptOrder, setActiveReceiptOrder] = useState<OrderDetail | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login?redirect=/profile', { replace: true });
    }
  }, [authLoading, user, navigate]);

  useEffect(() => {
    if (user) {
      setFullName(user.fullName || '');
      setPhone(user.phone || '');
      setAddress(user.address || '');
      setAvatarUrl(user.avatarUrl || null);
      apiFetch<{ orders: OrderDetail[] }>('/api/orders/my')
        .then((d) => setOrders(d.orders))
        .catch(() => {})
        .finally(() => setLoadingOrders(false));
    }
  }, [user]);

  if (authLoading || !user) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-12">
        <div className="h-64 animate-pulse rounded-3xl bg-stone-200/70" />
      </div>
    );
  }

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await uploadImageFile('avatars', file);
      setAvatarUrl(url);
      await apiFetch('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ avatarUrl: url }),
      });
      await refreshProfile();
      showToast('Profile photo updated', 'success');
    } catch (err: any) {
      showToast(err.message || 'Could not upload avatar', 'error');
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await apiFetch('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ fullName, phone, address, avatarUrl }),
      });
      await refreshProfile();
      showToast('Profile saved successfully', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save profile', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      showToast('New password must be at least 6 characters', 'error');
      return;
    }
    setChangingPwd(true);
    try {
      await apiFetch('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      setCurrentPassword('');
      setNewPassword('');
      showToast('Password updated successfully', 'success');
    } catch (err: any) {
      showToast(err.message || 'Could not change password', 'error');
    } finally {
      setChangingPwd(false);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      {/* Header Banner */}
      <div className="no-print glass-surface flex flex-col justify-between gap-4 rounded-3xl p-6 sm:flex-row sm:items-center">
        <div className="flex items-center gap-4">
          <div className="relative h-16 w-16 shrink-0">
            {avatarUrl ? (
              <img
                src={resolveMediaUrl(avatarUrl)}
                alt={user.fullName || user.email}
                referrerPolicy="no-referrer"
                className="h-16 w-16 rounded-2xl object-cover border border-stone-200"
              />
            ) : (
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#FFF3C4] text-[#B47B00]">
                <UserIcon className="h-7 w-7" />
              </div>
            )}
            <label
              aria-label="Upload profile photo"
              className="absolute -bottom-1 -right-1 flex h-7 w-7 cursor-pointer items-center justify-center rounded-lg bg-[#1C1917] text-white shadow hover:bg-stone-800"
            >
              <Camera className="h-3.5 w-3.5" />
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handleAvatarChange}
                className="sr-only"
              />
            </label>
          </div>
          <div>
            <h1 className="font-display text-2xl font-extrabold text-[#1C1917]">
              {user.fullName || 'SPIZEE Customer'}
            </h1>
            <p className="text-xs text-stone-500">
              {user.email} ·{' '}
              {user.role === 'admin'
                ? 'Administrator'
                : user.role === 'manager'
                  ? 'Manager'
                  : 'Customer'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {(user.role === 'admin' || user.role === 'manager') && (
            <Link
              to="/admin"
              className="rounded-xl bg-[#F5B800] px-4 py-2 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700]"
            >
              Open Admin Dashboard
            </Link>
          )}
          <button
            type="button"
            onClick={async () => {
              await logout();
              navigate('/');
            }}
            className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50"
          >
            <LogOut className="h-3.5 w-3.5" />
            Sign Out
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="no-print mt-6 flex flex-wrap gap-2">
        {(
          [
            { id: 'profile', label: 'Edit Profile & Password' },
            { id: 'orders', label: `Order History (${orders.length})` },
            { id: 'receipts', label: 'Previous Receipts' },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`rounded-xl px-4 py-2.5 text-xs font-bold transition ${
              tab === t.id
                ? 'bg-[#1C1917] text-white'
                : 'border border-stone-200 bg-white text-stone-700 hover:border-[#F5B800]'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="no-print mt-6">
        {tab === 'profile' && (
          <div className="grid gap-6 lg:grid-cols-12">
            <form onSubmit={handleSaveProfile} className="glass-surface rounded-3xl p-6 lg:col-span-7">
              <h2 className="font-display text-lg font-bold text-[#1C1917]">Personal Information</h2>
              <div className="mt-4 space-y-4">
                <div>
                  <label htmlFor="prof-name" className="block text-xs font-semibold text-stone-700">
                    Full Name
                  </label>
                  <input
                    id="prof-name"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="prof-email" className="block text-xs font-semibold text-stone-700">
                    Email
                  </label>
                  <input
                    id="prof-email"
                    type="email"
                    disabled
                    value={user.email}
                    className="mt-1 w-full rounded-xl border border-stone-200 bg-stone-50 px-3.5 py-2.5 text-sm text-stone-500"
                  />
                </div>
                <div>
                  <label htmlFor="prof-phone" className="block text-xs font-semibold text-stone-700">
                    Mobile Number
                  </label>
                  <input
                    id="prof-phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="017XX-XXXXXX"
                    className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                  />
                </div>
                <div>
                  <label
                    htmlFor="prof-address"
                    className="block text-xs font-semibold text-stone-700"
                  >
                    Default Delivery Address
                  </label>
                  <textarea
                    id="prof-address"
                    rows={3}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="House, Road, Area, Dhaka"
                    className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 rounded-xl bg-[#F5B800] px-5 py-2.5 text-sm font-bold text-[#1C1917] hover:bg-[#E0A700] disabled:opacity-60"
                >
                  <Save className="h-4 w-4" />
                  {saving ? 'Saving…' : 'Save Changes'}
                </button>
              </div>
            </form>

            <form onSubmit={handleChangePassword} className="glass-surface h-fit rounded-3xl p-6 lg:col-span-5">
              <div className="flex items-center gap-2">
                <KeyRound className="h-4 w-4 text-[#D99B00]" />
                <h2 className="font-display text-lg font-bold text-[#1C1917]">Change Password</h2>
              </div>
              <div className="mt-4 space-y-4">
                <div>
                  <label htmlFor="cur-pwd" className="block text-xs font-semibold text-stone-700">
                    Current Password (if set)
                  </label>
                  <input
                    id="cur-pwd"
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                  />
                </div>
                <div>
                  <label htmlFor="new-pwd" className="block text-xs font-semibold text-stone-700">
                    New Password (min 6 chars)
                  </label>
                  <input
                    id="new-pwd"
                    type="password"
                    minLength={6}
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="mt-1 w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm focus:border-[#F5B800] focus:outline-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={changingPwd}
                  className="w-full rounded-xl bg-[#1C1917] py-2.5 text-sm font-semibold text-white hover:bg-stone-800 disabled:opacity-60"
                >
                  {changingPwd ? 'Updating…' : 'Update Password'}
                </button>
              </div>
            </form>
          </div>
        )}

        {tab === 'orders' && (
          <div className="space-y-4">
            {loadingOrders ? (
              <div className="h-40 animate-pulse rounded-2xl bg-stone-200/70" />
            ) : orders.length === 0 ? (
              <div className="glass-surface rounded-3xl p-12 text-center">
                <p className="font-display text-lg font-bold text-[#1C1917]">No orders yet</p>
                <p className="mt-1 text-sm text-stone-500">
                  Once you place an order, you can track its live status here.
                </p>
                <Link
                  to="/menu"
                  className="mt-5 inline-block rounded-xl bg-[#F5B800] px-5 py-2.5 text-sm font-bold text-[#1C1917]"
                >
                  Explore Menu
                </Link>
              </div>
            ) : (
              orders.map((order) => {
                const dhaka = formatDhakaDateTime(order.createdAt);
                return (
                  <div key={order.id} className="glass-surface rounded-2xl p-5">
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-200/80 pb-3">
                      <div>
                        <h3 className="font-display text-base font-bold text-[#1C1917] tabular-nums">
                          Order #{order.orderNumber}
                        </h3>
                        <p className="text-xs text-stone-500 tabular-nums">
                          {dhaka.dateStr} · {dhaka.timeStr} · {copy.orderTypes[order.orderType]}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs font-bold uppercase tracking-wide text-[#9A6700]">
                          {copy.orderStatuses[order.status] || order.status}
                        </span>
                        <span className="font-mono text-base font-bold text-[#1C1917] tabular-nums">
                          {formatBdt(order.totalAmount)}
                        </span>
                      </div>
                    </div>

                    <ul className="mt-3 space-y-1 text-sm text-stone-700">
                      {order.items.map((item) => (
                        <li key={item.id} className="flex justify-between tabular-nums">
                          <span>
                            {item.quantity}× {item.productName}
                            {item.sizeLabel ? ` (${item.sizeLabel})` : ''}
                          </span>
                          <span className="font-mono">{formatBdt(item.lineTotal)}</span>
                        </li>
                      ))}
                    </ul>

                    <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-stone-100 pt-3">
                      <span className="font-mono text-xs text-stone-500">
                        Receipt: {order.receipt?.receiptNumber || '—'}
                      </span>
                      <button
                        type="button"
                        onClick={() => setActiveReceiptOrder(order)}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-[#FFF3C4] px-3.5 py-1.5 text-xs font-bold text-[#1C1917] hover:bg-[#F5B800]"
                      >
                        <Receipt className="h-3.5 w-3.5" />
                        View / Print / PDF Receipt
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {tab === 'receipts' && (
          <div className="glass-surface overflow-x-auto rounded-3xl p-6">
            {orders.length === 0 ? (
              <p className="py-8 text-center text-sm text-stone-500">No receipts available yet.</p>
            ) : (
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-stone-200 text-xs text-stone-500">
                    <th className="pb-3 font-semibold">Receipt #</th>
                    <th className="pb-3 font-semibold">Order #</th>
                    <th className="pb-3 font-semibold">Date &amp; Time</th>
                    <th className="pb-3 font-semibold">Type</th>
                    <th className="pb-3 text-right font-semibold">Total</th>
                    <th className="pb-3 text-right font-semibold">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 tabular-nums">
                  {orders.map((o) => {
                    const dt = formatDhakaDateTime(o.receipt?.issuedAt || o.createdAt);
                    return (
                      <tr key={o.id} className="hover:bg-[#FFFDF5]">
                        <td className="py-3 font-mono text-xs font-semibold">
                          {o.receipt?.receiptNumber || `SPZ-${o.orderNumber}`}
                        </td>
                        <td className="py-3 font-mono text-xs">#{o.orderNumber}</td>
                        <td className="py-3 text-xs text-stone-600">
                          {dt.dateStr} {dt.timeStr}
                        </td>
                        <td className="py-3 text-xs">{copy.orderTypes[o.orderType]}</td>
                        <td className="py-3 text-right font-mono font-bold">
                          {formatBdt(o.totalAmount)}
                        </td>
                        <td className="py-3 text-right">
                          <button
                            type="button"
                            onClick={() => setActiveReceiptOrder(o)}
                            className="rounded-lg bg-[#F5B800] px-3 py-1.5 text-xs font-bold text-[#1C1917] hover:bg-[#E0A700]"
                          >
                            Open Receipt
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        )}
      </div>

      {/* Receipt Modal */}
      {activeReceiptOrder && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Order receipt"
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-stone-900/45 p-4 backdrop-blur-xs"
          onClick={() => setActiveReceiptOrder(null)}
        >
          <div
            className="relative max-h-[92vh] w-full max-w-md overflow-y-auto rounded-3xl bg-[#FFFDF7] p-6 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setActiveReceiptOrder(null)}
              aria-label="Close receipt modal"
              className="no-print absolute right-4 top-4 inline-flex h-8 w-8 items-center justify-center rounded-full bg-white text-stone-700 shadow hover:bg-stone-100"
            >
              <X className="h-4 w-4" />
            </button>
            <ReceiptPaper order={activeReceiptOrder} settings={settings} showActions />
          </div>
        </div>
      )}
    </div>
  );
};
