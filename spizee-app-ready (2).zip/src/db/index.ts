import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema.ts';

declare global {
  var _postgresPool: Pool | undefined;
}

export const createPool = () => {
  if (!global._postgresPool) {
    const databaseUrl = process.env.DATABASE_URL;
    // Neon / Supabase / Render Postgres need SSL. Set DATABASE_SSL=false for a local DB.
    const useSsl = process.env.DATABASE_SSL !== 'false';
    global._postgresPool = databaseUrl
      ? new Pool({
          connectionString: databaseUrl,
          ssl: useSsl ? { rejectUnauthorized: false } : false,
          max: 10,
          idleTimeoutMillis: 15000,
          connectionTimeoutMillis: 15000,
        })
      : new Pool({
          host: process.env.SQL_HOST,
          user: process.env.SQL_USER,
          password: process.env.SQL_PASSWORD,
          database: process.env.SQL_DB_NAME,
          max: 10,
          idleTimeoutMillis: 15000,
          connectionTimeoutMillis: 15000,
        });

    global._postgresPool.on('error', (err: any) => {
      const msg = String(err?.message || '');
      const code = String(err?.code || '');
      // Cloud SQL Developer Edition closes idle sockets when scaling down; pg.Pool
      // automatically removes the dead client and opens a fresh one on the next query.
      const isExpectedIdleDisconnect =
        msg.includes('Connection terminated unexpectedly') ||
        msg.includes('terminating connection') ||
        code === 'ECONNRESET' ||
        code === 'EPIPE' ||
        code === 'ETIMEDOUT' ||
        code === '57P01' ||
        code === '57P02' ||
        code === '57P03';
      if (!isExpectedIdleDisconnect) {
        console.warn('SQL pool idle client warning:', msg || code);
      }
    });
  }
  return global._postgresPool;
};

const pool = createPool();

export const db = drizzle(pool, { schema });
