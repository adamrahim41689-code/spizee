import bcrypt from 'bcryptjs';
import { and, asc, desc, eq, gte, inArray, lte, max, ne, sql } from 'drizzle-orm';
import { db } from './index.ts';
import {
  banners,
  cartItems,
  categories,
  offers,
  orderItems,
  orders,
  productSizes,
  products,
  profiles,
  receipts,
  siteSettings,
} from './schema.ts';
import {
  calculateOrderTotals,
  computeEffectivePrice,
  formatDhakaDateTime,
  generateReceiptNumber,
  isWithinSchedule,
  validateOrderInput,
  type ActiveOfferInput,
} from '../utils/orderMath.ts';

function parseProductIds(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(String) : [];
  } catch {
    return [];
  }
}

export function mapOfferRow(row: typeof offers.$inferSelect): ActiveOfferInput & {
  description: string | null;
  createdAt: Date;
} {
  return {
    id: row.id,
    title: row.title,
    description: row.description,
    offerType: row.offerType,
    discountPercentage: row.discountPercentage ? Number(row.discountPercentage) : null,
    discountAmount: row.discountAmount ? Number(row.discountAmount) : null,
    startDate: row.startDate,
    endDate: row.endDate,
    applicableProductIds: parseProductIds(row.applicableProductIds),
    isActive: row.isActive,
    createdAt: row.createdAt,
  };
}

export async function ensureSiteSettings() {
  try {
    const existing = await db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1);
    if (existing.length > 0) return existing[0];

    const [created] = await db
      .insert(siteSettings)
      .values({
        id: 1,
        restaurantName: 'SPIZEE',
        logoUrl: null,
        address: 'House 24, Road 11, Banani, Dhaka 1213, Bangladesh',
        phone: '+880 1711-009988',
        email: 'hello@spizee.com',
        openingHours: 'Daily: 11:00 AM – 11:30 PM',
        facebook: 'https://facebook.com',
        instagram: 'https://instagram.com',
        tiktok: 'https://tiktok.com',
        whatsapp: '+8801711009988',
        googleMapsUrl: 'https://maps.google.com/?q=Banani,Dhaka',
        deliveryInfo: 'Hot & crispy delivery across Dhaka within 30–45 minutes. Cash on Delivery available.',
        deliveryCharge: '0',
        shortDescription:
          'SPIZEE (স্পাইজি) serves fresh, extra-crispy fried chicken, handcrafted burgers, flame-grilled shawarma, and wood-baked pizzas made to order.',
        footerCopyright: '© 2026 SPIZEE (স্পাইজি). All rights reserved.',
        footerRightText: 'Prices in Bangladeshi Taka (৳ BDT) · Asia/Dhaka Time',
        footerTextSize: 'xs',
      })
      .onConflictDoNothing()
      .returning();

    if (created) return created;
    const [refetched] = await db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1);
    return refetched;
  } catch (error) {
    console.error('ensureSiteSettings failed:', error);
    throw new Error('Failed to load restaurant settings.', { cause: error });
  }
}

export async function ensureDefaultAdminAccount() {
  try {
    const primaryOwnerEmail = 'rigoshopbd@gmail.com';
    // Guarantee Primary Owner always keeps admin access and stays active,
    // without touching any added secondary admins or managers.
    await db
      .update(profiles)
      .set({ role: 'admin', isActive: true })
      .where(eq(profiles.email, primaryOwnerEmail));
  } catch (error) {
    console.error('ensureDefaultAdminAccount error:', error);
  }
}

export async function seedSampleCatalog(force = false) {
  try {
    const existingCats = await db.select().from(categories).limit(1);
    const existingProds = await db.select().from(products).limit(1);
    if (!force && (existingCats.length > 0 || existingProds.length > 0)) {
      return { seeded: false, message: 'Catalog already has items.' };
    }

    const catDefs = [
      {
        name: 'Burgers',
        description: 'Toasted brioche buns with crispy chicken fillets and melted cheddar',
        imageUrl: '/src/assets/images/food_crispy_burger_1795162956438.webp',
        sortOrder: 1,
      },
      {
        name: 'Fried Chicken',
        description: 'Double-dredged golden spicy fried chicken served piping hot',
        imageUrl: '/src/assets/images/food_fried_chicken_1795162955886.webp',
        sortOrder: 2,
      },
      {
        name: 'Shawarma',
        description: 'Char-grilled spiced chicken wraps with roasted garlic toum',
        imageUrl: '/src/assets/images/hero_shawarma_combo_1795162956805.webp',
        sortOrder: 3,
      },
      {
        name: 'Pizza & Fries',
        description: 'Golden crust pizzas and crispy seasoned masala fries',
        imageUrl: '/src/assets/images/food_loaded_fries_pizza_1795162957346.webp',
        sortOrder: 4,
      },
      {
        name: 'Combos',
        description: 'Value meal boxes pairing our bestsellers with fries and drinks',
        imageUrl: '/src/assets/images/hero_spizee_feast_1795162956502.webp',
        sortOrder: 5,
      },
    ];

    const insertedCats: Record<string, string> = {};
    for (const c of catDefs) {
      const [row] = await db.insert(categories).values({ ...c, isActive: true }).returning();
      insertedCats[c.name] = row.id;
    }

    const productDefs = [
      {
        category: 'Burgers',
        name: 'SPIZEE Classic Zinger Burger',
        description:
          'Extra-crispy spiced chicken thigh fillet, melted aged cheddar, crisp iceberg lettuce, and smoky house sauce on a toasted sesame brioche bun.',
        imageUrl: '/src/assets/images/food_crispy_burger_1795162956438.webp',
        basePrice: '260',
        discountPrice: '230',
        isFeatured: true,
        isPopular: true,
        isNew: false,
        sizes: [
          { label: 'Regular', price: '260', discountPrice: '230', sortOrder: 1 },
          { label: 'Double Fillet', price: '370', discountPrice: '340', sortOrder: 2 },
          { label: 'King Meal (+Fries)', price: '440', discountPrice: '399', sortOrder: 3 },
        ],
      },
      {
        category: 'Burgers',
        name: 'Fiery Naga Crunch Burger',
        description:
          'Hand-breaded chicken crunch tossed in authentic Bangladeshi Naga glaze with cooling ranch slaw and double cheese.',
        imageUrl: '/src/assets/images/food_crispy_burger_1795162956438.webp',
        basePrice: '290',
        discountPrice: null,
        isFeatured: false,
        isPopular: true,
        isNew: true,
        sizes: [
          { label: 'Regular', price: '290', discountPrice: null, sortOrder: 1 },
          { label: 'Large', price: '360', discountPrice: '330', sortOrder: 2 },
        ],
      },
      {
        category: 'Fried Chicken',
        name: 'Golden Crispy Chicken Bucket',
        description:
          'Signature 12-spice marinated chicken fried to a shatteringly crisp golden crust, served with spicy mayo dip.',
        imageUrl: '/src/assets/images/food_fried_chicken_1795162955886.webp',
        basePrice: '190',
        discountPrice: null,
        isFeatured: true,
        isPopular: true,
        isNew: false,
        sizes: [
          { label: '2 Pieces', price: '340', discountPrice: '310', sortOrder: 1 },
          { label: '4 Pieces', price: '650', discountPrice: '599', sortOrder: 2 },
          { label: '6 Pieces Bucket', price: '950', discountPrice: '880', sortOrder: 3 },
        ],
      },
      {
        category: 'Shawarma',
        name: 'Smoky Garlic Chicken Shawarma',
        description:
          'Flame-seared marinated chicken strips rolled in warm artisan pita with pickled turnips, fresh greens, and signature garlic sauce.',
        imageUrl: '/src/assets/images/hero_shawarma_combo_1795162956805.webp',
        basePrice: '220',
        discountPrice: '195',
        isFeatured: true,
        isPopular: true,
        isNew: false,
        sizes: [
          { label: 'Regular Wrap', price: '220', discountPrice: '195', sortOrder: 1 },
          { label: 'Jumbo Wrap', price: '310', discountPrice: '280', sortOrder: 2 },
          { label: 'Platter (+Wedges)', price: '390', discountPrice: null, sortOrder: 3 },
        ],
      },
      {
        category: 'Pizza & Fries',
        name: 'Tandoori Chicken & Cheese Pizza',
        description:
          'Hand-stretched golden crust layered with spiced tomato base, smoky tandoori chicken chunks, mozzarella, and fresh herbs.',
        imageUrl: '/src/assets/images/food_loaded_fries_pizza_1795162957346.webp',
        basePrice: '480',
        discountPrice: '430',
        isFeatured: true,
        isPopular: false,
        isNew: true,
        sizes: [
          { label: '8" Personal', price: '480', discountPrice: '430', sortOrder: 1 },
          { label: '12" Family', price: '820', discountPrice: '750', sortOrder: 2 },
        ],
      },
      {
        category: 'Pizza & Fries',
        name: 'Seasoned Masala Crispy Fries',
        description:
          'Thick-cut golden potatoes dusted in SPIZEE signature peri-masala spice blend with creamy garlic dip.',
        imageUrl: '/src/assets/images/food_loaded_fries_pizza_1795162957346.webp',
        basePrice: '130',
        discountPrice: null,
        isFeatured: false,
        isPopular: true,
        isNew: false,
        sizes: [
          { label: 'Regular', price: '130', discountPrice: null, sortOrder: 1 },
          { label: 'Large Share', price: '210', discountPrice: '185', sortOrder: 2 },
        ],
      },
      {
        category: 'Combos',
        name: 'SPIZEE Ultimate Feast Box',
        description:
          'One Classic Zinger Burger, 2 pieces of Crispy Fried Chicken, seasoned fries, garlic dip, and chilled sparkling drink.',
        imageUrl: '/src/assets/images/hero_spizee_feast_1795162956502.webp',
        basePrice: '690',
        discountPrice: '599',
        isFeatured: true,
        isPopular: true,
        isNew: true,
        sizes: [
          { label: 'Solo Feast', price: '690', discountPrice: '599', sortOrder: 1 },
          { label: 'Duo Feast (For 2)', price: '1290', discountPrice: '1120', sortOrder: 2 },
        ],
      },
    ];

    const createdProductIds: string[] = [];
    for (const p of productDefs) {
      const [prod] = await db
        .insert(products)
        .values({
          categoryId: insertedCats[p.category] ?? null,
          name: p.name,
          description: p.description,
          imageUrl: p.imageUrl,
          basePrice: p.basePrice,
          discountPrice: p.discountPrice,
          isAvailable: true,
          isFeatured: p.isFeatured,
          isPopular: p.isPopular,
          isNew: p.isNew,
        })
        .returning();
      createdProductIds.push(prod.id);

      for (const s of p.sizes) {
        await db.insert(productSizes).values({
          productId: prod.id,
          label: s.label,
          price: s.price,
          discountPrice: s.discountPrice,
          sortOrder: s.sortOrder,
        });
      }
    }

    const existingBanners = await db.select().from(banners).limit(1);
    if (existingBanners.length === 0) {
      await db.insert(banners).values([
        {
          imageUrl: '/src/assets/images/hero_spizee_feast_1795162956502.webp',
          title: 'Crispy. Juicy. Unmistakably SPIZEE.',
          subtitle: 'Hand-breaded spicy chicken burgers, golden buckets, and freshly seasoned fries delivered hot in Dhaka.',
          offerText: 'Feast Box from ৳599',
          buttonText: 'Explore Full Menu',
          buttonLink: '/menu',
          isActive: true,
          position: 1,
        },
        {
          imageUrl: '/src/assets/images/hero_shawarma_combo_1795162956805.webp',
          title: 'Flame-Grilled Shawarma & Crispy Wedges',
          subtitle: 'Marinated overnight in warm spices, wrapped fresh to order with house-whipped garlic dip.',
          offerText: 'Flat 10% Off Shawarma',
          buttonText: 'Order Shawarma',
          buttonLink: '/menu?category=Shawarma',
          isActive: true,
          position: 2,
        },
        {
          imageUrl: '/src/assets/images/food_loaded_fries_pizza_1795162957346.webp',
          title: 'Oven-Baked Tandoori Pizza Nights',
          subtitle: 'Golden hand-stretched dough loaded with smoky tandoori chicken and bubbling mozzarella.',
          offerText: 'Save ৳70 on Family Size',
          buttonText: 'View Pizza Deals',
          buttonLink: '/menu?category=Pizza%20%26%20Fries',
          isActive: true,
          position: 3,
        },
      ]);
    }

    const existingOffers = await db.select().from(offers).limit(1);
    if (existingOffers.length === 0) {
      await db.insert(offers).values([
        {
          title: 'Weekend Crunch 10% Off',
          description: 'Enjoy an extra 10% off our signature Zinger Burger and Golden Crispy Chicken Buckets.',
          offerType: 'percentage',
          discountPercentage: '10',
          discountAmount: null,
          applicableProductIds: JSON.stringify(createdProductIds.slice(0, 3)),
          isActive: true,
        },
        {
          title: 'Combo Feast Special — Save ৳50',
          description: 'Instant ৳50 savings on the SPIZEE Ultimate Feast Box and Tandem Pizza.',
          offerType: 'fixed',
          discountPercentage: null,
          discountAmount: '50',
          applicableProductIds: JSON.stringify(createdProductIds.slice(4)),
          isActive: true,
        },
      ]);
    }

    return { seeded: true, message: 'Sample menu added successfully.' };
  } catch (error) {
    console.error('seedSampleCatalog failed:', error);
    throw new Error('Failed to seed sample menu.', { cause: error });
  }
}

export async function getPublicCatalog() {
  try {
    const settings = await ensureSiteSettings();

    const [catRows, prodRows, sizeRows, bannerRows, offerRows] = await Promise.all([
      db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.name)),
      db.select().from(products).orderBy(desc(products.isFeatured), desc(products.createdAt)),
      db.select().from(productSizes).orderBy(asc(productSizes.sortOrder), asc(productSizes.price)),
      db.select().from(banners).orderBy(asc(banners.position), desc(banners.createdAt)),
      db.select().from(offers).orderBy(desc(offers.createdAt)),
    ]);

    const now = new Date();
    const activeOffers = offerRows
      .map(mapOfferRow)
      .filter((o) => isWithinSchedule(o.isActive, o.startDate, o.endDate, now));

    const activeBanners = bannerRows.filter((b) =>
      isWithinSchedule(b.isActive, b.startDate, b.endDate, now)
    );

    const sizesByProd = new Map<string, Array<typeof productSizes.$inferSelect>>();
    for (const s of sizeRows) {
      const list = sizesByProd.get(s.productId) ?? [];
      list.push(s);
      sizesByProd.set(s.productId, list);
    }

    const catMap = new Map(catRows.map((c) => [c.id, c]));

    const enrichedProducts = prodRows.map((p) => {
      const sizes = (sizesByProd.get(p.id) ?? []).map((s) => ({
        id: s.id,
        productId: s.productId,
        label: s.label,
        price: Number(s.price),
        discountPrice: s.discountPrice !== null ? Number(s.discountPrice) : null,
        sortOrder: s.sortOrder,
      }));
      return {
        id: p.id,
        categoryId: p.categoryId,
        categoryName: p.categoryId ? catMap.get(p.categoryId)?.name ?? 'Uncategorized' : 'Uncategorized',
        name: p.name,
        description: p.description,
        imageUrl: p.imageUrl,
        basePrice: Number(p.basePrice),
        discountPrice: p.discountPrice !== null ? Number(p.discountPrice) : null,
        isAvailable: p.isAvailable,
        isFeatured: p.isFeatured,
        isPopular: p.isPopular,
        isNew: p.isNew,
        createdAt: p.createdAt,
        sizes,
      };
    });

    return {
      settings: {
        ...settings,
        deliveryCharge: Number(settings.deliveryCharge ?? 0),
      },
      categories: catRows.filter((c) => c.isActive),
      products: enrichedProducts,
      banners: activeBanners,
      offers: activeOffers,
    };
  } catch (error) {
    console.error('getPublicCatalog failed:', error);
    throw new Error('Failed to load storefront catalog.', { cause: error });
  }
}

export async function placeOrderServerSide(params: {
  userId: string | null;
  source: 'online' | 'pos';
  orderType: 'home_delivery' | 'pickup' | 'dine_in';
  deliveryAddress?: string | null;
  customerName?: string | null;
  customerPhone?: string | null;
  paymentMethod?: string | null;
  notes?: string | null;
  extraDiscount?: number;
  items: Array<{ productId: string; sizeId?: string | null; quantity: number }>;
}) {
  const validationError = validateOrderInput({
    items: params.items,
    orderType: params.orderType,
    source: params.source,
    deliveryAddress: params.deliveryAddress,
    customerName: params.customerName,
    customerPhone: params.customerPhone,
  });
  if (validationError) {
    throw new Error(validationError);
  }

  try {
    return await db.transaction(async (tx) => {
      const siteDeliveryCharge = 0;

      const allOfferRows = await tx.select().from(offers).where(eq(offers.isActive, true));
      const activeOffers = allOfferRows.map(mapOfferRow);
      const now = new Date();

      const productIds = Array.from(new Set(params.items.map((i) => i.productId)));
      const dbProducts = await tx
        .select()
        .from(products)
        .where(inArray(products.id, productIds));
      const productMap = new Map(dbProducts.map((p) => [p.id, p]));

      const dbSizes =
        productIds.length > 0
          ? await tx
              .select()
              .from(productSizes)
              .where(inArray(productSizes.productId, productIds))
              .orderBy(asc(productSizes.sortOrder), asc(productSizes.price))
          : [];
      const sizeMap = new Map(dbSizes.map((s) => [s.id, s]));
      const sizesByProduct = new Map<string, Array<typeof productSizes.$inferSelect>>();
      for (const s of dbSizes) {
        const list = sizesByProduct.get(s.productId) ?? [];
        list.push(s);
        sizesByProduct.set(s.productId, list);
      }

      const computedLines: Array<{
        productId: string;
        productName: string;
        sizeLabel: string | null;
        unitPrice: number;
        quantity: number;
        lineTotal: number;
        effectiveUnitPrice: number;
      }> = [];

      for (const reqItem of params.items) {
        const prod = productMap.get(reqItem.productId);
        if (!prod || !prod.isAvailable) {
          throw new Error(`Product "${prod?.name || 'selected item'}" is currently unavailable.`);
        }
        const prodSizes = sizesByProduct.get(prod.id) ?? [];
        let sizeRow: typeof productSizes.$inferSelect | undefined;
        if (reqItem.sizeId) {
          const exact = sizeMap.get(reqItem.sizeId);
          if (exact && exact.productId === prod.id) {
            sizeRow = exact;
          } else {
            // Stale sizeId from cart after admin edited/removed sizes — reconcile gracefully
            sizeRow = prodSizes[0];
          }
        } else if (prodSizes.length > 0) {
          sizeRow = prodSizes[0];
        }

        const priced = computeEffectivePrice(
          {
            productId: prod.id,
            basePrice: Number(prod.basePrice),
            discountPrice: prod.discountPrice !== null ? Number(prod.discountPrice) : null,
            sizePrice: sizeRow ? Number(sizeRow.price) : null,
            sizeDiscountPrice:
              sizeRow && sizeRow.discountPrice !== null ? Number(sizeRow.discountPrice) : null,
            quantity: reqItem.quantity,
          },
          activeOffers,
          now
        );

        computedLines.push({
          productId: prod.id,
          productName: prod.name,
          sizeLabel: sizeRow ? sizeRow.label : null,
          unitPrice: priced.effectiveUnitPrice,
          effectiveUnitPrice: priced.effectiveUnitPrice,
          quantity: reqItem.quantity,
          lineTotal: priced.lineSubtotal,
        });
      }

      const totals = calculateOrderTotals({
        lines: computedLines,
        orderType: params.orderType,
        source: params.source,
        siteDeliveryCharge,
        extraDiscount: params.source === 'pos' ? params.extraDiscount ?? 0 : 0,
      });

      const [{ maxOrderNum }] = await tx
        .select({ maxOrderNum: max(orders.orderNumber) })
        .from(orders);
      const nextOrderNumber = Math.max(1001, Number(maxOrderNum ?? 1000) + 1);

      const cleanAddress =
        params.source === 'pos' || params.orderType !== 'home_delivery'
          ? null
          : params.deliveryAddress?.trim() || null;

      const [createdOrder] = await tx
        .insert(orders)
        .values({
          orderNumber: nextOrderNumber,
          userId: params.source === 'pos' ? null : params.userId,
          source: params.source,
          customerName: params.customerName?.trim() || (params.source === 'pos' ? 'Walk-in Guest' : null),
          customerPhone: params.customerPhone?.trim() || null,
          orderType: params.orderType,
          deliveryAddress: cleanAddress,
          subtotal: totals.subtotal.toFixed(2),
          discount: totals.discount.toFixed(2),
          deliveryCharge: totals.deliveryCharge.toFixed(2),
          totalAmount: totals.totalAmount.toFixed(2),
          paymentMethod: params.paymentMethod || 'cash',
          status: 'confirmed',
          notes: params.notes?.trim() || null,
        })
        .returning();

      const insertedItems = await tx
        .insert(orderItems)
        .values(
          computedLines.map((l) => ({
            orderId: createdOrder.id,
            productId: l.productId,
            productName: l.productName,
            sizeLabel: l.sizeLabel,
            unitPrice: l.unitPrice.toFixed(2),
            quantity: l.quantity,
            lineTotal: l.lineTotal.toFixed(2),
          }))
        )
        .returning();

      const receiptNumber = generateReceiptNumber(nextOrderNumber, now);
      const [createdReceipt] = await tx
        .insert(receipts)
        .values({
          orderId: createdOrder.id,
          receiptNumber,
        })
        .returning();

      if (params.source === 'online' && params.userId) {
        await tx.delete(cartItems).where(eq(cartItems.userId, params.userId));
      }

      return {
        ...createdOrder,
        subtotal: Number(createdOrder.subtotal),
        discount: Number(createdOrder.discount),
        deliveryCharge: Number(createdOrder.deliveryCharge),
        totalAmount: Number(createdOrder.totalAmount),
        items: insertedItems.map((it) => ({
          ...it,
          unitPrice: Number(it.unitPrice),
          lineTotal: Number(it.lineTotal),
        })),
        receipt: createdReceipt,
      };
    });
  } catch (error: any) {
    console.error('placeOrderServerSide failed:', error);
    if (error instanceof Error && error.message) {
      throw error;
    }
    throw new Error('Could not place order. Please try again.', { cause: error });
  }
}

export async function getOrderWithDetails(orderId: string) {
  try {
    const orderRows = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    if (orderRows.length === 0) return null;
    const order = orderRows[0];

    const [items, receiptRows] = await Promise.all([
      db.select().from(orderItems).where(eq(orderItems.orderId, order.id)),
      db.select().from(receipts).where(eq(receipts.orderId, order.id)).limit(1),
    ]);

    return {
      ...order,
      subtotal: Number(order.subtotal),
      discount: Number(order.discount),
      deliveryCharge: Number(order.deliveryCharge),
      totalAmount: Number(order.totalAmount),
      items: items.map((it) => ({
        ...it,
        unitPrice: Number(it.unitPrice),
        lineTotal: Number(it.lineTotal),
      })),
      receipt: receiptRows[0] ?? null,
    };
  } catch (error) {
    console.error('getOrderWithDetails failed:', error);
    throw new Error('Failed to load order details.', { cause: error });
  }
}

export async function listOrdersWithDetails(filters?: {
  userId?: string;
  status?: string;
  orderType?: string;
  source?: string;
  search?: string;
  dateFrom?: string;
  dateTo?: string;
}) {
  try {
    const conditions = [];
    if (filters?.userId) conditions.push(eq(orders.userId, filters.userId));
    if (filters?.status && filters.status !== 'all') conditions.push(eq(orders.status, filters.status));
    if (filters?.orderType && filters.orderType !== 'all') {
      conditions.push(eq(orders.orderType, filters.orderType));
    }
    if (filters?.source && filters.source !== 'all') conditions.push(eq(orders.source, filters.source));
    if (filters?.dateFrom) conditions.push(gte(orders.createdAt, new Date(filters.dateFrom)));
    if (filters?.dateTo) {
      const end = new Date(filters.dateTo);
      end.setHours(23, 59, 59, 999);
      conditions.push(lte(orders.createdAt, end));
    }

    const orderRows = await db
      .select()
      .from(orders)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(orders.createdAt))
      .limit(200);

    if (orderRows.length === 0) return [];

    const orderIds = orderRows.map((o) => o.id);
    const [allItems, allReceipts] = await Promise.all([
      db.select().from(orderItems).where(inArray(orderItems.orderId, orderIds)),
      db.select().from(receipts).where(inArray(receipts.orderId, orderIds)),
    ]);

    const itemsByOrder = new Map<string, Array<typeof orderItems.$inferSelect>>();
    for (const item of allItems) {
      const arr = itemsByOrder.get(item.orderId) ?? [];
      arr.push(item);
      itemsByOrder.set(item.orderId, arr);
    }
    const receiptByOrder = new Map(allReceipts.map((r) => [r.orderId, r]));

    let result = orderRows.map((o) => ({
      ...o,
      subtotal: Number(o.subtotal),
      discount: Number(o.discount),
      deliveryCharge: Number(o.deliveryCharge),
      totalAmount: Number(o.totalAmount),
      items: (itemsByOrder.get(o.id) ?? []).map((it) => ({
        ...it,
        unitPrice: Number(it.unitPrice),
        lineTotal: Number(it.lineTotal),
      })),
      receipt: receiptByOrder.get(o.id) ?? null,
    }));

    if (filters?.search && filters.search.trim()) {
      const q = filters.search.trim().toLowerCase();
      result = result.filter(
        (o) =>
          String(o.orderNumber).includes(q) ||
          (o.customerName || '').toLowerCase().includes(q) ||
          (o.customerPhone || '').toLowerCase().includes(q) ||
          (o.receipt?.receiptNumber || '').toLowerCase().includes(q) ||
          o.items.some((i) => i.productName.toLowerCase().includes(q))
      );
    }

    return result;
  } catch (error) {
    console.error('listOrdersWithDetails failed:', error);
    throw new Error('Failed to load orders.', { cause: error });
  }
}

export async function getAdminDashboardStats() {
  try {
    const [allProducts, allOrders, allItems, allCustomers] = await Promise.all([
      db.select().from(products),
      db.select().from(orders).orderBy(desc(orders.createdAt)),
      db.select().from(orderItems),
      db.select().from(profiles).where(eq(profiles.role, 'customer')),
    ]);

    const todayDhaka = formatDhakaDateTime(new Date()).isoDate;
    const validOrders = allOrders.filter((o) => o.status !== 'cancelled');
    const cancelledIds = new Set(allOrders.filter((o) => o.status === 'cancelled').map((o) => o.id));

    let totalRevenue = 0;
    let todayRevenue = 0;
    let todayOrders = 0;
    let pendingOrders = 0;
    let completedOrders = 0;

    const statusCounts: Record<string, number> = {
      pending: 0,
      confirmed: 0,
      preparing: 0,
      ready: 0,
      completed: 0,
      cancelled: 0,
    };

    const dailyMap = new Map<string, { date: string; sales: number; orders: number }>();
    const monthlyMap = new Map<string, { month: string; sales: number; orders: number }>();

    for (const o of allOrders) {
      statusCounts[o.status] = (statusCounts[o.status] ?? 0) + 1;
      if (o.status === 'pending') pendingOrders++;
      if (o.status === 'completed') completedOrders++;

      const dhaka = formatDhakaDateTime(o.createdAt);
      if (dhaka.isoDate === todayDhaka) {
        todayOrders++;
      }

      if (o.status !== 'cancelled') {
        const amt = Number(o.totalAmount);
        totalRevenue += amt;
        if (dhaka.isoDate === todayDhaka) {
          todayRevenue += amt;
        }

        const dEntry = dailyMap.get(dhaka.isoDate) ?? { date: dhaka.isoDate, sales: 0, orders: 0 };
        dEntry.sales = Math.round((dEntry.sales + amt) * 100) / 100;
        dEntry.orders += 1;
        dailyMap.set(dhaka.isoDate, dEntry);

        const monthKey = dhaka.isoDate.slice(0, 7);
        const mEntry = monthlyMap.get(monthKey) ?? { month: monthKey, sales: 0, orders: 0 };
        mEntry.sales = Math.round((mEntry.sales + amt) * 100) / 100;
        mEntry.orders += 1;
        monthlyMap.set(monthKey, mEntry);
      }
    }

    const popularMap = new Map<string, { name: string; quantity: number; revenue: number }>();
    for (const it of allItems) {
      if (cancelledIds.has(it.orderId)) continue;
      const prev = popularMap.get(it.productName) ?? { name: it.productName, quantity: 0, revenue: 0 };
      prev.quantity += it.quantity;
      prev.revenue = Math.round((prev.revenue + Number(it.lineTotal)) * 100) / 100;
      popularMap.set(it.productName, prev);
    }

    const dailySales = Array.from(dailyMap.values())
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-14);

    const monthlySales = Array.from(monthlyMap.values())
      .sort((a, b) => a.month.localeCompare(b.month))
      .slice(-6);

    const popularProducts = Array.from(popularMap.values())
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 6);

    const orderStats = Object.entries(statusCounts).map(([status, count]) => ({
      status,
      count,
    }));

    return {
      kpis: {
        totalProducts: allProducts.length,
        totalOrders: allOrders.length,
        todayOrders,
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        todayRevenue: Math.round(todayRevenue * 100) / 100,
        pendingOrders,
        completedOrders,
        totalCustomers: allCustomers.length,
      },
      dailySales,
      monthlySales,
      orderStats,
      popularProducts,
    };
  } catch (error) {
    console.error('getAdminDashboardStats failed:', error);
    throw new Error('Failed to calculate dashboard statistics.', { cause: error });
  }
}

export async function getCustomersWithStats() {
  try {
    const customerRows = await db
      .select()
      .from(profiles)
      .orderBy(desc(profiles.createdAt));

    const orderRows = await db.select().from(orders);

    const statsByUser = new Map<string, { totalOrders: number; totalSpent: number }>();
    for (const o of orderRows) {
      if (!o.userId) continue;
      const prev = statsByUser.get(o.userId) ?? { totalOrders: 0, totalSpent: 0 };
      prev.totalOrders += 1;
      if (o.status !== 'cancelled') {
        prev.totalSpent = Math.round((prev.totalSpent + Number(o.totalAmount)) * 100) / 100;
      }
      statsByUser.set(o.userId, prev);
    }

    return customerRows.map((c) => ({
      id: c.id,
      fullName: c.fullName,
      email: c.email,
      phone: c.phone,
      address: c.address,
      avatarUrl: c.avatarUrl,
      role: c.role,
      isActive: c.isActive,
      createdAt: c.createdAt,
      totalOrders: statsByUser.get(c.id)?.totalOrders ?? 0,
      totalSpent: statsByUser.get(c.id)?.totalSpent ?? 0,
    }));
  } catch (error) {
    console.error('getCustomersWithStats failed:', error);
    throw new Error('Failed to load customers.', { cause: error });
  }
}

export async function getUserCart(userId: string) {
  try {
    return await db
      .select()
      .from(cartItems)
      .where(eq(cartItems.userId, userId));
  } catch (error) {
    console.error('getUserCart failed:', error);
    throw new Error('Failed to load cart.', { cause: error });
  }
}

export async function replaceUserCart(
  userId: string,
  entries: Array<{ productId: string; sizeId: string | null; quantity: number }>
) {
  try {
    return await db.transaction(async (tx) => {
      await tx.delete(cartItems).where(eq(cartItems.userId, userId));
      const valid = entries.filter((e) => e.productId && e.quantity > 0);
      if (valid.length === 0) return [];
      const inserted = await tx
        .insert(cartItems)
        .values(
          valid.map((e) => ({
            userId,
            productId: e.productId,
            sizeId: e.sizeId || null,
            quantity: Math.min(50, Math.max(1, Math.floor(e.quantity))),
          }))
        )
        .returning();
      return inserted;
    });
  } catch (error) {
    console.error('replaceUserCart failed:', error);
    throw new Error('Failed to sync cart.', { cause: error });
  }
}

export async function getAdminCatalogAll() {
  try {
    const [catRows, prodRows, sizeRows, bannerRows, offerRows, settings] = await Promise.all([
      db.select().from(categories).orderBy(asc(categories.sortOrder), asc(categories.name)),
      db.select().from(products).orderBy(desc(products.createdAt)),
      db.select().from(productSizes).orderBy(asc(productSizes.sortOrder), asc(productSizes.price)),
      db.select().from(banners).orderBy(asc(banners.position), desc(banners.createdAt)),
      db.select().from(offers).orderBy(desc(offers.createdAt)),
      ensureSiteSettings(),
    ]);

    const sizesByProd = new Map<string, Array<typeof productSizes.$inferSelect>>();
    for (const s of sizeRows) {
      const arr = sizesByProd.get(s.productId) ?? [];
      arr.push(s);
      sizesByProd.set(s.productId, arr);
    }

    return {
      categories: catRows,
      products: prodRows.map((p) => ({
        ...p,
        basePrice: Number(p.basePrice),
        discountPrice: p.discountPrice !== null ? Number(p.discountPrice) : null,
        sizes: (sizesByProd.get(p.id) ?? []).map((s) => ({
          ...s,
          price: Number(s.price),
          discountPrice: s.discountPrice !== null ? Number(s.discountPrice) : null,
        })),
      })),
      sizes: sizeRows.map((s) => ({
        ...s,
        price: Number(s.price),
        discountPrice: s.discountPrice !== null ? Number(s.discountPrice) : null,
      })),
      banners: bannerRows,
      offers: offerRows.map(mapOfferRow),
      settings: {
        ...settings,
        deliveryCharge: Number(settings.deliveryCharge ?? 0),
      },
    };
  } catch (error) {
    console.error('getAdminCatalogAll failed:', error);
    throw new Error('Failed to load admin catalog.', { cause: error });
  }
}
