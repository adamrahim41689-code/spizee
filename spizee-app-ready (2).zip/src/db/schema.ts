import { relations } from 'drizzle-orm';
import {
  boolean,
  index,
  integer,
  numeric,
  pgTable,
  text,
  timestamp,
  uuid,
} from 'drizzle-orm/pg-core';

export const profiles = pgTable('profiles', {
  id: uuid('id').defaultRandom().primaryKey(),
  firebaseUid: text('firebase_uid').unique(),
  fullName: text('full_name'),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash'),
  phone: text('phone'),
  address: text('address'),
  avatarUrl: text('avatar_url'),
  role: text('role').notNull().default('customer'), // 'customer' | 'admin'
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const categories = pgTable('categories', {
  id: uuid('id').defaultRandom().primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  imageUrl: text('image_url'),
  isActive: boolean('is_active').notNull().default(true),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const products = pgTable('products', {
  id: uuid('id').defaultRandom().primaryKey(),
  categoryId: uuid('category_id').references(() => categories.id, { onDelete: 'set null' }),
  name: text('name').notNull(),
  description: text('description'),
  imageUrl: text('image_url'),
  basePrice: numeric('base_price', { precision: 10, scale: 2 }).notNull().default('0'),
  discountPrice: numeric('discount_price', { precision: 10, scale: 2 }),
  isAvailable: boolean('is_available').notNull().default(true),
  isFeatured: boolean('is_featured').notNull().default(false),
  isPopular: boolean('is_popular').notNull().default(false),
  isNew: boolean('is_new').notNull().default(false),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const productSizes = pgTable('product_sizes', {
  id: uuid('id').defaultRandom().primaryKey(),
  productId: uuid('product_id')
    .notNull()
    .references(() => products.id, { onDelete: 'cascade' }),
  label: text('label').notNull(),
  price: numeric('price', { precision: 10, scale: 2 }).notNull(),
  discountPrice: numeric('discount_price', { precision: 10, scale: 2 }),
  sortOrder: integer('sort_order').notNull().default(0),
}, (t) => [index('product_sizes_product_id_idx').on(t.productId)]);

export const orders = pgTable('orders', {
  id: uuid('id').defaultRandom().primaryKey(),
  orderNumber: integer('order_number').notNull().unique(),
  userId: uuid('user_id').references(() => profiles.id, { onDelete: 'set null' }),
  source: text('source').notNull().default('online'), // 'online' | 'pos'
  customerName: text('customer_name'),
  customerPhone: text('customer_phone'),
  orderType: text('order_type').notNull(), // 'home_delivery' | 'pickup' | 'dine_in'
  deliveryAddress: text('delivery_address'),
  subtotal: numeric('subtotal', { precision: 10, scale: 2 }).notNull().default('0'),
  discount: numeric('discount', { precision: 10, scale: 2 }).notNull().default('0'),
  deliveryCharge: numeric('delivery_charge', { precision: 10, scale: 2 }).notNull().default('0'),
  totalAmount: numeric('total_amount', { precision: 10, scale: 2 }).notNull().default('0'),
  paymentMethod: text('payment_method').notNull().default('cash'),
  status: text('status').notNull().default('pending'), // 'pending'|'confirmed'|'preparing'|'ready'|'completed'|'cancelled'
  notes: text('notes'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index('orders_user_id_idx').on(t.userId),
  index('orders_created_at_idx').on(t.createdAt),
  index('orders_status_idx').on(t.status),
]);

export const orderItems = pgTable('order_items', {
  id: uuid('id').defaultRandom().primaryKey(),
  orderId: uuid('order_id')
    .notNull()
    .references(() => orders.id, { onDelete: 'cascade' }),
  productId: uuid('product_id').references(() => products.id, { onDelete: 'set null' }),
  productName: text('product_name').notNull(),
  sizeLabel: text('size_label'),
  unitPrice: numeric('unit_price', { precision: 10, scale: 2 }).notNull(),
  quantity: integer('quantity').notNull(),
  lineTotal: numeric('line_total', { precision: 10, scale: 2 }).notNull(),
}, (t) => [index('order_items_order_id_idx').on(t.orderId)]);

export const receipts = pgTable('receipts', {
  id: uuid('id').defaultRandom().primaryKey(),
  orderId: uuid('order_id')
    .notNull()
    .unique()
    .references(() => orders.id, { onDelete: 'cascade' }),
  receiptNumber: text('receipt_number').notNull().unique(),
  issuedAt: timestamp('issued_at', { withTimezone: true }).notNull().defaultNow(),
});

export const cartItems = pgTable('cart_items', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id')
    .notNull()
    .references(() => profiles.id, { onDelete: 'cascade' }),
  productId: uuid('product_id')
    .notNull()
    .references(() => products.id, { onDelete: 'cascade' }),
  sizeId: uuid('size_id').references(() => productSizes.id, { onDelete: 'set null' }),
  quantity: integer('quantity').notNull().default(1),
}, (t) => [index('cart_items_user_id_idx').on(t.userId)]);

export const banners = pgTable('banners', {
  id: uuid('id').defaultRandom().primaryKey(),
  imageUrl: text('image_url'),
  title: text('title'),
  subtitle: text('subtitle'),
  offerText: text('offer_text'),
  buttonText: text('button_text'),
  buttonLink: text('button_link'),
  startDate: timestamp('start_date', { withTimezone: true }),
  endDate: timestamp('end_date', { withTimezone: true }),
  isActive: boolean('is_active').notNull().default(true),
  position: integer('position').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const offers = pgTable('offers', {
  id: uuid('id').defaultRandom().primaryKey(),
  title: text('title').notNull(),
  description: text('description'),
  offerType: text('offer_type').notNull(), // 'percentage'|'fixed'|'combo'|'special_price'|'limited_time'
  discountPercentage: numeric('discount_percentage', { precision: 5, scale: 2 }),
  discountAmount: numeric('discount_amount', { precision: 10, scale: 2 }),
  startDate: timestamp('start_date', { withTimezone: true }),
  endDate: timestamp('end_date', { withTimezone: true }),
  applicableProductIds: text('applicable_product_ids').notNull().default('[]'),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

export const siteSettings = pgTable('site_settings', {
  id: integer('id').primaryKey().default(1),
  restaurantName: text('restaurant_name').notNull().default('SPIZEE'),
  logoUrl: text('logo_url'),
  address: text('address'),
  phone: text('phone'),
  email: text('email'),
  openingHours: text('opening_hours'),
  facebook: text('facebook'),
  instagram: text('instagram'),
  tiktok: text('tiktok'),
  whatsapp: text('whatsapp'),
  googleMapsUrl: text('google_maps_url'),
  deliveryInfo: text('delivery_info'),
  deliveryCharge: numeric('delivery_charge', { precision: 10, scale: 2 }).notNull().default('0'),
  shortDescription: text('short_description'),
  footerCopyright: text('footer_copyright'),
  footerRightText: text('footer_right_text'),
  footerTextSize: text('footer_text_size').notNull().default('xs'),
});

export const uploadedMedia = pgTable('uploaded_media', {
  id: uuid('id').defaultRandom().primaryKey(),
  storagePath: text('storage_path').notNull().unique(),
  bucket: text('bucket').notNull(),
  mimeType: text('mime_type').notNull(),
  sizeBytes: integer('size_bytes').notNull(),
  dataBase64: text('data_base64').notNull(),
  uploadedBy: uuid('uploaded_by').references(() => profiles.id, { onDelete: 'set null' }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

// Relations
export const categoriesRelations = relations(categories, ({ many }) => ({
  products: many(products),
}));

export const productsRelations = relations(products, ({ one, many }) => ({
  category: one(categories, {
    fields: [products.categoryId],
    references: [categories.id],
  }),
  sizes: many(productSizes),
}));

export const productSizesRelations = relations(productSizes, ({ one }) => ({
  product: one(products, {
    fields: [productSizes.productId],
    references: [products.id],
  }),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  user: one(profiles, {
    fields: [orders.userId],
    references: [profiles.id],
  }),
  items: many(orderItems),
  receipt: one(receipts, {
    fields: [orders.id],
    references: [receipts.orderId],
  }),
}));

export const orderItemsRelations = relations(orderItems, ({ one }) => ({
  order: one(orders, {
    fields: [orderItems.orderId],
    references: [orders.id],
  }),
  product: one(products, {
    fields: [orderItems.productId],
    references: [products.id],
  }),
}));

export const receiptsRelations = relations(receipts, ({ one }) => ({
  order: one(orders, {
    fields: [receipts.orderId],
    references: [orders.id],
  }),
}));

export const cartItemsRelations = relations(cartItems, ({ one }) => ({
  user: one(profiles, {
    fields: [cartItems.userId],
    references: [profiles.id],
  }),
  product: one(products, {
    fields: [cartItems.productId],
    references: [products.id],
  }),
  size: one(productSizes, {
    fields: [cartItems.sizeId],
    references: [productSizes.id],
  }),
}));
