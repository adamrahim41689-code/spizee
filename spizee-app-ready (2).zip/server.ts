import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import compression from 'compression';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import { asc, desc, eq } from 'drizzle-orm';
import { db } from './src/db/index.ts';
import {
  banners,
  categories,
  offers,
  orders,
  productSizes,
  products,
  profiles,
  receipts,
  siteSettings,
  uploadedMedia,
} from './src/db/schema.ts';
import {
  ensureDefaultAdminAccount,
  ensureSiteSettings,
  getAdminCatalogAll,
  getAdminDashboardStats,
  getCustomersWithStats,
  getOrderWithDetails,
  getPublicCatalog,
  getUserCart,
  listOrdersWithDetails,
  mapOfferRow,
  placeOrderServerSide,
  replaceUserCart,
  seedSampleCatalog,
} from './src/db/repository.ts';
import {
  createSessionToken,
  hasAdminAccess,
  isSoleAdminEmail,
  normalizeRole,
  optionalAuth,
  requireAdmin,
  requireAuth,
  type AuthRequest,
} from './src/middleware/auth.ts';
import { mergeCartEntries } from './src/utils/orderMath.ts';
import {
  buildMediaStoragePath,
  computeMediaEtag,
  isAllowedUploadBucket,
  normalizeUploadRequestPath,
  resolveImageExtension,
} from './src/utils/mediaStorage.ts';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

if (isProduction && !process.env.SESSION_SECRET) {
  console.error('FATAL: SESSION_SECRET must be set in production.');
  process.exit(1);
}

// Gzip/brotli-friendly compression for JSON + static assets (faster on mobile data)
app.use(compression());

// CORS so the Android app (Capacitor WebView) can call this API from another origin
const allowedOrigins = new Set([
  'https://localhost',
  'http://localhost',
  'capacitor://localhost',
  ...(process.env.CORS_ORIGINS || '')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean),
]);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && (allowedOrigins.has(origin) || /^http:\/\/localhost:\d+$/.test(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Max-Age', '86400');
  }
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
});

app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));

// Legacy local uploads directory (read-only fallback for pre-existing local files)
const uploadsRoot = path.resolve(process.cwd(), 'public', 'uploads');

// Bounded in-memory cache for DB-backed uploaded images (speeds up repeat loads; Cloud SQL is the permanent source of truth)
interface CachedMediaEntry {
  mimeType: string;
  buffer: Buffer;
  etag: string;
}
const MAX_MEDIA_CACHE_ENTRIES = 60;
const MAX_MEDIA_CACHE_BYTES = 25 * 1024 * 1024;
const mediaCache = new Map<string, CachedMediaEntry>();
let mediaCacheBytes = 0;

function getCachedMedia(storagePath: string): CachedMediaEntry | null {
  const hit = mediaCache.get(storagePath);
  if (!hit) return null;
  // Refresh LRU order
  mediaCache.delete(storagePath);
  mediaCache.set(storagePath, hit);
  return hit;
}

function setCachedMedia(storagePath: string, entry: CachedMediaEntry) {
  if (entry.buffer.length > 5 * 1024 * 1024) return;
  const existing = mediaCache.get(storagePath);
  if (existing) {
    mediaCacheBytes -= existing.buffer.length;
    mediaCache.delete(storagePath);
  }
  while (
    mediaCache.size >= MAX_MEDIA_CACHE_ENTRIES ||
    mediaCacheBytes + entry.buffer.length > MAX_MEDIA_CACHE_BYTES
  ) {
    const oldestKey = mediaCache.keys().next().value;
    if (!oldestKey) break;
    const oldest = mediaCache.get(oldestKey);
    if (oldest) mediaCacheBytes -= oldest.buffer.length;
    mediaCache.delete(oldestKey);
  }
  mediaCache.set(storagePath, entry);
  mediaCacheBytes += entry.buffer.length;
}

// Serve uploaded images persistently from Cloud SQL PostgreSQL (never lost on Cloud Run restarts)
app.get('/uploads/*', async (req, res) => {
  try {
    const rawSubPath = req.path.replace(/^\/uploads\/?/, '');
    const storagePath = normalizeUploadRequestPath(rawSubPath);
    if (!storagePath) {
      return res.status(404).json({ error: 'Image not found.' });
    }

    let entry = getCachedMedia(storagePath);
    if (!entry) {
      const [row] = await db
        .select({
          mimeType: uploadedMedia.mimeType,
          sizeBytes: uploadedMedia.sizeBytes,
          dataBase64: uploadedMedia.dataBase64,
        })
        .from(uploadedMedia)
        .where(eq(uploadedMedia.storagePath, storagePath))
        .limit(1);

      if (row) {
        const buffer = Buffer.from(row.dataBase64, 'base64');
        entry = {
          mimeType: row.mimeType,
          buffer,
          etag: computeMediaEtag(storagePath, row.sizeBytes || buffer.length),
        };
        setCachedMedia(storagePath, entry);
      }
    }

    if (entry) {
      res.setHeader('Content-Type', entry.mimeType);
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('ETag', entry.etag);
      if (req.headers['if-none-match'] === entry.etag) {
        return res.status(304).end();
      }
      res.setHeader('Content-Length', String(entry.buffer.length));
      return res.send(entry.buffer);
    }

    // Optional fallback for any legacy file still sitting in local public/uploads
    const localFile = path.resolve(uploadsRoot, storagePath);
    if (localFile.startsWith(uploadsRoot + path.sep) && fs.existsSync(localFile)) {
      return res.sendFile(localFile);
    }

    return res.status(404).json({ error: 'Image not found.' });
  } catch (error) {
    console.error('Serve uploaded media error:', error);
    return res.status(500).json({ error: 'Failed to load image.' });
  }
});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!resolveImageExtension(file.mimetype)) {
      return cb(new Error('Only JPG, PNG, WebP, and GIF images are allowed.'));
    }
    cb(null, true);
  },
});

let catalogInitialized = false;
async function ensureInitialCatalogOnce() {
  if (catalogInitialized) return;
  catalogInitialized = true;
  try {
    await ensureSiteSettings();
    await ensureDefaultAdminAccount();
    await seedSampleCatalog(false);
  } catch (err) {
    catalogInitialized = false;
    console.error('Initial catalog setup error:', err);
  }
}

function sanitizeProfile(p: typeof profiles.$inferSelect | AuthRequest['profile']) {
  if (!p) return null;
  return {
    id: p.id,
    fullName: p.fullName,
    email: p.email,
    phone: p.phone,
    address: p.address,
    avatarUrl: p.avatarUrl,
    role: normalizeRole(p.email, p.role),
    isActive: p.isActive,
    createdAt: p.createdAt,
  };
}

// ==================== PUBLIC CATALOG ====================
// Short in-memory cache: menu/banners/offers rarely change, so skip the DB for repeat visits.
// Any admin write (POST/PUT/PATCH/DELETE under /api/admin) clears it immediately.
let catalogCache: { at: number; data: unknown } | null = null;
const CATALOG_TTL_MS = 30_000;
app.use('/api/admin', (req, _res, next) => {
  if (req.method !== 'GET') catalogCache = null;
  next();
});

app.get('/api/public/bootstrap', async (_req, res) => {
  try {
    if (catalogCache && Date.now() - catalogCache.at < CATALOG_TTL_MS) {
      return res.json(catalogCache.data);
    }
    await ensureInitialCatalogOnce();
    const data = await getPublicCatalog();
    catalogCache = { at: Date.now(), data };
    res.json(data);
  } catch (error: any) {
    console.error('Bootstrap error:', error);
    res.status(500).json({ error: error.message || 'Failed to load store data.' });
  }
});

// ==================== AUTH ROUTES ====================
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { fullName, email, phone, password, address } = req.body ?? {};
    const cleanEmail = String(email || '').trim().toLowerCase();
    const cleanName = String(fullName || '').trim();
    const cleanPassword = String(password || '');

    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' });
    }
    if (cleanName.length < 2) {
      return res.status(400).json({ error: 'Full name must be at least 2 characters.' });
    }
    if (cleanPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const existing = await db
      .select()
      .from(profiles)
      .where(eq(profiles.email, cleanEmail))
      .limit(1);

    if (existing.length > 0) {
      const existingRow = existing[0];
      // Allow a pre-invited Admin/Manager (no password & no Google link yet) to claim their account
      if (!existingRow.passwordHash && !existingRow.firebaseUid) {
        const passwordHash = await bcrypt.hash(cleanPassword, 10);
        const [activated] = await db
          .update(profiles)
          .set({
            fullName: cleanName || existingRow.fullName,
            phone: phone ? String(phone).trim() : existingRow.phone,
            address: address ? String(address).trim() : existingRow.address,
            passwordHash,
            isActive: true,
          })
          .where(eq(profiles.id, existingRow.id))
          .returning();
        const token = createSessionToken(activated.id, activated.email);
        return res.status(201).json({ token, profile: sanitizeProfile(activated) });
      }
      return res.status(409).json({ error: 'An account with this email already exists. Please sign in.' });
    }

    const passwordHash = await bcrypt.hash(cleanPassword, 10);
    // All public signups default to customer (unless primary owner email)
    const [created] = await db
      .insert(profiles)
      .values({
        email: cleanEmail,
        fullName: cleanName,
        phone: phone ? String(phone).trim() : null,
        address: address ? String(address).trim() : null,
        passwordHash,
        role: isSoleAdminEmail(cleanEmail) ? 'admin' : 'customer',
        isActive: true,
      })
      .returning();

    const token = createSessionToken(created.id, created.email);
    res.status(201).json({ token, profile: sanitizeProfile(created) });
  } catch (error: any) {
    console.error('Signup error:', error);
    res.status(500).json({ error: 'Failed to create account. Please try again.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    await ensureDefaultAdminAccount();
    const { email, password } = req.body ?? {};
    const cleanEmail = String(email || '').trim().toLowerCase();
    const cleanPassword = String(password || '');

    if (!cleanEmail || !cleanPassword) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const rows = await db
      .select()
      .from(profiles)
      .where(eq(profiles.email, cleanEmail))
      .limit(1);

    const user = rows[0];
    if (!user) {
      return res.status(401).json({ error: 'No account found with this email address.' });
    }
    if (!user.passwordHash) {
      if (user.firebaseUid) {
        return res.status(401).json({
          error:
            'This account was created with Google Sign-In and has no password set yet. Click "Continue with Google" below, or set a password from Profile / Admin Panel.',
        });
      }
      return res.status(401).json({
        error:
          'This account was invited without a password. Click "Continue with Google" below, or switch to "Create Account" to set your password.',
      });
    }
    if (!user.isActive) {
      return res.status(403).json({ error: 'Your account is currently deactivated.' });
    }

    let match = await bcrypt.compare(cleanPassword, user.passwordHash);
    if (!match && cleanPassword.trim() !== cleanPassword) {
      match = await bcrypt.compare(cleanPassword.trim(), user.passwordHash);
    }
    if (!match) {
      return res.status(401).json({ error: 'Incorrect password. Please check and try again.' });
    }

    const token = createSessionToken(user.id, user.email);
    res.json({ token, profile: sanitizeProfile(user) });
  } catch (error: any) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Sign in failed. Please try again.' });
  }
});

app.post('/api/auth/firebase-sync', requireAuth, async (req: AuthRequest, res) => {
  res.json({ profile: sanitizeProfile(req.profile) });
});

app.get('/api/auth/me', requireAuth, async (req: AuthRequest, res) => {
  res.json({ profile: sanitizeProfile(req.profile) });
});

app.put('/api/auth/profile', requireAuth, async (req: AuthRequest, res) => {
  try {
    const { fullName, phone, address, avatarUrl } = req.body ?? {};
    const [updated] = await db
      .update(profiles)
      .set({
        fullName: fullName !== undefined ? String(fullName).trim() : req.profile!.fullName,
        phone: phone !== undefined ? String(phone).trim() : req.profile!.phone,
        address: address !== undefined ? String(address).trim() : req.profile!.address,
        avatarUrl: avatarUrl !== undefined ? (avatarUrl ? String(avatarUrl) : null) : req.profile!.avatarUrl,
      })
      .where(eq(profiles.id, req.profile!.id))
      .returning();

    res.json({ profile: sanitizeProfile(updated) });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Failed to update profile.' });
  }
});

app.post('/api/auth/change-password', requireAuth, async (req: AuthRequest, res) => {
  try {
    const { currentPassword, newPassword } = req.body ?? {};
    if (!newPassword || String(newPassword).length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters.' });
    }
    const [user] = await db
      .select()
      .from(profiles)
      .where(eq(profiles.id, req.profile!.id))
      .limit(1);

    if (user?.passwordHash) {
      const ok = await bcrypt.compare(String(currentPassword || ''), user.passwordHash);
      if (!ok) {
        return res.status(400).json({ error: 'Current password is incorrect.' });
      }
    }

    const hash = await bcrypt.hash(String(newPassword), 10);
    await db
      .update(profiles)
      .set({ passwordHash: hash })
      .where(eq(profiles.id, req.profile!.id));

    res.json({ message: 'Password updated successfully.' });
  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ error: 'Failed to change password.' });
  }
});

app.post('/api/auth/forgot-password', async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: 'Please enter a valid email address.' });
  }
  res.json({
    message:
      'If an account exists for that email, password recovery instructions have been recorded. For Google accounts, please sign in with Google.',
  });
});

// ==================== SECURE PERSISTENT IMAGE UPLOADS (CLOUD SQL) ====================
app.post('/api/upload/:bucket', requireAuth, upload.single('file'), async (req: AuthRequest, res) => {
  try {
    const bucket = String(req.params.bucket || '');
    if (!isAllowedUploadBucket(bucket)) {
      return res.status(400).json({ error: 'Invalid upload destination.' });
    }
    if (bucket !== 'avatars' && !hasAdminAccess(req.profile?.role)) {
      return res.status(403).json({ error: 'Only admins can upload storefront assets.' });
    }
    if (!req.file) {
      return res.status(400).json({ error: 'Please choose a JPG, PNG, WebP, or GIF image (max 5MB).' });
    }

    const ext = resolveImageExtension(req.file.mimetype);
    if (!ext) {
      return res.status(400).json({ error: 'Only JPG, PNG, WebP, and GIF images are allowed.' });
    }

    const filename = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`;
    const storagePath = buildMediaStoragePath(bucket, filename, req.profile!.id);
    const dataBase64 = req.file.buffer.toString('base64');

    await db.insert(uploadedMedia).values({
      storagePath,
      bucket,
      mimeType: req.file.mimetype,
      sizeBytes: req.file.buffer.length,
      dataBase64,
      uploadedBy: req.profile!.id,
    });

    setCachedMedia(storagePath, {
      mimeType: req.file.mimetype,
      buffer: req.file.buffer,
      etag: computeMediaEtag(storagePath, req.file.buffer.length),
    });

    res.json({ url: `/uploads/${storagePath}` });
  } catch (error: any) {
    console.error('Upload error:', error);
    res.status(400).json({ error: error.message || 'Image upload failed.' });
  }
});

// ==================== CUSTOMER CART ====================
app.get('/api/cart', requireAuth, async (req: AuthRequest, res) => {
  try {
    const items = await getUserCart(req.profile!.id);
    res.json({ items });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load cart.' });
  }
});

app.put('/api/cart', requireAuth, async (req: AuthRequest, res) => {
  try {
    const rawItems = Array.isArray(req.body?.items) ? req.body.items : [];
    const items = await replaceUserCart(req.profile!.id, rawItems);
    res.json({ items });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to save cart.' });
  }
});

app.post('/api/cart/merge', requireAuth, async (req: AuthRequest, res) => {
  try {
    const guestItems = Array.isArray(req.body?.items) ? req.body.items : [];
    const existing = await getUserCart(req.profile!.id);
    const merged = mergeCartEntries(
      existing.map((e) => ({ productId: e.productId, sizeId: e.sizeId, quantity: e.quantity })),
      guestItems
    );
    const saved = await replaceUserCart(req.profile!.id, merged);
    res.json({ items: saved });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to merge cart.' });
  }
});

// ==================== CUSTOMER & GUEST ORDERS & RECEIPTS ====================
app.post('/api/orders', optionalAuth, async (req: AuthRequest, res) => {
  try {
    const { items, orderType, deliveryAddress, customerName, customerPhone, paymentMethod, notes } =
      req.body ?? {};
    const trimmedName = typeof customerName === 'string' ? customerName.trim() : '';
    const trimmedPhone = typeof customerPhone === 'string' ? customerPhone.trim() : '';
    const fallbackName =
      trimmedName ||
      req.profile?.fullName ||
      (orderType === 'home_delivery' ? '' : 'Walk-in Customer');
    const order = await placeOrderServerSide({
      userId: req.profile?.id ?? null,
      source: 'online',
      orderType,
      deliveryAddress,
      customerName: fallbackName,
      customerPhone: trimmedPhone || req.profile?.phone || null,
      paymentMethod: paymentMethod || 'cash',
      notes,
      items: Array.isArray(items) ? items : [],
    });
    res.status(201).json({ order });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to place order.' });
  }
});

app.get('/api/orders/my', requireAuth, async (req: AuthRequest, res) => {
  try {
    const myOrders = await listOrdersWithDetails({ userId: req.profile!.id });
    res.json({ orders: myOrders });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load your orders.' });
  }
});

app.get('/api/orders/:id', optionalAuth, async (req: AuthRequest, res) => {
  try {
    const order = await getOrderWithDetails(String(req.params.id));
    if (!order) {
      return res.status(404).json({ error: 'Order not found.' });
    }
    const isGuestOrder = order.userId === null;
    const isAdmin = hasAdminAccess(req.profile?.role);
    const isOwner = Boolean(req.profile && order.userId === req.profile.id);
    if (!isGuestOrder && !isAdmin && !isOwner) {
      return res.status(403).json({ error: 'You do not have permission to view this order.' });
    }
    const settings = await ensureSiteSettings();
    res.json({ order, settings: { ...settings, deliveryCharge: Number(settings.deliveryCharge ?? 0) } });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load order.' });
  }
});

// ==================== ADMIN ROUTES ====================
app.get('/api/admin/overview', requireAdmin, async (_req, res) => {
  try {
    const stats = await getAdminDashboardStats();
    res.json(stats);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load dashboard overview.' });
  }
});

app.get('/api/admin/catalog', requireAdmin, async (_req, res) => {
  try {
    const data = await getAdminCatalogAll();
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load catalog.' });
  }
});

app.post('/api/admin/seed-sample', requireAdmin, async (_req, res) => {
  try {
    const result = await seedSampleCatalog(true);
    res.json(result);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to add sample menu.' });
  }
});

// Categories CRUD
app.post('/api/admin/categories', requireAdmin, async (req, res) => {
  try {
    const { name, description, imageUrl, isActive, sortOrder } = req.body ?? {};
    if (!name || String(name).trim().length < 1) {
      return res.status(400).json({ error: 'Category name is required.' });
    }
    const [created] = await db
      .insert(categories)
      .values({
        name: String(name).trim(),
        description: description ? String(description).trim() : null,
        imageUrl: imageUrl ? String(imageUrl).trim() : null,
        isActive: isActive !== false,
        sortOrder: Number(sortOrder) || 0,
      })
      .returning();
    res.status(201).json({ category: created });
  } catch (error) {
    console.error('Create category error:', error);
    res.status(500).json({ error: 'Failed to create category.' });
  }
});

app.put('/api/admin/categories/:id', requireAdmin, async (req, res) => {
  try {
    const id = String(req.params.id);
    const { name, description, imageUrl, isActive, sortOrder } = req.body ?? {};
    const [updated] = await db
      .update(categories)
      .set({
        name: String(name || '').trim(),
        description: description ? String(description).trim() : null,
        imageUrl: imageUrl ? String(imageUrl).trim() : null,
        isActive: Boolean(isActive),
        sortOrder: Number(sortOrder) || 0,
      })
      .where(eq(categories.id, id))
      .returning();
    res.json({ category: updated });
  } catch (error) {
    console.error('Update category error:', error);
    res.status(500).json({ error: 'Failed to update category.' });
  }
});

app.delete('/api/admin/categories/:id', requireAdmin, async (req, res) => {
  try {
    await db.delete(categories).where(eq(categories.id, String(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    console.error('Delete category error:', error);
    res.status(500).json({ error: 'Failed to delete category.' });
  }
});

// Products & inline Sizes CRUD
app.post('/api/admin/products', requireAdmin, async (req, res) => {
  try {
    const {
      name,
      description,
      categoryId,
      imageUrl,
      basePrice,
      discountPrice,
      isAvailable,
      isFeatured,
      isPopular,
      isNew,
      sizes,
    } = req.body ?? {};

    if (!name || String(name).trim().length < 2) {
      return res.status(400).json({ error: 'Product name is required.' });
    }
    const baseNum = Number(basePrice);
    if (Number.isNaN(baseNum) || baseNum < 0) {
      return res.status(400).json({ error: 'Valid base price is required.' });
    }

    const result = await db.transaction(async (tx) => {
      const [created] = await tx
        .insert(products)
        .values({
          name: String(name).trim(),
          description: description ? String(description).trim() : null,
          categoryId: categoryId || null,
          imageUrl: imageUrl ? String(imageUrl).trim() : null,
          basePrice: baseNum.toFixed(2),
          discountPrice:
            discountPrice !== null && discountPrice !== '' && discountPrice !== undefined
              ? Number(discountPrice).toFixed(2)
              : null,
          isAvailable: isAvailable !== false,
          isFeatured: Boolean(isFeatured),
          isPopular: Boolean(isPopular),
          isNew: Boolean(isNew),
        })
        .returning();

      const sizeList = Array.isArray(sizes) ? sizes : [];
      const insertedSizes = [];
      for (let i = 0; i < sizeList.length; i++) {
        const s = sizeList[i];
        if (!s?.label || Number.isNaN(Number(s.price))) continue;
        const [sz] = await tx
          .insert(productSizes)
          .values({
            productId: created.id,
            label: String(s.label).trim(),
            price: Number(s.price).toFixed(2),
            discountPrice:
              s.discountPrice !== null && s.discountPrice !== '' && s.discountPrice !== undefined
                ? Number(s.discountPrice).toFixed(2)
                : null,
            sortOrder: Number(s.sortOrder ?? i + 1),
          })
          .returning();
        insertedSizes.push(sz);
      }
      return { ...created, sizes: insertedSizes };
    });

    res.status(201).json({ product: result });
  } catch (error) {
    console.error('Create product error:', error);
    res.status(500).json({ error: 'Failed to create product.' });
  }
});

app.put('/api/admin/products/:id', requireAdmin, async (req, res) => {
  try {
    const id = String(req.params.id);
    const {
      name,
      description,
      categoryId,
      imageUrl,
      basePrice,
      discountPrice,
      isAvailable,
      isFeatured,
      isPopular,
      isNew,
      sizes,
    } = req.body ?? {};

    const result = await db.transaction(async (tx) => {
      const [updated] = await tx
        .update(products)
        .set({
          name: String(name || '').trim(),
          description: description ? String(description).trim() : null,
          categoryId: categoryId || null,
          imageUrl: imageUrl ? String(imageUrl).trim() : null,
          basePrice: Number(basePrice || 0).toFixed(2),
          discountPrice:
            discountPrice !== null && discountPrice !== '' && discountPrice !== undefined
              ? Number(discountPrice).toFixed(2)
              : null,
          isAvailable: Boolean(isAvailable),
          isFeatured: Boolean(isFeatured),
          isPopular: Boolean(isPopular),
          isNew: Boolean(isNew),
        })
        .where(eq(products.id, id))
        .returning();

      if (Array.isArray(sizes)) {
        const existingSizes = await tx
          .select()
          .from(productSizes)
          .where(eq(productSizes.productId, id));
        const keepIds = new Set(sizes.map((s: any) => s.id).filter(Boolean));

        for (const old of existingSizes) {
          if (!keepIds.has(old.id)) {
            await tx.delete(productSizes).where(eq(productSizes.id, old.id));
          }
        }

        for (let i = 0; i < sizes.length; i++) {
          const s = sizes[i];
          if (!s?.label || Number.isNaN(Number(s.price))) continue;
          const payload = {
            label: String(s.label).trim(),
            price: Number(s.price).toFixed(2),
            discountPrice:
              s.discountPrice !== null && s.discountPrice !== '' && s.discountPrice !== undefined
                ? Number(s.discountPrice).toFixed(2)
                : null,
            sortOrder: Number(s.sortOrder ?? i + 1),
          };
          if (s.id && existingSizes.some((e) => e.id === s.id)) {
            await tx.update(productSizes).set(payload).where(eq(productSizes.id, s.id));
          } else {
            await tx.insert(productSizes).values({ productId: id, ...payload });
          }
        }
      }

      const freshSizes = await tx
        .select()
        .from(productSizes)
        .where(eq(productSizes.productId, id))
        .orderBy(asc(productSizes.sortOrder));

      return { ...updated, sizes: freshSizes };
    });

    res.json({ product: result });
  } catch (error) {
    console.error('Update product error:', error);
    res.status(500).json({ error: 'Failed to update product.' });
  }
});

app.delete('/api/admin/products/:id', requireAdmin, async (req, res) => {
  try {
    await db.delete(products).where(eq(products.id, String(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    console.error('Delete product error:', error);
    res.status(500).json({ error: 'Failed to delete product.' });
  }
});

// Product Sizes standalone endpoints
app.post('/api/admin/sizes', requireAdmin, async (req, res) => {
  try {
    const { productId, label, price, discountPrice, sortOrder } = req.body ?? {};
    if (!productId || !label || Number.isNaN(Number(price))) {
      return res.status(400).json({ error: 'Product, label, and valid price are required.' });
    }
    const [created] = await db
      .insert(productSizes)
      .values({
        productId,
        label: String(label).trim(),
        price: Number(price).toFixed(2),
        discountPrice:
          discountPrice !== null && discountPrice !== '' && discountPrice !== undefined
            ? Number(discountPrice).toFixed(2)
            : null,
        sortOrder: Number(sortOrder) || 0,
      })
      .returning();
    res.status(201).json({ size: created });
  } catch (error) {
    console.error('Create size error:', error);
    res.status(500).json({ error: 'Failed to create product size.' });
  }
});

app.put('/api/admin/sizes/:id', requireAdmin, async (req, res) => {
  try {
    const { label, price, discountPrice, sortOrder } = req.body ?? {};
    const [updated] = await db
      .update(productSizes)
      .set({
        label: String(label || '').trim(),
        price: Number(price || 0).toFixed(2),
        discountPrice:
          discountPrice !== null && discountPrice !== '' && discountPrice !== undefined
            ? Number(discountPrice).toFixed(2)
            : null,
        sortOrder: Number(sortOrder) || 0,
      })
      .where(eq(productSizes.id, String(req.params.id)))
      .returning();
    res.json({ size: updated });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update product size.' });
  }
});

app.delete('/api/admin/sizes/:id', requireAdmin, async (req, res) => {
  try {
    await db.delete(productSizes).where(eq(productSizes.id, String(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete product size.' });
  }
});

// Admin Orders & POS
app.get('/api/admin/orders', requireAdmin, async (req, res) => {
  try {
    const list = await listOrdersWithDetails({
      status: req.query.status ? String(req.query.status) : undefined,
      orderType: req.query.orderType ? String(req.query.orderType) : undefined,
      source: req.query.source ? String(req.query.source) : undefined,
      search: req.query.search ? String(req.query.search) : undefined,
      dateFrom: req.query.dateFrom ? String(req.query.dateFrom) : undefined,
      dateTo: req.query.dateTo ? String(req.query.dateTo) : undefined,
    });
    res.json({ orders: list });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load orders.' });
  }
});

app.patch('/api/admin/orders/:id/status', requireAdmin, async (req, res) => {
  try {
    const status = String(req.body?.status || '');
    const allowed = new Set(['pending', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled']);
    if (!allowed.has(status)) {
      return res.status(400).json({ error: 'Invalid order status.' });
    }
    const [updated] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, String(req.params.id)))
      .returning();
    res.json({ order: updated });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update order status.' });
  }
});

app.post('/api/admin/pos/orders', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { items, orderType, customerName, customerPhone, paymentMethod, notes, extraDiscount } =
      req.body ?? {};
    const safeType = orderType === 'dine_in' ? 'dine_in' : 'pickup';
    const order = await placeOrderServerSide({
      userId: null,
      source: 'pos',
      orderType: safeType,
      deliveryAddress: null,
      customerName,
      customerPhone,
      paymentMethod: paymentMethod || 'cash',
      notes,
      extraDiscount: Number(extraDiscount) || 0,
      items: Array.isArray(items) ? items : [],
    });
    res.status(201).json({ order });
  } catch (error: any) {
    res.status(400).json({ error: error.message || 'Failed to create POS order.' });
  }
});

// Admin Customers
app.get('/api/admin/customers', requireAdmin, async (_req, res) => {
  try {
    const list = await getCustomersWithStats();
    res.json({ customers: list });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load customers.' });
  }
});

app.get('/api/admin/customers/:id/orders', requireAdmin, async (req, res) => {
  try {
    const list = await listOrdersWithDetails({ userId: String(req.params.id) });
    res.json({ orders: list });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load customer orders.' });
  }
});

app.patch('/api/admin/customers/:id/status', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const targetId = String(req.params.id);
    if (targetId === req.profile!.id) {
      return res.status(400).json({ error: 'You cannot deactivate your own admin account.' });
    }
    const existing = await db.select().from(profiles).where(eq(profiles.id, targetId)).limit(1);
    if (existing[0] && isSoleAdminEmail(existing[0].email)) {
      return res.status(403).json({ error: 'The Primary Owner account cannot be deactivated.' });
    }
    const [updated] = await db
      .update(profiles)
      .set({ isActive: Boolean(req.body?.isActive) })
      .where(eq(profiles.id, targetId))
      .returning();
    res.json({ customer: sanitizeProfile(updated) });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update account status.' });
  }
});

// Admin Banners CRUD
app.post('/api/admin/banners', requireAdmin, async (req, res) => {
  try {
    const { imageUrl, title, subtitle, offerText, buttonText, buttonLink, startDate, endDate, isActive, position } =
      req.body ?? {};
    const [created] = await db
      .insert(banners)
      .values({
        imageUrl: imageUrl || null,
        title: title || null,
        subtitle: subtitle || null,
        offerText: offerText || null,
        buttonText: buttonText || null,
        buttonLink: buttonLink || '/menu',
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        isActive: isActive !== false,
        position: Number(position) || 0,
      })
      .returning();
    res.status(201).json({ banner: created });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create banner.' });
  }
});

app.put('/api/admin/banners/:id', requireAdmin, async (req, res) => {
  try {
    const { imageUrl, title, subtitle, offerText, buttonText, buttonLink, startDate, endDate, isActive, position } =
      req.body ?? {};
    const [updated] = await db
      .update(banners)
      .set({
        imageUrl: imageUrl || null,
        title: title || null,
        subtitle: subtitle || null,
        offerText: offerText || null,
        buttonText: buttonText || null,
        buttonLink: buttonLink || '/menu',
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        isActive: Boolean(isActive),
        position: Number(position) || 0,
      })
      .where(eq(banners.id, String(req.params.id)))
      .returning();
    res.json({ banner: updated });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update banner.' });
  }
});

app.delete('/api/admin/banners/:id', requireAdmin, async (req, res) => {
  try {
    await db.delete(banners).where(eq(banners.id, String(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete banner.' });
  }
});

// Admin Offers CRUD
app.post('/api/admin/offers', requireAdmin, async (req, res) => {
  try {
    const {
      title,
      description,
      offerType,
      discountPercentage,
      discountAmount,
      startDate,
      endDate,
      applicableProductIds,
      isActive,
    } = req.body ?? {};

    if (!title || String(title).trim().length < 2) {
      return res.status(400).json({ error: 'Offer title is required.' });
    }
    const [created] = await db
      .insert(offers)
      .values({
        title: String(title).trim(),
        description: description ? String(description).trim() : null,
        offerType: String(offerType || 'percentage'),
        discountPercentage:
          discountPercentage !== null && discountPercentage !== '' && discountPercentage !== undefined
            ? Number(discountPercentage).toFixed(2)
            : null,
        discountAmount:
          discountAmount !== null && discountAmount !== '' && discountAmount !== undefined
            ? Number(discountAmount).toFixed(2)
            : null,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        applicableProductIds: JSON.stringify(Array.isArray(applicableProductIds) ? applicableProductIds : []),
        isActive: isActive !== false,
      })
      .returning();
    res.status(201).json({ offer: mapOfferRow(created) });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create offer.' });
  }
});

app.put('/api/admin/offers/:id', requireAdmin, async (req, res) => {
  try {
    const {
      title,
      description,
      offerType,
      discountPercentage,
      discountAmount,
      startDate,
      endDate,
      applicableProductIds,
      isActive,
    } = req.body ?? {};
    const [updated] = await db
      .update(offers)
      .set({
        title: String(title || '').trim(),
        description: description ? String(description).trim() : null,
        offerType: String(offerType || 'percentage'),
        discountPercentage:
          discountPercentage !== null && discountPercentage !== '' && discountPercentage !== undefined
            ? Number(discountPercentage).toFixed(2)
            : null,
        discountAmount:
          discountAmount !== null && discountAmount !== '' && discountAmount !== undefined
            ? Number(discountAmount).toFixed(2)
            : null,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        applicableProductIds: JSON.stringify(Array.isArray(applicableProductIds) ? applicableProductIds : []),
        isActive: Boolean(isActive),
      })
      .where(eq(offers.id, String(req.params.id)))
      .returning();
    res.json({ offer: mapOfferRow(updated) });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update offer.' });
  }
});

app.delete('/api/admin/offers/:id', requireAdmin, async (req, res) => {
  try {
    await db.delete(offers).where(eq(offers.id, String(req.params.id)));
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete offer.' });
  }
});

// Admin Receipt History
app.get('/api/admin/receipts', requireAdmin, async (req, res) => {
  try {
    const list = await listOrdersWithDetails({
      search: req.query.search ? String(req.query.search) : undefined,
    });
    res.json({
      receipts: list
        .filter((o) => o.receipt)
        .map((o) => ({
          id: o.receipt!.id,
          receiptNumber: o.receipt!.receiptNumber,
          issuedAt: o.receipt!.issuedAt,
          order: o,
        })),
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to load receipts.' });
  }
});

// ==================== ADMIN TEAM (ADMINS & MANAGERS) ====================
app.get('/api/admin/team', requireAdmin, async (_req, res) => {
  try {
    const allProfiles = await db.select().from(profiles).orderBy(asc(profiles.createdAt));

    const team = allProfiles
      .filter((p) => hasAdminAccess(normalizeRole(p.email, p.role)))
      .map((p) => {
        const resolved = normalizeRole(p.email, p.role);
        return {
          id: p.id,
          fullName: p.fullName,
          email: p.email,
          phone: p.phone,
          role: resolved === 'manager' ? 'manager' : 'admin',
          isOwner: isSoleAdminEmail(p.email),
          isActive: p.isActive,
          hasSignedIn: Boolean(p.firebaseUid || p.passwordHash),
          hasPassword: Boolean(p.passwordHash),
          hasGoogle: Boolean(p.firebaseUid),
          createdAt: p.createdAt.toISOString(),
        };
      })
      .sort((a, b) => Number(b.isOwner) - Number(a.isOwner));

    const promotableCustomers = allProfiles
      .filter((p) => !hasAdminAccess(normalizeRole(p.email, p.role)))
      .map((p) => ({
        id: p.id,
        fullName: p.fullName,
        email: p.email,
        phone: p.phone,
        isActive: p.isActive,
        createdAt: p.createdAt.toISOString(),
      }));

    res.json({ team, promotableCustomers });
  } catch (error) {
    console.error('Get admin team error:', error);
    res.status(500).json({ error: 'Failed to load team members.' });
  }
});

app.post('/api/admin/team', requireAdmin, async (req, res) => {
  try {
    const { email, fullName, role, password } = req.body ?? {};
    const cleanEmail = String(email || '').trim().toLowerCase();
    const cleanName = fullName ? String(fullName).trim() : '';
    const cleanRole = role === 'manager' ? 'manager' : 'admin';
    const cleanPassword = password ? String(password) : '';

    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return res.status(400).json({ error: 'Please enter a valid Gmail / email address.' });
    }
    if (cleanPassword && cleanPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters (or leave blank for Google Sign-In).' });
    }

    const finalRole = isSoleAdminEmail(cleanEmail) ? 'admin' : cleanRole;
    const passwordHash = cleanPassword ? await bcrypt.hash(cleanPassword, 10) : undefined;

    const existing = await db
      .select()
      .from(profiles)
      .where(eq(profiles.email, cleanEmail))
      .limit(1);

    let saved: typeof profiles.$inferSelect;
    if (existing.length > 0) {
      const row = existing[0];
      const [updated] = await db
        .update(profiles)
        .set({
          role: finalRole,
          isActive: true,
          fullName: cleanName || row.fullName || cleanEmail.split('@')[0],
          ...(passwordHash ? { passwordHash } : {}),
        })
        .where(eq(profiles.id, row.id))
        .returning();
      saved = updated;
    } else {
      const [created] = await db
        .insert(profiles)
        .values({
          email: cleanEmail,
          fullName: cleanName || cleanEmail.split('@')[0],
          role: finalRole,
          passwordHash: passwordHash || null,
          isActive: true,
        })
        .returning();
      saved = created;
    }

    res.status(201).json({
      member: {
        id: saved.id,
        fullName: saved.fullName,
        email: saved.email,
        phone: saved.phone,
        role: normalizeRole(saved.email, saved.role),
        isOwner: isSoleAdminEmail(saved.email),
        isActive: saved.isActive,
        hasSignedIn: Boolean(saved.firebaseUid || saved.passwordHash),
        hasPassword: Boolean(saved.passwordHash),
        hasGoogle: Boolean(saved.firebaseUid),
        createdAt: saved.createdAt.toISOString(),
      },
    });
  } catch (error) {
    console.error('Add team member error:', error);
    res.status(500).json({ error: 'Failed to add Admin / Manager.' });
  }
});

app.patch('/api/admin/team/:id', requireAdmin, async (req, res) => {
  try {
    const id = String(req.params.id);
    const { role, fullName, isActive, password } = req.body ?? {};

    const rows = await db.select().from(profiles).where(eq(profiles.id, id)).limit(1);
    const target = rows[0];
    if (!target) {
      return res.status(404).json({ error: 'Team member not found.' });
    }
    if (isSoleAdminEmail(target.email)) {
      return res.status(403).json({ error: 'The Primary Owner account cannot be modified or downgraded.' });
    }

    const cleanPassword = password !== undefined ? String(password) : '';
    if (password !== undefined && cleanPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }
    const passwordHash = cleanPassword ? await bcrypt.hash(cleanPassword, 10) : undefined;

    const nextRole =
      role === 'admin' || role === 'manager' || role === 'customer' ? role : target.role;

    const [updated] = await db
      .update(profiles)
      .set({
        role: nextRole,
        fullName: fullName !== undefined ? String(fullName).trim() || target.fullName : target.fullName,
        isActive: isActive !== undefined ? Boolean(isActive) : target.isActive,
        ...(passwordHash ? { passwordHash } : {}),
      })
      .where(eq(profiles.id, id))
      .returning();

    res.json({ member: sanitizeProfile(updated) });
  } catch (error) {
    console.error('Update team member error:', error);
    res.status(500).json({ error: 'Failed to update team member.' });
  }
});

app.delete('/api/admin/team/:id', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const id = String(req.params.id);
    const rows = await db.select().from(profiles).where(eq(profiles.id, id)).limit(1);
    const target = rows[0];
    if (!target) {
      return res.status(404).json({ error: 'Team member not found.' });
    }
    if (isSoleAdminEmail(target.email)) {
      return res.status(403).json({ error: 'The Primary Owner account cannot be removed.' });
    }
    if (req.profile && req.profile.id === target.id) {
      return res.status(400).json({ error: 'You cannot remove your own admin access.' });
    }

    // Demote back to regular customer (keeps any historical orders intact cleanly)
    await db
      .update(profiles)
      .set({ role: 'customer' })
      .where(eq(profiles.id, id));

    res.json({ success: true });
  } catch (error) {
    console.error('Remove team member error:', error);
    res.status(500).json({ error: 'Failed to remove admin access.' });
  }
});

// Admin Site Settings
app.put('/api/admin/settings', requireAdmin, async (req, res) => {
  try {
    await ensureSiteSettings();
    const {
      restaurantName,
      logoUrl,
      address,
      phone,
      email,
      openingHours,
      facebook,
      instagram,
      tiktok,
      whatsapp,
      googleMapsUrl,
      deliveryInfo,
      deliveryCharge,
      shortDescription,
      footerCopyright,
      footerRightText,
      footerTextSize,
    } = req.body ?? {};

    const validFooterSizes = new Set(['xs', 'sm', 'base', 'lg']);
    const normalizedFooterSize =
      footerTextSize !== undefined && validFooterSizes.has(String(footerTextSize))
        ? String(footerTextSize)
        : undefined;

    const [updated] = await db
      .update(siteSettings)
      .set({
        restaurantName: String(restaurantName || 'SPIZEE').trim(),
        logoUrl: logoUrl !== undefined ? (logoUrl || null) : undefined,
        address: address !== undefined ? String(address || '').trim() : undefined,
        phone: phone !== undefined ? String(phone || '').trim() : undefined,
        email: email !== undefined ? String(email || '').trim() : undefined,
        openingHours: openingHours !== undefined ? String(openingHours || '').trim() : undefined,
        facebook: facebook !== undefined ? String(facebook || '').trim() : undefined,
        instagram: instagram !== undefined ? String(instagram || '').trim() : undefined,
        tiktok: tiktok !== undefined ? String(tiktok || '').trim() : undefined,
        whatsapp: whatsapp !== undefined ? String(whatsapp || '').trim() : undefined,
        googleMapsUrl: googleMapsUrl !== undefined ? String(googleMapsUrl || '').trim() : undefined,
        deliveryInfo: deliveryInfo !== undefined ? String(deliveryInfo || '').trim() : undefined,
        deliveryCharge:
          deliveryCharge !== undefined ? Math.max(0, Number(deliveryCharge) || 0).toFixed(2) : undefined,
        shortDescription: shortDescription !== undefined ? String(shortDescription || '').trim() : undefined,
        footerCopyright:
          footerCopyright !== undefined ? String(footerCopyright).trim() : undefined,
        footerRightText:
          footerRightText !== undefined ? String(footerRightText).trim() : undefined,
        footerTextSize: normalizedFooterSize,
      })
      .where(eq(siteSettings.id, 1))
      .returning();

    res.json({
      settings: {
        ...updated,
        deliveryCharge: Number(updated.deliveryCharge ?? 0),
      },
    });
  } catch (error) {
    console.error('Update settings error:', error);
    res.status(500).json({ error: 'Failed to update settings.' });
  }
});

// Error handler for multer/upload errors
app.use((err: any, _req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err) {
    console.error('API Error:', err);
    return res.status(400).json({ error: err.message || 'Request failed.' });
  }
  next();
});

async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const srcAssetsImagesDir = path.resolve(process.cwd(), 'src', 'assets', 'images');
    if (fs.existsSync(srcAssetsImagesDir)) {
      app.use('/src/assets/images', express.static(srcAssetsImagesDir, { maxAge: '30d' }));
    }
    const distDir = path.resolve(process.cwd(), 'dist');
    // Hashed build files never change -> cache for a year; index.html must always be fresh.
    app.use(
      express.static(distDir, {
        maxAge: '1y',
        immutable: true,
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
        },
      })
    );
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SPIZEE server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
