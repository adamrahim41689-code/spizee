# SPIZEE — অ্যাপ (APK) বানানোর গাইড

## ধাপ ১: ডাটাবেস (Neon)
1. https://neon.tech এ অ্যাকাউন্ট খুলে একটা নতুন Project বানান।
2. **Connection string** কপি করুন (`postgresql://...?sslmode=require` এরকম)।

## ধাপ ২: GitHub-এ কোড তুলুন
1. GitHub-এ নতুন repository বানান (Private রাখতে পারেন)।
2. এই ফোল্ডারের সব ফাইল আপলোড করুন (`.github` ফোল্ডারসহ, এটা হিডেন ফোল্ডার)।
   সহজ উপায়: GitHub Desktop বা `git push`।

## ধাপ ৩: ব্যাকএন্ড অনলাইনে (Render)
1. https://render.com → New → **Blueprint** → আপনার repo সিলেক্ট করুন (`render.yaml` নিজে পড়বে)।
2. `DATABASE_URL` এর জায়গায় ধাপ ১-এর connection string বসান। `SESSION_SECRET` নিজে তৈরি হবে।
3. Deploy শেষ হলে একটা লিংক পাবেন, যেমন `https://spizee.onrender.com`। এই লিংকে ওয়েবসাইটও চলবে।
4. ওয়েবসাইটে `rigoshopbd@gmail.com` ইমেইল দিয়ে Sign up করলে সেটা অটো Admin হবে।
   অন্য ইমেইল চাইলে `src/middleware/auth.ts` (SOLE_ADMIN_EMAIL) আর `src/db/repository.ts` এ বদলান।
5. Admin → Overview থেকে **Seed sample** চাপলে স্যাম্পল মেনু তৈরি হবে।

## ধাপ ৪: APK বানান
1. GitHub repo → Settings → Secrets and variables → Actions → **Variables** → New variable
   - Name: `VITE_API_URL`
   - Value: ধাপ ৩-এর Render লিংক (শেষে `/` ছাড়া)
2. repo → **Actions** → "Build Android APK" → **Run workflow**।
3. ৫-১০ মিনিট পরে ওই run-এ **Artifacts → spizee-apk** ডাউনলোড করুন। ভেতরে `app-debug.apk` আছে।
4. ফোনে APK ইন্সটল করুন (Unknown sources অনুমতি দিতে হবে)।

## মনে রাখুন
- Render-এর ফ্রি প্ল্যানে কিছুক্ষণ ব্যবহার না হলে সার্ভার ঘুমিয়ে যায়, প্রথম লোড ৩০-৫০ সেকেন্ড লাগতে পারে। দ্রুত চাইলে paid প্ল্যান নিন।
- অ্যাপে Google লগইন বন্ধ রাখা হয়েছে (ইমেইল + পাসওয়ার্ড চলবে)। ওয়েবসাইটে Google লগইন চলবে।
- এটা debug APK। Play Store-এ দিতে হলে signed release APK লাগবে।
- সার্ভার ঘুমিয়ে পড়া এড়াতে চাইলে https://uptimerobot.com এ ফ্রি অ্যাকাউন্ট খুলে প্রতি ৫ মিনিটে `https://আপনার-লিংক/api/public/bootstrap` পিং করান। তাহলে প্রথম লোড ধীর হবে না।

## Netlify-তে ফ্রন্টএন্ড দিলে (ঐচ্ছিক)
Netlify শুধু ফ্রন্টএন্ড চালাতে পারে, ব্যাকএন্ড (Express + ডাটাবেস) চালাতে পারে না। ব্যাকএন্ড Render-এ থাকতেই হবে।
1. Netlify → Site configuration → Environment variables → `VITE_API_URL` = Render লিংক (শেষে `/` ছাড়া)।
2. Render → Environment → `CORS_ORIGINS` = আপনার Netlify লিংক, যেমন `https://spizee.netlify.app`।
3. Netlify → Deploys → **Clear cache and deploy site**। Build command `npm run build`, Publish directory `dist` (netlify.toml-এ দেওয়া আছে)।
4. Netlify লিংকে Google লগইন চলবে না, ইমেইল + পাসওয়ার্ড চলবে।
