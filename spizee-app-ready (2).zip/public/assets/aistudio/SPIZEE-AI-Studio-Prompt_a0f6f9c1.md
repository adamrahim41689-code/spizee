# SPIZEE (স্পাইজি) — Google AI Studio সম্পূর্ণ গাইড ও Master Prompt

এই ফাইলে দুটি অংশ আছে:

- **Part A (বাংলা):** Beginner-এর জন্য Supabase Setup, ধাপে ধাপে। এটা আগে করুন।
- **Part B (English):** Google AI Studio-তে Copy & Paste করার Master Prompt। AI Studio ইংরেজি প্রম্পটে সবচেয়ে ভালো ফল দেয়, তাই এটি ইংরেজিতে লেখা।

---

# PART A — Supabase Setup (সহজ ধাপ)

## ধাপ ১: Supabase Account ও Project

1. https://supabase.com এ যান → **Start your project** → GitHub বা Email দিয়ে Sign Up করুন।
2. **New Project** চাপুন।
3. Name: `spizee`, একটি শক্ত Database Password দিন (কোথাও লিখে রাখুন), Region: কাছের একটি (যেমন Singapore)।
4. **Create new project** চাপুন। ১–২ মিনিট অপেক্ষা করুন।

## ধাপ ২: API Key সংগ্রহ

1. বাম পাশে **Project Settings (⚙️) → API** (অথবা **Data API / API Keys**) এ যান।
2. দুটি জিনিস কপি করে রাখুন:
   - **Project URL** (যেমন `https://abcdxyz.supabase.co`)
   - **anon / public key** (অথবা "publishable key")
3. ⚠️ **service_role key কখনো AI Studio বা ওয়েবসাইটে দেবেন না।** এটি গোপন রাখতে হবে।

## ধাপ ৩: Database Table তৈরি (SQL)

1. বাম মেনু থেকে **SQL Editor** → **New query**।
2. নিচের **SQL Block** পুরোটা Copy করে Paste করুন → **Run** চাপুন।
3. "Success" দেখালে হয়ে গেছে।

```sql
-- ============ SPIZEE DATABASE SCHEMA ============
create extension if not exists pgcrypto;

-- ---------- PROFILES ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  phone text,
  address text,
  avatar_url text,
  role text not null default 'customer' check (role in ('customer','admin')),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Admin check helper (security definer avoids RLS recursion)
create or replace function public.is_admin()
returns boolean language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin' and is_active = true);
$$;

-- Auto-create profile on signup (always role = customer)
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, phone, avatar_url)
  values (new.id, new.email,
          coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
          new.phone,
          new.raw_user_meta_data->>'avatar_url');
  return new;
end; $$;

create trigger on_auth_user_created
after insert on auth.users for each row execute function public.handle_new_user();

-- Block customers from changing their own role / active status
create or replace function public.protect_profile_fields()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then
    new.role := old.role;
    new.is_active := old.is_active;
  end if;
  return new;
end; $$;

create trigger protect_profile_fields_trg
before update on public.profiles for each row execute function public.protect_profile_fields();

-- ---------- CATEGORIES ----------
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  image_url text,
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- PRODUCTS ----------
create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete set null,
  name text not null,
  description text,
  image_url text,
  base_price numeric(10,2) not null default 0,
  discount_price numeric(10,2),
  is_available boolean not null default true,
  is_featured boolean not null default false,
  is_popular boolean not null default false,
  is_new boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- PRODUCT SIZES ----------
create table public.product_sizes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  label text not null,               -- e.g. Small, Regular, 2 Pieces
  price numeric(10,2) not null,
  discount_price numeric(10,2),
  sort_order int not null default 0
);

-- ---------- ORDERS ----------
create sequence public.order_number_seq start 1001;

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint not null unique default nextval('public.order_number_seq'),
  user_id uuid references public.profiles(id) on delete set null,
  source text not null default 'online' check (source in ('online','pos')),
  customer_name text,
  customer_phone text,
  order_type text not null check (order_type in ('home_delivery','pickup','dine_in')),
  delivery_address text,
  subtotal numeric(10,2) not null default 0,
  discount numeric(10,2) not null default 0,
  total_amount numeric(10,2) not null default 0,
  payment_method text default 'cash',
  status text not null default 'pending'
    check (status in ('pending','confirmed','preparing','ready','completed','cancelled')),
  notes text,
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  size_label text,
  unit_price numeric(10,2) not null,
  quantity int not null check (quantity > 0),
  line_total numeric(10,2) not null
);

-- ---------- RECEIPTS ----------
create table public.receipts (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  receipt_number text not null unique,
  issued_at timestamptz not null default now()
);

-- ---------- CART (logged-in users) ----------
create table public.cart_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  size_id uuid references public.product_sizes(id) on delete set null,
  quantity int not null default 1 check (quantity > 0),
  unique (user_id, product_id, size_id)
);

-- ---------- BANNERS ----------
create table public.banners (
  id uuid primary key default gen_random_uuid(),
  image_url text,
  title text,
  subtitle text,
  offer_text text,
  button_text text,
  button_link text,
  start_date timestamptz,
  end_date timestamptz,
  is_active boolean not null default true,
  position int not null default 0,
  created_at timestamptz not null default now()
);

-- ---------- OFFERS ----------
create table public.offers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  offer_type text not null check (offer_type in ('percentage','fixed','combo','special_price','limited_time')),
  discount_percentage numeric(5,2),
  discount_amount numeric(10,2),
  start_date timestamptz,
  end_date timestamptz,
  applicable_product_ids uuid[] default '{}',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- SITE SETTINGS (single row) ----------
create table public.site_settings (
  id int primary key default 1 check (id = 1),
  restaurant_name text default 'SPIZEE',
  logo_url text,
  address text,
  phone text,
  email text,
  opening_hours text,
  facebook text, instagram text, tiktok text, whatsapp text,
  google_maps_url text,
  delivery_info text,
  delivery_charge numeric(10,2) default 0,
  short_description text
);
insert into public.site_settings (id) values (1);

-- ============ SERVER-SIDE ORDER FUNCTION ============
-- Prices are calculated on the server so customers cannot fake totals.
create or replace function public.place_order(
  p_items jsonb,            -- [{"size_id":"uuid","product_id":"uuid","quantity":2}, ...]
  p_order_type text,
  p_delivery_address text default null,
  p_customer_name text default null,
  p_customer_phone text default null,
  p_notes text default null,
  p_source text default 'online'
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_order_id uuid;
  v_item jsonb;
  v_size record;
  v_prod record;
  v_price numeric(10,2);
  v_qty int;
  v_subtotal numeric(10,2) := 0;
  v_source text := 'online';
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  if p_source = 'pos' then
    if not public.is_admin() then raise exception 'Not allowed'; end if;
    v_source := 'pos';
  end if;
  if p_order_type = 'home_delivery' and (p_delivery_address is null or length(trim(p_delivery_address)) < 5) then
    raise exception 'Delivery address required';
  end if;
  if v_source = 'pos' then p_delivery_address := null; end if;

  insert into public.orders (user_id, source, customer_name, customer_phone, order_type, delivery_address, notes)
  values (case when v_source='pos' then null else auth.uid() end, v_source, p_customer_name, p_customer_phone,
          p_order_type, p_delivery_address, p_notes)
  returning id into v_order_id;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::int;
    if v_qty is null or v_qty < 1 or v_qty > 50 then raise exception 'Invalid quantity'; end if;
    select * into v_prod from public.products where id = (v_item->>'product_id')::uuid and is_available = true;
    if not found then raise exception 'Product unavailable'; end if;

    if v_item->>'size_id' is not null then
      select * into v_size from public.product_sizes
        where id = (v_item->>'size_id')::uuid and product_id = v_prod.id;
      if not found then raise exception 'Invalid size'; end if;
      v_price := coalesce(v_size.discount_price, v_size.price);
    else
      v_price := coalesce(v_prod.discount_price, v_prod.base_price);
    end if;

    insert into public.order_items (order_id, product_id, product_name, size_label, unit_price, quantity, line_total)
    values (v_order_id, v_prod.id, v_prod.name, v_size.label, v_price, v_qty, v_price * v_qty);
    v_subtotal := v_subtotal + v_price * v_qty;
    v_size := null;
  end loop;

  update public.orders set subtotal = v_subtotal, total_amount = v_subtotal - discount where id = v_order_id;

  insert into public.receipts (order_id, receipt_number)
  values (v_order_id, 'SPZ-' || to_char(now() at time zone 'Asia/Dhaka','YYMMDD') || '-' ||
          (select order_number from public.orders where id = v_order_id));

  if v_source = 'online' then
    delete from public.cart_items where user_id = auth.uid();
  end if;
  return v_order_id;
end; $$;

grant execute on function public.place_order to authenticated;

-- ============ ROW LEVEL SECURITY ============
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_sizes enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.receipts enable row level security;
alter table public.cart_items enable row level security;
alter table public.banners enable row level security;
alter table public.offers enable row level security;
alter table public.site_settings enable row level security;

-- profiles
create policy "own profile read" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "own profile update" on public.profiles for update using (id = auth.uid() or public.is_admin());

-- public catalog (read by everyone, write by admin)
create policy "cat read" on public.categories for select using (true);
create policy "cat admin" on public.categories for all using (public.is_admin()) with check (public.is_admin());
create policy "prod read" on public.products for select using (true);
create policy "prod admin" on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy "size read" on public.product_sizes for select using (true);
create policy "size admin" on public.product_sizes for all using (public.is_admin()) with check (public.is_admin());
create policy "banner read" on public.banners for select using (true);
create policy "banner admin" on public.banners for all using (public.is_admin()) with check (public.is_admin());
create policy "offer read" on public.offers for select using (true);
create policy "offer admin" on public.offers for all using (public.is_admin()) with check (public.is_admin());
create policy "settings read" on public.site_settings for select using (true);
create policy "settings admin" on public.site_settings for update using (public.is_admin()) with check (public.is_admin());

-- orders: customer sees own, admin sees all; creation only through place_order()
create policy "orders read" on public.orders for select using (user_id = auth.uid() or public.is_admin());
create policy "orders admin update" on public.orders for update using (public.is_admin());
create policy "items read" on public.order_items for select using (
  exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));
create policy "receipts read" on public.receipts for select using (
  exists (select 1 from public.orders o where o.id = order_id and (o.user_id = auth.uid() or public.is_admin())));

-- cart: own only
create policy "cart own" on public.cart_items for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ============ STORAGE BUCKETS ============
insert into storage.buckets (id, name, public) values
  ('product-images','product-images',true),
  ('banners','banners',true),
  ('site-assets','site-assets',true),
  ('avatars','avatars',true)
on conflict (id) do nothing;

create policy "public read images" on storage.objects for select
  using (bucket_id in ('product-images','banners','site-assets','avatars'));
create policy "admin write images" on storage.objects for all
  using (bucket_id in ('product-images','banners','site-assets') and public.is_admin())
  with check (bucket_id in ('product-images','banners','site-assets') and public.is_admin());
create policy "avatar own upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "avatar own update" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
```

> **Storage-এ Error এলে:** Supabase-এর কিছু ভার্সনে SQL দিয়ে Storage Policy ফেইল করতে পারে। তখন **Storage** মেনুতে গিয়ে ৪টি Bucket (`product-images`, `banners`, `site-assets`, `avatars`) নিজে হাতে বানান এবং **Public bucket** অন করুন। Policy নিয়ে সমস্যা হলে AI Studio-কে Error মেসেজ পেস্ট করে দিন।

## ধাপ ৪: Authentication Setup

1. **Authentication → Providers** এ যান।
2. **Email** চালু আছে কিনা দেখুন।
   - শুরুতে Test করার সময় **Authentication → Sign In / Providers → Email → "Confirm email"** বন্ধ রাখতে পারেন, যাতে দ্রুত Test করা যায়। Live করার আগে আবার চালু করুন।
3. **Google Login (ঐচ্ছিক):**
   - Google Cloud Console → APIs & Services → Credentials → **OAuth client ID** (Web application) তৈরি করুন।
   - **Authorized redirect URI**-তে Supabase-এর দেখানো Callback URL (`https://<project>.supabase.co/auth/v1/callback`) বসান।
   - Client ID ও Secret Supabase-এর **Google Provider**-এ বসিয়ে Enable করুন।
4. **Mobile Number Login:** SMS পাঠাতে Twilio-র মতো SMS Provider লাগে এবং এতে খরচ আছে। শুরুতে Email + Google দিয়ে চালু করুন। Mobile নম্বর **Profile-এ তথ্য হিসেবে** সংরক্ষণ করা যাবে। Phone OTP পরে যোগ করা যাবে।
5. **URL Configuration:** **Authentication → URL Configuration** এ **Site URL** ও **Redirect URLs**-এ আপনার ওয়েবসাইটের লিংক (পরে Deploy করা লিংক) যোগ করুন।

## ধাপ ৫: নিজেকে Admin বানান

1. আগে ওয়েবসাইটে (বা Supabase **Authentication → Users → Add user**) আপনার Email দিয়ে একটি Account তৈরি করুন।
2. **SQL Editor**-এ নিচের কোড চালান (Email নিজেরটা দিন):

```sql
update public.profiles set role = 'admin' where email = 'YOUR_EMAIL@example.com';
```

3. এখন ওই Email দিয়ে Login করলে Admin Dashboard দেখা যাবে।

## ধাপ ৬: Environment Variables (AI Studio-তে)

AI Studio-তে **Settings / Secrets (Environment variables)** অংশে যোগ করুন:

| Name | Value |
|---|---|
| `VITE_SUPABASE_URL` | ধাপ ২-এর Project URL |
| `VITE_SUPABASE_ANON_KEY` | ধাপ ২-এর anon/public key |

> Key কেবল এই দুটিই। **service_role key দেবেন না।** AI Studio ভিন্ন নাম চাইলে (যেমন `process.env`), সেটাই অনুসরণ করুন। Master Prompt-এ AI-কে সেটা মানতে বলা আছে।

## ধাপ ৭: AI Studio-তে ব্যবহার

1. Google AI Studio → **Build** মোডে নতুন App শুরু করুন।
2. আপনার **Logo ফাইল আপলোড** করুন (Attachment হিসেবে)।
3. নিচের **Part B** পুরোটা Paste করে Run করুন।
4. এক প্রম্পটে সব না এলে, নিচের **Follow-up Prompts** একটা একটা করে দিন।
5. প্রতিটি ধাপের পর নিজে Test করুন, তারপর পরের ধাপে যান।

---
---

# PART B — MASTER PROMPT (এখান থেকে নিচের সবটুকু Copy করুন)

```
You are a senior full-stack engineer and product designer. Build a COMPLETE, PRODUCTION-READY, FULLY FUNCTIONAL fast-food restaurant ordering website and admin system called **SPIZEE** (Bangla: স্পাইজি). This is NOT a static mockup or demo. Every button, form, cart action, login, order, dashboard widget, receipt, print and PDF download must work against a real database. Do not leave any feature incomplete or stubbed. Do not use dummy/fake data for statistics; all dashboard numbers must be computed from real database records.

The owner is a beginner. Whenever setup is needed, give very simple step-by-step instructions in plain language.

====================================================
0. WORKING METHOD (follow this order, report after each phase)
====================================================
Phase 1: Architecture: folder structure, routes, data flow, component list.
Phase 2: Frontend design system and public pages.
Phase 3: Supabase connection, database, storage.
Phase 4: Authentication and role protection.
Phase 5: Admin dashboard shell and Product / Category / Size management.
Phase 6: Cart and Checkout.
Phase 7: Order management and Admin POS.
Phase 8: Receipt, Print, PDF download.
Phase 9: Banners, Offers, Settings, Customers, Dashboard charts.
Phase 10: Full self-test of every flow, bug fixes, production-readiness checklist.
If the output is too large for one response, finish each phase fully and continue in the next response. Never skip or "leave for later".

====================================================
1. BRANDING AND DESIGN
====================================================
- Name everywhere: **SPIZEE** (exact spelling; never "SPIZW" or any variant). Bangla: স্পাইজি.
- The owner has UPLOADED the restaurant logo with this prompt. Use that exact uploaded logo in the header, footer, login pages, admin sidebar and receipt. NEVER redraw, recolor, crop, distort or alter the logo.
- Palette: Primary Yellow (#FFC20E-ish, choose a refined premium yellow) and White. Secondary: soft yellow, warm cream, light gray. Text: dark gray/near-black for readability only. NO dark/black page backgrounds anywhere (the receipt's black text on white paper is the only black-heavy element).
- Style: premium, modern, minimal, clean, professional, like a real fast-food brand. Glassmorphism (frosted translucent panels with backdrop-blur, soft borders, soft shadows) on header, cards, modals, buttons, dashboard widgets and floating elements. Rounded corners (xl/2xl), smooth transitions.
- Subtle animations: page transitions, smooth scroll, card hover lift, button hover, add-to-cart animation, cart badge bounce, modal fade/scale, slider transitions, sidebar slide, dashboard card entrance, skeleton/loading animations, toast notifications. Keep them tasteful, not excessive. Site must feel fast.
- Fully responsive: desktop, laptop, tablet, mobile (including mobile nav, mobile cart, mobile checkout, mobile profile, and responsive admin dashboard with collapsible sidebar).
- Use a Bengali-friendly font pair for Bangla text (e.g., Hind Siliguri or Noto Sans Bengali) with a modern Latin font. Currency symbol: ৳ (BDT).
- All UI text in English by default, but structure text through a simple i18n object so Bangla can be added easily; the brand name in Bangla (স্পাইজি) shown in the footer/about.

====================================================
2. TECH STACK
====================================================
- React + TypeScript + Vite + Tailwind CSS + React Router + a lightweight state solution (Context or Zustand).
- Supabase: Auth, Postgres Database, Storage, Row Level Security, RPC functions. Use `@supabase/supabase-js`.
- Read credentials ONLY from environment variables: `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (adapt to the AI Studio environment's supported mechanism if it differs). NEVER hardcode keys. NEVER use or ask for the service_role key in the frontend.
- PDF: `jspdf` + `jspdf-autotable` (or html2canvas) for real PDF file download. Print: dedicated print stylesheet / print route using `window.print()`.
- Charts: Recharts.
- Toasts: a lightweight toast library or custom.
If something above is not supported in the environment, choose the closest supported alternative, but keep ALL functionality and real database integration.

====================================================
3. DATABASE (ALREADY CREATED BY THE OWNER IN SUPABASE VIA SQL)
====================================================
The owner has already run SQL that created these tables, with RLS enabled. Use them exactly:

- `profiles` (id = auth user id, full_name, email, phone, address, avatar_url, role 'customer'|'admin', is_active, created_at)
- `categories` (id, name, description, image_url, is_active, sort_order)
- `products` (id, category_id, name, description, image_url, base_price, discount_price, is_available, is_featured, is_popular, is_new, created_at)
- `product_sizes` (id, product_id, label, price, discount_price, sort_order)
- `orders` (id, order_number, user_id, source 'online'|'pos', customer_name, customer_phone, order_type 'home_delivery'|'pickup'|'dine_in', delivery_address, subtotal, discount, total_amount, payment_method, status 'pending'|'confirmed'|'preparing'|'ready'|'completed'|'cancelled', notes, created_at)
- `order_items` (id, order_id, product_id, product_name, size_label, unit_price, quantity, line_total)
- `receipts` (id, order_id, receipt_number, issued_at)
- `cart_items` (id, user_id, product_id, size_id, quantity)
- `banners` (id, image_url, title, subtitle, offer_text, button_text, button_link, start_date, end_date, is_active, position)
- `offers` (id, title, description, offer_type, discount_percentage, discount_amount, start_date, end_date, applicable_product_ids, is_active)
- `site_settings` (single row id=1: restaurant_name, logo_url, address, phone, email, opening_hours, facebook, instagram, tiktok, whatsapp, google_maps_url, delivery_info, delivery_charge, short_description)
- Postgres function `place_order(p_items jsonb, p_order_type, p_delivery_address, p_customer_name, p_customer_phone, p_notes, p_source)` returns the new order id. It calculates prices on the SERVER, creates order, order_items and the receipt record. **Always create orders by calling this RPC** (items: `[{product_id, size_id, quantity}]`). Never insert orders/order_items directly and never trust client-side totals.
- Storage buckets (public read): `product-images`, `banners`, `site-assets` (admin write), `avatars` (user writes only inside folder named by their own user id).
- Helper `is_admin()` exists in the DB.
On first run, verify the connection and the existence of these tables; if something is missing, show a clear, friendly setup-error screen telling the owner exactly what is missing, instead of crashing. If you believe the schema needs changes, output the exact additional SQL and explain how to run it in Supabase → SQL Editor.

====================================================
4. PUBLIC WEBSITE
====================================================
**Header (sticky, glassmorphism):** SPIZEE logo (uploaded), Home, Menu, About / Restaurant Info, Contact, Cart button with live item-count badge, Profile button, Login / Sign Up button (when logged out). Mobile: hamburger menu with animated drawer.

**Home page:**
1. Hero promotional slider (3–4+ banners loaded from `banners` table, only active and within start/end dates, ordered by `position`): autoplay, prev/next arrows, indicators, smooth transitions, swipe on mobile, title, subtitle, offer text and CTA button. If there are no banners yet, show elegant default placeholder slides so the page never looks broken.
2. Category strip (from `categories`: e.g., Burgers, Chicken, Fried Chicken, Shawarma, Fries, Pizza, Drinks, Combos, Snacks, Special Offers).
3. Food product sections (Featured, Popular, New, Offers) in premium glass cards.
4. Offer highlights from active `offers`.
5. Footer.

**Food card:** image, name, short description, price, discount price (strike-through original), size selector with size-wise live price, Add to Cart, Buy Now, availability state (disabled "Sold Out" if unavailable), badge (New / Popular / Offer). Clicking the card opens a Product Details modal (large image, description, size selection, quantity stepper, Add to Cart, Buy Now).

**Menu page:** all foods, category tabs/filters, search bar (by name), price range filter, filters for Popular / New / Discount items, category-wise listing, empty-state design, loading skeletons.

**About / Restaurant Info page** and **Contact page**: content from `site_settings` (address, phone, email, opening hours, social links, Google Maps embed/link, delivery info).

**Footer:** logo, restaurant name, short description, phone, email, address, Google Maps link, Facebook, Instagram, TikTok, WhatsApp, opening hours, copyright. All from `site_settings` so admin edits reflect instantly.

====================================================
5. PRODUCT SIZES AND VARIATIONS
====================================================
- Each product can have any number of sizes created by admin (e.g., Burger: Small/Regular/Big/Large; Chicken: 1/2/4/6 Pieces), each with its own price (and optional discount price).
- Selecting a size updates the displayed price immediately and the correct size price goes into the cart.
- Products with no sizes use base_price / discount_price.
- Admin can add, edit, delete sizes and set size-wise prices from the product form.

====================================================
6. CART (fully working)
====================================================
- Add multiple products; same product with different sizes = separate lines; increase / decrease quantity; remove item; change size inside cart; automatic subtotal and total; empty-cart state; slide-over cart drawer plus full cart page; animated count badge.
- Persistence: guests → `localStorage`; logged-in customers → `cart_items` table (sync/merge guest cart into DB on login). Cart survives refresh.
- Cart line shows image, name, selected size, unit price, quantity controls, subtotal, remove button; footer shows total amount and Checkout button.

====================================================
7. AUTHENTICATION AND ROLES
====================================================
- Two roles: **admin** and **customer**, stored in `profiles.role` (never trust client-side flags or localStorage for the role; always read role from the database after login).
- Customer: Sign Up / Login with Email + Password, "Continue with Google" button (Supabase Google OAuth), and phone number collected on signup/profile (Phone-OTP login is optional; implement the UI and code path behind a clearly-labeled config flag that is OFF by default, because it requires an SMS provider). Forgot-password flow, logout, friendly validation and error messages.
- Admin: logs in with Email + Password via the same login screen, then is redirected automatically to `/admin`. Customers can NEVER see or open admin routes: implement route guards that verify `role = 'admin'` from `profiles`; non-admins are redirected away. All admin data operations are additionally protected by database RLS.
- Admin accounts are created by the owner in Supabase (SQL `update profiles set role='admin' ...`), never via public signup. Do not provide any UI that lets a user promote themselves.
- Do not expose sensitive admin information in the frontend bundle.

====================================================
8. CUSTOMER PROFILE
====================================================
Profile picture upload (to `avatars/<user-id>/...` with image type/size validation), name, email, mobile number, address, Edit Profile, Change Password, Order History (with status badges and order details), Previous Receipts (view / print / download), Logout.

====================================================
9. CHECKOUT AND ORDER SYSTEM (customer)
====================================================
Checkout page contains: customer info (prefilled from profile, editable), ordered items with size/quantity/price, subtotal, delivery charge (from settings, only for Home Delivery), total, order type selector, Confirm Order button.

Order types:
1. **Home Delivery:** shows delivery address/location field (required), prefilled from profile.
2. **Instant / Restaurant Pickup (and Dine-In option):** no delivery address required; the interface changes accordingly.

"Buy Now" on a product goes to checkout with just that item. Place the order via the `place_order` RPC, then show the Order Confirmation page with the receipt. Require login for placing orders (redirect guests to login and return them to checkout afterwards, preserving the cart). Validate all fields. Prevent double-submit.

====================================================
10. ADMIN DASHBOARD (separate interface, yellow & white glass theme)
====================================================
Collapsible animated sidebar:
Dashboard Overview, Products, Categories, Product Sizes, Orders, POS / Quick Order, Customers, Promotional Banners, Offers & Discounts, Receipt History, Website Settings, Contact & Social Media, Admin Profile, Logout.

**Overview:** cards for Total Products, Total Orders, Today's Orders, Total Revenue, Today's Revenue, Pending Orders, Completed Orders, Total Customers, all computed from the real database (revenue excludes cancelled orders). Charts: Daily Sales, Monthly Sales, Order Statistics (by status), Popular Products (by quantity sold). "Today" is calculated in Asia/Dhaka time. Empty states when there is no data yet (no fake numbers).

**Products:** table with search and filters; Add / Edit / Delete (confirmation popup); image upload to Storage with preview; name, description, category, base price, discount price, availability, featured/popular/new flags, status; multiple sizes with size-wise prices (add/edit/delete inline). Changes appear on Home and Menu immediately.

**Categories:** add / edit / delete (confirmation popup), image, name, description, status, sort order; assign products to categories.

**Orders:** list all orders with Order ID/number, customer name, phone, products, quantity, size, total, date, time, order type, address, payment info, status. Search and filters (status, type, date range, source online/POS). Admin can change status (Pending → Confirmed → Preparing → Ready → Completed, or Cancelled), open Order Details, print the receipt, and view order history.

**POS / Quick Order (admin only):** fast, touch-friendly interface with category tabs, product search, product grid, size picker, quantity, add/remove lines, live total, optional customer name and phone, Confirm Order. **No delivery address or home-delivery option in POS.** It uses the same orders tables (source = 'pos') through `place_order(..., p_source := 'pos')`. After confirming, show the receipt immediately with Print / Download buttons.

**Customers:** list with name, email, mobile, address, registration date, total orders, total purchase; view a customer's profile and order history; activate / deactivate account (`is_active`).

**Banners:** add / edit / delete / reorder (position), image upload, title, subtitle, offer text, button text and link, start date, end date, active/inactive toggle, live preview.

**Offers & Discounts:** percentage discount, fixed discount, combo offer, special price, limited-time offer, with title, description, amount/percentage, start & end dates, applicable products, active status. Active offers must visibly affect the storefront (badge/discount display) in a consistent, documented way. If applying offers to final price requires server-side logic, output the exact SQL to update `place_order` so that checkout totals stay server-calculated.

**Receipt History:** searchable list of all receipts; view / print / download any receipt.

**Website Settings and Contact & Social Media:** restaurant name, logo (uploadable to `site-assets`), address, phone, email, opening hours, Facebook, Instagram, TikTok, WhatsApp, Google Maps link, delivery information, delivery charge, short description. Saving updates the Footer, Contact page and Header live.

**Admin Profile:** name, avatar, change password.

====================================================
11. RECEIPT, PRINT, PDF
====================================================
After any order is confirmed (customer or admin), generate a receipt in a **traditional white-paper, black-text** style (simple monospaced/receipt typography, dashed separators). It must contain: SPIZEE logo (uploaded), restaurant name SPIZEE, receipt number, order ID/number, customer name and phone (if any), order type, delivery address (only for Home Delivery), items with size, quantity, unit price and line total, subtotal, discount, delivery charge (if any), total amount, order date, order time **including hour, minute and second** (auto-generated, Asia/Dhaka timezone), order status, and a Thank-You message at the bottom.

- **Print Receipt button:** opens a clean print layout through the browser print system (works on mobile and desktop). A dedicated `@media print` stylesheet must hide the header, footer, navigation, buttons, backgrounds and all other UI. Optimize for 80mm thermal paper and also look correct on A4 (use `@page` size and width rules).
- **Download Receipt button:** generates and downloads a real **PDF** file (e.g., `SPIZEE-Receipt-<number>.pdf`) that can be saved on mobile or desktop.
- Receipts are reachable from the Order Confirmation page, the customer's Order History / Previous Receipts, and the admin Orders / Receipt History pages.

====================================================
12. SECURITY REQUIREMENTS
====================================================
- Secure Supabase Auth; admin route guards plus RLS; never trust the client for role or prices; orders only via `place_order` RPC.
- Validate and sanitize all inputs (client and, where applicable, server). Escape rendered user content (no `dangerouslySetInnerHTML` with user data).
- Secure image uploads: allow only jpg/png/webp, enforce max size (e.g., 3–5 MB), randomized file names.
- No secrets in code or in the bundle apart from the public anon key and URL.
- Passwords handled only by Supabase Auth; enforce minimum strength on the UI.
- Customers can read only their own profile, cart, orders, order items and receipts.

====================================================
13. QUALITY, ERROR HANDLING AND UX
====================================================
- Loading skeletons, empty states, friendly error messages, toast notifications for every action, confirmation dialogs for deletes.
- Realtime or automatic refresh of the admin Orders list when new orders arrive (Supabase Realtime if enabled, otherwise polling every ~15 seconds), with a subtle sound/visual alert.
- Accessible markup (labels, aria, focus states), good contrast, SEO basics (title, meta description, favicon from the uploaded logo).
- Clean, well-organized, commented code with reusable components and typed models.
- Seed helper: a one-click "Add sample menu" button visible ONLY to admin on an empty database that inserts a few example categories/products/sizes (clearly marked as sample, deletable). Dashboard statistics must never use fake numbers.

====================================================
14. FINAL SELF-TEST CHECKLIST (perform and report results)
====================================================
1. Guest browses Home and Menu, searches, filters, opens product modal.
2. Guest adds items with different sizes; refresh keeps the cart.
3. Customer signs up, logs in (email and Google), cart merges.
4. Customer places Home Delivery order (address required) and Pickup order (no address).
5. Receipt appears with correct data, timestamp with seconds; Print layout is clean; PDF downloads.
6. Customer sees the order in Order History and can re-open the receipt.
7. Customer cannot open `/admin` (redirected) and cannot read other users' data.
8. Admin logs in, lands on the dashboard, sees real statistics.
9. Admin adds category, product with images and sizes → appears on Home/Menu instantly; edit and delete work.
10. Admin changes order status; the customer sees the update.
11. Admin POS order has no delivery address, creates a receipt, and prints/downloads it.
12. Banners, offers, settings and social links change the storefront live.
13. Everything works on mobile width.
Fix every bug found. Then provide a PRODUCTION-READINESS CHECKLIST (enable email confirmation, set Site URL and Redirect URLs, Google OAuth credentials, backups, custom domain, deployment steps) in simple beginner language.

====================================================
15. BEGINNER SETUP INSTRUCTIONS TO OUTPUT
====================================================
At the start, show the owner a short, simple checklist of what they must have ready (Supabase project URL and anon key, SQL already run, Storage buckets, Auth providers, admin promotion SQL, environment variables). If anything is not ready, guide them step by step, in simple words, with exact click paths. Use clear numbered steps. Then proceed to build.

Begin with Phase 1 now.
```

---
---

# Follow-up Prompts (দরকার হলে একটা একটা করে দিন)

**যদি এক রেসপন্সে অসম্পূর্ণ থাকে:**
```
Continue exactly where you stopped. Complete the next phase fully with working code. Do not summarize, do not skip any feature.
```

**Supabase সংযোগ ঠিক না থাকলে:**
```
The app can't connect to Supabase / shows errors. Here is the exact error message: [PASTE ERROR]. Diagnose the cause, fix the code, and if SQL is needed give me the exact SQL and tell me where to click to run it.
```

**Logo ঠিকমতো না বসলে:**
```
Use my uploaded logo exactly as provided (no redraw, no recolor, no crop) in the header, footer, login page, admin sidebar and receipt. Also use it as the favicon.
```

**Mobile-এ সমস্যা:**
```
Test and fix every page and the admin dashboard at 360px, 390px, 768px and 1280px widths. Fix overflow, tiny tap targets, broken drawers and unreadable tables (use card layouts for tables on mobile).
```

**Print/PDF ঠিক না হলে:**
```
Fix the receipt: print layout must hide all site UI and fit 80mm thermal paper and A4. PDF download must produce a real file named SPIZEE-Receipt-<number>.pdf with the same content as the on-screen receipt, including logo and time with seconds.
```

**সব শেষে চূড়ান্ত পরীক্ষা:**
```
Run the full self-test checklist (section 14) item by item, report PASS/FAIL for each, fix all failures, then give me the production-readiness checklist.
```

---

## কিছু গুরুত্বপূর্ণ কথা

- **Mobile OTP Login:** SMS Provider (খরচ লাগে) ছাড়া কাজ করে না। তাই শুরুতে Email + Google রাখা হয়েছে।
- **Google Login:** Google Cloud-এ OAuth Credential না বানালে Google বাটন কাজ করবে না।
- **অর্ডারের দাম:** Server-এ হিসাব হয়, তাই কেউ Browser থেকে দাম বদলে ঠকাতে পারবে না।
- **Admin Account:** শুধু আপনি Supabase থেকে বানাতে পারবেন, ওয়েবসাইট থেকে কেউ Admin হতে পারবে না।
- **Live করার আগে:** Email Confirmation চালু করুন এবং Site URL/Redirect URL ঠিক করুন।
